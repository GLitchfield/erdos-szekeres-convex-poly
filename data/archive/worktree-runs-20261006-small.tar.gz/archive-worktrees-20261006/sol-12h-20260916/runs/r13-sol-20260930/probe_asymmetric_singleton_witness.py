"""One exact stress witness for generic singleton attainment; diagnostic only."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from decomposable_additivity_test import child
from probe_singleton_normal import singleton_values


def main():
    start = time.monotonic()
    word = ((1, "upper"), "S", "S", (1, "upper"),
            (2, "lower"), "S", "S", (2, "lower"))
    maxima = (1, 1)
    bound = compiled_evaluator(4, 4, 5, cache_size=2_000_000, persistent=True)
    try:
        value = bound(word, maxima)
        choices = singleton_values(bound, 5, word, maxima)
        cut_parts = [child(word, maxima, {1, 2}, "lower", 1),
                     child(word, maxima, {5, 6}, "upper", 3)]
        output = {"semantics": "context-bound-zero-children-c-v1", "case": [4, 4, 5],
                  "word": word, "maxima": maxima, "bound": value,
                  "best_singleton": max(choices), "singleton_choices": choices,
                  "balanced_cut_parts": cut_parts,
                  "balanced_cut_values": [bound(*row) for row in cut_parts],
                  "seconds": time.monotonic() - start}
    finally:
        bound.close()
    Path(sys.argv[1]).write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"done": 1, "total": 1, "bound": value,
                      "best_singleton": max(choices), "seconds": output["seconds"]}), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
