import ESBlueprint.B.CtxBoundAttainedByEndCut

namespace ErdosSzekeres
open Ctx Ctx.Context

-- Classification only; no refuted end-cut theorem is invoked.
example (σ : Context) (hruns : 2 ≤ σ.numRuns)
    (hlen : σ.childPositions.length ≤ 3) (block : List ℕ) (hb : block ∈ σ.blocks) :
    ∃ p ∈ σ.childPositions,
      (∀ q ∈ σ.childPositions, q ∈ block ↔ q = p) ∨
      (∀ q ∈ σ.childPositions, q ∈ block ↔ q ≠ p) := by
  classical
  have hn : 2 ≤ σ.childPositions.length := hruns.trans (numRuns_le_length σ)
  have hd := childPositions_nodup σ
  have hsize : σ.childPositions.length = 2 ∨ σ.childPositions.length = 3 := by omega
  rcases hsize with h2 | h3
  · obtain ⟨a, b, hps⟩ := List.length_eq_two.mp h2
    simp [hps] at hd
    simp only [blocks, hps] at hb
    change block ∈ [[a], [b]] at hb
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hb
    rcases hb with rfl | rfl
    · refine ⟨a, ?_, Or.inl ?_⟩ <;> simp_all
    · refine ⟨b, ?_, Or.inl ?_⟩ <;> simp_all
  · obtain ⟨a, b, c, hps⟩ := List.length_eq_three.mp h3
    simp [hps] at hd
    simp only [blocks, hps] at hb
    change block ∈ [[a], [a, b], [b], [b, c], [c]] at hb
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hb
    rcases hb with rfl | rfl | rfl | rfl | rfl
    · refine ⟨a, ?_, Or.inl ?_⟩ <;> simp_all
    · refine ⟨c, ?_, Or.inr ?_⟩ <;> simp_all
    · refine ⟨b, ?_, Or.inl ?_⟩ <;> simp_all
    · refine ⟨a, ?_, Or.inr ?_⟩ <;> simp_all
    · refine ⟨c, ?_, Or.inl ?_⟩ <;> simp_all

end ErdosSzekeres
