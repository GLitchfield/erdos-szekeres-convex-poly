by
  classical
  have hBase : ∀ (ρ : Context), ρ.a ≤ 1 ∨ ρ.u ≤ 1 → ρ.base = 0 := by
    intro ρ hρ
    cases hp : ρ.childPositions.head? with
    | none => simp [base, hp]
    | some p =>
      rcases hρ with ha | hu
      · have hz : ρ.a - 1 = 0 := by omega
        simp [base, hp, capLimit, hz]
      · have hz : ρ.u - 1 = 0 := by omega
        simp [base, hp, cupLimit, hz]
  have hFuel : ∀ fuel (ρ : Context), ρ.a ≤ 1 ∨ ρ.u ≤ 1 → boundFuel fuel ρ = 0 := by
    intro fuel
    induction fuel with
    | zero => intro ρ _; rfl
    | succ fuel ih =>
      intro ρ hρ
      rw [boundFuel.eq_2]
      by_cases hr : ρ.numRuns ≤ 1
      · rw [if_pos hr]
        exact hBase ρ hρ
      · rw [if_neg hr]
        apply Nat.eq_zero_of_le_zero
        apply getD_max?_le
        intro value hv
        simp only [List.mem_flatMap, List.mem_range, List.mem_cons,
          List.not_mem_nil, or_false] at hv
        obtain ⟨block, _, d, _, hv⟩ := hv
        rcases hv with rfl | rfl
        · rw [ih (ρ.part block Side.lower (d + 1)) hρ,
            ih (ρ.part (ρ.childPositions.filter (· ∉ block)) Side.upper
              (ρ.k - 1 - (d + 1))) hρ]
        · rw [ih (ρ.part block Side.upper (ρ.k - 1 - (d + 1))) hρ,
            ih (ρ.part (ρ.childPositions.filter (· ∉ block)) Side.lower (d + 1)) hρ]
  exact ⟨fun fuel => hFuel fuel σ hzero, hFuel _ σ hzero⟩
