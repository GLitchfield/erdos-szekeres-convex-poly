"""Root singleton attainment at a minimum active chosen-axis point.

Finite diagnostic only. Reuses root generation, point-limit semantics and
compiled bounds. Complete declared ranges finish even after a counterexample.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from decomposable_depth2_tables import limits_from_signature
from decomposable_recursive_formula import run_index
from probe_singleton_normal import root_words, singleton_values


def audit(bound, a, u, k, word, maxima):
    value = bound(word, maxima)
    if value == 0:
        return None, True
    _, cups, caps = limits_from_signature(word, maxima, a, u, k, lean=True)
    indexes = run_index(word)
    side = next(x[1] for x in word if x != "S")
    active = [p for p, r in enumerate(indexes)
              if r is not None and cups[r, r] > 0 and caps[r, r] > 0]
    if not active:
        return {"a": a, "u": u, "k": k, "word": word,
                "maxima": maxima, "bound": value, "failure": "positive bound without active point"}, False
    chosen = cups if side == "lower" else caps
    minimum = min(int(chosen[indexes[p], indexes[p]]) for p in active)
    selected = {p for p in active if chosen[indexes[p], indexes[p]] == minimum}
    choices = singleton_values(bound, k, word, maxima)
    best = max(c for c in choices if c[1] in selected)
    if best[0] >= value:
        return None, False
    return {"a": a, "u": u, "k": k, "word": word, "maxima": maxima,
            "side": side, "bound": value, "minimum": minimum,
            "selected": sorted(selected), "best_selected": best,
            "best_unrestricted": max(choices)}, False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--a-list", required=True)
    parser.add_argument("--u-list", required=True)
    parser.add_argument("--max-runs", type=int, default=3)
    parser.add_argument("--max-len", type=int, default=2)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    avals = list(map(int, args.a_list.split(",")))
    uvals = list(map(int, args.u_list.split(",")))
    words = list(root_words(args.max_runs, args.max_len, args.max_children))
    total = len(avals) * len(uvals) * (args.k - 2) * len(words)
    started = time.monotonic()
    checked = zero = 0
    failures = []
    for a in avals:
        for u in uvals:
            bound = compiled_evaluator(a, u, args.k, cache_size=2_000_000, persistent=True)
            try:
                for m in range(1, args.k - 1):
                    for word in words:
                        failure, trivial = audit(bound, a, u, args.k, word, (m,))
                        checked += 1
                        zero += trivial
                        if failure:
                            failures.append(failure)
                    elapsed = time.monotonic() - started
                    print(json.dumps({"done": checked, "total": total,
                                      "elapsed": elapsed, "rate": checked / elapsed,
                                      "zero_bounds": zero, "failures": len(failures)}), flush=True)
            finally:
                bound.close()
    Path(args.out).write_text(json.dumps({"semantics": "context-bound-zero-children-c-v1",
        "candidate": "minimum-active-chosen-axis-singleton-attainment-v1", "args": vars(args),
        "checked": checked, "zero_bounds": zero,
        "seconds": time.monotonic() - started, "failures": failures}, indent=2) + "\n")
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
