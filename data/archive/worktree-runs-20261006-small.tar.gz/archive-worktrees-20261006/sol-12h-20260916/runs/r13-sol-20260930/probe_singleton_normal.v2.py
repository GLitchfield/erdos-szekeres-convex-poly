"""Diagnostic singleton-cut normal form for one-level roots; no Lean credit.

Compare bound(word) with every singleton cut, including both orientations and
all admissible couplings. Words have one marker between runs and optional
single markers at each end. Include all run lengths 1..max_len, with an
explicit total-child cap. This tests normal form, not C1r itself.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from decomposable_additivity_test import child


def root_words(max_runs, max_len, max_children):
    for side in ("lower", "upper"):
        marker = (1, side)
        for runs in range(2, max_runs + 1):
            for lengths in itertools.product(range(1, max_len + 1), repeat=runs):
                if sum(lengths) > max_children:
                    continue
                for left, right in itertools.product((0, 1), repeat=2):
                    word = [marker] * left
                    for i, length in enumerate(lengths):
                        if i:
                            word.append(marker)
                        word.extend(["S"] * length)
                    yield tuple(word + [marker] * right)


def singleton_values(bound, k, word, maxima):
    children = frozenset(i for i, x in enumerate(word) if x == "S")
    values = []
    for p in sorted(children):
        for d in range(1, k - 1):
            for side, maximum in (("lower", d), ("upper", k - 1 - d)):
                other = "upper" if side == "lower" else "lower"
                value = bound(*child(word, maxima, {p}, side, maximum))
                value += bound(*child(word, maxima, children - {p}, other, k - 1 - maximum))
                values.append((value, p, side, maximum))
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--a-list", required=True)
    parser.add_argument("--u-list", required=True)
    parser.add_argument("--max-runs", type=int, default=2)
    parser.add_argument("--max-len", type=int, default=2)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--cache-size", type=int, default=2000000)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    avals = list(map(int, args.a_list.split(",")))
    uvals = list(map(int, args.u_list.split(",")))
    words = list(root_words(args.max_runs, args.max_len, args.max_children))
    total = len(avals) * len(uvals) * (args.k - 2) * len(words)
    started = time.monotonic()
    checked = end_failures = 0
    failures = []
    for a in avals:
        for u in uvals:
            bound = compiled_evaluator(a, u, args.k, cache_size=args.cache_size, persistent=True)
            try:
                for m in range(1, args.k - 1):
                    for word in words:
                        value = bound(word, (m,))
                        choices = singleton_values(bound, args.k, word, (m,))
                        best = max(choices)
                        children = sorted(i for i, x in enumerate(word) if x == "S")
                        best_end = max(v for v, p, _, _ in choices if p in (children[0], children[-1]))
                        end_failures += best_end < value
                        checked += 1
                        if best[0] < value:
                            failures.append({"a": a, "u": u, "k": args.k, "m": m,
                                             "word": word, "bound": value, "best_singleton": best})
                    elapsed = time.monotonic() - started
                    print(json.dumps({"done": checked, "total": total, "a": a, "u": u, "m": m,
                                      "elapsed": elapsed, "rate": checked / elapsed,
                                      "failures": len(failures), "end_failures": end_failures}), flush=True)
            finally:
                bound.close()
    Path(args.out).write_text(json.dumps({"semantics": "context-bound-zero-children-c-v1",
                                         "args": vars(args), "checked": checked,
                                         "seconds": time.monotonic() - started,
                                         "end_failures": end_failures, "failures": failures}, indent=2) + "\n")
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
