"""Diagnostic general-context singleton normal form; no kernel credit.

Reuse the bounded context generator and the singleton-cut implementation.
The --limit prefix is an explicitly declared smoke sample, not a deadline.
All admitted cases complete; progress reports per 32 cases.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from decomposable_additivity_test import contexts
from decomposable_recursive_formula import run_index
from probe_singleton_normal import singleton_values

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", default="3,4,5")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--children", type=int, default=4)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    a, u, k = map(int, args.case.split(","))
    fixture = (( (1, "lower"), "S", "S", (2, "upper"), "S", "S"), (3, 1))
    cases = [fixture]
    cases.extend((w, m) for w, m in contexts(args.children, 2, 2, k, include_unused_levels=True)
                 if w.count("S") == args.children and len({r for r in run_index(w) if r is not None}) >= 2)
    cases = cases[args.offset:]
    if args.limit:
        cases = cases[:args.limit]
    start = time.monotonic()
    failures = []
    bound = compiled_evaluator(a, u, k, cache_size=500000, persistent=True)
    try:
        for done, (word, maxima) in enumerate(cases, 1):
            value = bound(word, maxima)
            choices = singleton_values(bound, k, word, maxima)
            best = max(choices)
            if best[0] < value:
                failures.append({"word": word, "maxima": maxima, "bound": value,
                                 "best_singleton": best})
            if done % 32 == 0 or done == len(cases):
                elapsed = time.monotonic() - start
                print(json.dumps({"done": done, "total": len(cases), "elapsed": elapsed,
                                  "rate": done / elapsed, "failures": len(failures)}), flush=True)
    finally:
        bound.close()
    Path(args.out).write_text(json.dumps({"semantics": "context-bound-zero-children-c-v1",
        "args": vars(args), "checked": len(cases), "seconds": time.monotonic() - start,
        "failures": failures}, indent=2) + "\n")
    return 2 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main())
