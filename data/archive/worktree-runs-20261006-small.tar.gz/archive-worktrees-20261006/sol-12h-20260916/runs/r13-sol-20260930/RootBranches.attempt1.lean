import ESBlueprint.B.CtxNumRunsChildLetterContraction
import ESBlueprint.B.CtxBoundChildLetterExpansion

namespace ErdosSzekeres
open Ctx Ctx.Context

-- The single-run branch needs no well-formedness.
example (σ : Context) (left right : List Letter)
    (hword : σ.word = left ++ [Letter.child, Letter.child] ++ right)
    (hruns : σ.numRuns ≤ 1) :
    σ.bound = ({ σ with word := left ++ [Letter.child] ++ right } : Context).bound := by
  have hsame := ctx_num_runs_child_letter_contraction σ left right hword
  have hsmall : ({ σ with word := left ++ [Letter.child] ++ right } : Context).numRuns ≤ 1 := by
    omega
  simp only [Context.bound, boundFuel.eq_2, if_pos hruns, if_pos hsmall]
  exact ctx_base_child_letter_contraction σ left right hword

-- Capacity parameters at least two make a one-level uniform word well formed.
example (a u k m : ℕ) (ha : 2 ≤ a) (hu : 2 ≤ u) (hak : a ≤ k) (huk : u ≤ k)
    (hm : 1 ≤ m) (hmk : m ≤ k - 2) (s : Side) (word : List Letter)
    (hletters : ∀ x ∈ word, x = Letter.child ∨ x = Letter.ext 1 s) :
    ({a := a, u := u, k := k, word := word, maxima := [m]} : Context).WellFormed := by
  classical
  let σ : Context := {a := a, u := u, k := k, word := word, maxima := [m]}
  have hshape : ∀ p l t, σ.letterAt p = Letter.ext l t → l = 1 ∧ t = s := by
    intro p l t hext
    have hp : p < σ.word.length := by
      by_contra hn
      have h := letterAt_of_length_le σ (Nat.le_of_not_gt hn)
      rw [h] at hext
      cases hext
    have hmem : Letter.ext l t ∈ word := by
      have hget : σ.word[p] = Letter.ext l t := by
        simpa [letterAt, hp] using hext
      rw [← hget]
      exact List.getElem_mem _
    rcases hletters _ hmem with h | h
    · cases h
    · cases h
      exact ⟨rfl, rfl⟩
  refine ⟨ha, hu, hak, huk, ?_, ?_⟩
  · intro n hn
    simp only [σ, List.mem_singleton] at hn
    subst n
    exact ⟨hm, hmk⟩
  · intro p l t hext
    obtain ⟨rfl, rfl⟩ := hshape p l t hext
    refine ⟨by omega, by simp [σ], ?_⟩
    have hpExt : p ∈ σ.extPositions 1 := by
      have hp : p < σ.word.length := by
        by_contra hn
        have h := letterAt_of_length_le σ (Nat.le_of_not_gt hn)
        rw [h] at hext
        cases hext
      simp [extPositions, hp, hext]
    cases hh : (σ.extPositions 1).head? with
    | none =>
      have hn := List.head?_eq_none_iff.mp hh
      rw [hn] at hpExt
      simp at hpExt
    | some q =>
      have hq := List.mem_of_mem_head? hh
      have hqe := (List.mem_filter.mp hq).2
      cases hl : σ.letterAt q with
      | child => simp [hl] at hqe
      | ext j v =>
        obtain ⟨rfl, rfl⟩ := hshape q j v hl
        simp [sideAt, hh, hl]

end ErdosSzekeres
