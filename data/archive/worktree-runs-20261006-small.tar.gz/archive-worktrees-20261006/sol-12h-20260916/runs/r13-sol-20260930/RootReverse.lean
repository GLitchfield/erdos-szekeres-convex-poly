import ESBlueprint.B.CtxBoundZeroOfUnitGlobalAxis
import ESBlueprint.B.CtxBoundChildLetterExpansion

namespace ErdosSzekeres
open Ctx Ctx.Context

-- The reverse inequality of C1r, including its raw a/u=1 boundary.
example (a u k m : ℕ) (ha : 1 ≤ a) (hak : a ≤ k) (hu : 1 ≤ u) (huk : u ≤ k)
    (hm : 1 ≤ m) (hmk : m ≤ k - 2) (side : Side) (left right : List Letter)
    (hletters : ∀ x ∈ left ++ right, x = Letter.child ∨ x = Letter.ext 1 side) :
    ({a := a, u := u, k := k, word := left ++ [Letter.child] ++ right,
      maxima := [m]} : Context).bound ≤
    ({a := a, u := u, k := k, word := left ++ [Letter.child, Letter.child] ++ right,
      maxima := [m]} : Context).bound := by
  classical
  let σ : Context := {a := a, u := u, k := k, word := left ++ [Letter.child, Letter.child] ++ right, maxima := [m]}
  let ρ : Context := {σ with word := left ++ [Letter.child] ++ right}
  change ρ.bound ≤ σ.bound
  by_cases hzero : a ≤ 1 ∨ u ≤ 1
  · have hb := (ctx_bound_zero_of_unit_global_axis σ hzero).2
    have hs := (ctx_bound_zero_of_unit_global_axis ρ hzero).2
    rw [hb, hs]
  · have ha2 : 2 ≤ a := by omega
    have hu2 : 2 ≤ u := by omega
    have hWF : ∀ w : List Letter,
        (∀ x ∈ w, x = Letter.child ∨ x = Letter.ext 1 side) →
        ({a := a, u := u, k := k, word := w, maxima := [m]} : Context).WellFormed := by
      intro w hw
      let τ : Context := {a := a, u := u, k := k, word := w, maxima := [m]}
      have hshape : ∀ p l t, τ.letterAt p = Letter.ext l t → l = 1 ∧ t = side := by
        intro p l t hext
        have hp : p < τ.word.length := by
          by_contra hn
          have h := letterAt_of_length_le τ (Nat.le_of_not_gt hn)
          rw [h] at hext
          cases hext
        have hmem : Letter.ext l t ∈ w := by
          have hget : τ.word[p] = Letter.ext l t := by
            simpa [letterAt, hp] using hext
          rw [← hget]
          exact List.getElem_mem _
        rcases hw _ hmem with h | h
        · cases h
        · cases h
          exact ⟨rfl, rfl⟩
      refine ⟨ha2, hu2, hak, huk, ?_, ?_⟩
      · intro n hn
        simp only [List.mem_singleton] at hn
        subst n
        exact ⟨hm, hmk⟩
      · intro p l t hext
        change τ.letterAt p = Letter.ext l t at hext
        obtain ⟨rfl, rfl⟩ := hshape p l t hext
        refine ⟨by omega, by simp, ?_⟩
        have hpExt : p ∈ τ.extPositions 1 := by
          have hp : p < τ.word.length := by
            by_contra hn
            have h := letterAt_of_length_le τ (Nat.le_of_not_gt hn)
            rw [h] at hext
            cases hext
          simp [extPositions, hp, hext]
        cases hh : (τ.extPositions 1).head? with
        | none =>
          have hn := List.head?_eq_none_iff.mp hh
          rw [hn] at hpExt
          simp at hpExt
        | some q =>
          have hq := List.mem_of_mem_head? hh
          have hqe := (List.mem_filter.mp hq).2
          cases hl : τ.letterAt q with
          | child => simp [hl] at hqe
          | ext j v =>
            obtain ⟨rfl, rfl⟩ := hshape q j v hl
            change v = τ.sideAt 1
            simp [sideAt, hh, hl]
    have hσletters : ∀ x ∈ σ.word, x = Letter.child ∨ x = Letter.ext 1 side := by
      intro x hx
      by_cases hc : x = Letter.child
      · exact Or.inl hc
      · apply hletters x
        simpa [σ, hc, List.mem_append] using hx
    exact ctx_bound_child_letter_expansion σ (hWF _ hσletters) left right rfl

end ErdosSzekeres
