"""A small closure diagnostic for unrestricted singleton attainment.

Balanced four-child words, all eight uniform per-level side patterns and
six external level orders, every sibling maximum. No claim of complete three-level
coverage or Lean theorem credit.
"""
from __future__ import annotations
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from harness.research.context_bound import compiled_evaluator
from probe_singleton_normal import singleton_values


def main():
    a, u, k = 5, 5, 6
    output = Path(sys.argv[1])
    patterns = itertools.product(("lower", "upper"), repeat=3)
    orders = list(itertools.permutations(range(1, 4)))
    cases = [(tuple(["S", "S"] + [(i, sides[i - 1]) for i in order] + ["S", "S"]), maxima)
             for sides in patterns for order in orders
             for maxima in itertools.product(range(1, k - 1), repeat=3)]
    start = time.monotonic()
    failures = []
    bound = compiled_evaluator(a, u, k, cache_size=2_000_000, persistent=True)
    try:
        for done, (word, maxima) in enumerate(cases, 1):
            value = bound(word, maxima)
            choices = singleton_values(bound, k, word, maxima)
            best = max(choices)
            if best[0] < value:
                failures.append({"word": word, "maxima": maxima,
                                 "bound": value, "best_singleton": best})
            if done % 8 == 0 or done == len(cases):
                elapsed = time.monotonic() - start
                print(json.dumps({"done": done, "total": len(cases), "elapsed": elapsed,
                                  "rate": done / elapsed, "failures": len(failures)}), flush=True)
    finally:
        bound.close()
    output.write_text(json.dumps({"semantics": "context-bound-zero-children-c-v1",
        "candidate": "unrestricted-singleton-attainment-balanced-three-level-all-orders-v2",
        "case": [a, u, k], "checked": len(cases), "seconds": time.monotonic() - start,
        "failures": failures}, indent=2) + "\n")
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
