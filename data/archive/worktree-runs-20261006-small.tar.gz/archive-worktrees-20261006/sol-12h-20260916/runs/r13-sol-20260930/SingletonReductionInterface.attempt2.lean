import ESBlueprint.B.CtxSingletonPartBoundEqThreshold
import ESBlueprint.B.CtxBoundAttainedByEndCut

namespace ErdosSzekeres
open Ctx Ctx.Context

-- N is deliberately explicit. This is not C1r-from-X alone.
example (σ ρ : Context) (hruns : 2 ≤ ρ.numRuns)
    (hN : ∃ p ∈ σ.childPositions, ∃ (s : Side) (c : ℕ),
      1 ≤ c ∧ c ≤ σ.k - 2 ∧
      σ.bound ≤ decomposableThreshold ((σ.part [p] s c).capLimit p p + 1)
        ((σ.part [p] s c).cupLimit p p + 1) σ.k +
        (σ.part (σ.childPositions.filter (fun r => r ≠ p))
          (match s with | Side.lower => Side.upper | Side.upper => Side.lower)
          (σ.k - 1 - c)).bound)
    (hX : ∀ p ∈ σ.childPositions, ∀ (s : Side) (c : ℕ),
      1 ≤ c → c ≤ σ.k - 2 →
      ∃ q ∈ ρ.childPositions, ∃ (t : Side) (d : ℕ), 1 ≤ d ∧ d ≤ ρ.k - 2 ∧
        decomposableThreshold ((σ.part [p] s c).capLimit p p + 1)
          ((σ.part [p] s c).cupLimit p p + 1) σ.k +
          (σ.part (σ.childPositions.filter (fun r => r ≠ p))
            (match s with | Side.lower => Side.upper | Side.upper => Side.lower)
            (σ.k - 1 - c)).bound ≤
        decomposableThreshold ((ρ.part [q] t d).capLimit q q + 1)
          ((ρ.part [q] t d).cupLimit q q + 1) ρ.k +
          (ρ.part (ρ.childPositions.filter (fun r => r ≠ q))
            (match t with | Side.lower => Side.upper | Side.upper => Side.lower)
            (ρ.k - 1 - d)).bound) : σ.bound ≤ ρ.bound := by
  classical
  obtain ⟨p, hp, s, c, hc, hck, hN⟩ := hN
  obtain ⟨q, hq, t, d, hd, hdk, hX⟩ := hX p hp s c hc hck
  have hn : 2 ≤ ρ.childPositions.length := hruns.trans (numRuns_le_length ρ)
  have hb : [q] ∈ ρ.blocks := by
    obtain ⟨i, hi, hqi⟩ := List.mem_iff_getElem.mp hq
    have hwindow : (ρ.childPositions.drop i).take 1 = [q] := by
      simpa only [List.get_eq_getElem, hqi] using List.take_one_drop_eq_of_lt_length hi
    unfold blocks
    apply List.mem_filter.mpr
    refine ⟨?_, by simpa using hn⟩
    apply List.mem_flatMap.mpr
    refine ⟨i, List.mem_range.mpr hi, ?_⟩
    apply List.mem_map.mpr
    exact ⟨0, List.mem_range.mpr (by omega), hwindow⟩
  have hcut : decomposableThreshold ((ρ.part [q] t d).capLimit q q + 1)
      ((ρ.part [q] t d).cupLimit q q + 1) ρ.k +
      (ρ.part (ρ.childPositions.filter (fun r => r ≠ q))
        (match t with | Side.lower => Side.upper | Side.upper => Side.lower)
        (ρ.k - 1 - d)).bound ≤ ρ.bound := by
    clear hX
    rw [← ctx_singleton_part_bound_eq_threshold ρ q hq t d]
    cases t with
    | lower =>
      simpa only [List.mem_singleton] using (ctx_bound_cut_le ρ hruns [q] hb d hd hdk).1
    | upper =>
      have he1 : 1 ≤ ρ.k - 1 - d := by omega
      have hek : ρ.k - 1 - d ≤ ρ.k - 2 := by omega
      have he : ρ.k - 1 - (ρ.k - 1 - d) = d := by omega
      simpa only [List.mem_singleton, he] using
        (ctx_bound_cut_le ρ hruns [q] hb (ρ.k - 1 - d) he1 hek).2
  exact hN.trans (hX.trans hcut)

end ErdosSzekeres
