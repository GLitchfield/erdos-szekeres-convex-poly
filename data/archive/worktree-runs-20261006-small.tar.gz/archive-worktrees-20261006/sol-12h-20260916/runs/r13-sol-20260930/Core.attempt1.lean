import ESBlueprint.B.CtxBoundAttainedByEndCut

namespace ErdosSzekeres

open Ctx Ctx.Context

-- C1r permits a or u to be one, outside Context.WellFormed.
example (σ : Context) (hzero : σ.a ≤ 1 ∨ σ.u ≤ 1) : σ.bound = 0 := by
  have hBase : ∀ (ρ : Context), ρ.a ≤ 1 ∨ ρ.u ≤ 1 → ρ.base = 0 := by
    intro ρ hρ
    cases hp : ρ.childPositions.head? with
    | none => simp [base, hp]
    | some p =>
      rcases hρ with ha | hu
      · have hz : ρ.a - 1 = 0 := by omega
        simp [base, hp, capLimit, hz]
      · have hz : ρ.u - 1 = 0 := by omega
        simp [base, hp, cupLimit, hz]
  have hFuel : ∀ fuel (ρ : Context), ρ.a ≤ 1 ∨ ρ.u ≤ 1 → boundFuel fuel ρ = 0 := by
    intro fuel
    induction fuel with
    | zero => intro ρ _; rfl
    | succ fuel ih =>
      intro ρ hρ
      rw [boundFuel.eq_2]
      by_cases hr : ρ.numRuns ≤ 1
      · rw [if_pos hr]
        exact hBase ρ hρ
      · rw [if_neg hr]
        apply Nat.eq_zero_of_le_zero
        apply getD_max?_le
        intro value hv
        simp only [List.mem_flatMap, List.mem_range, List.mem_cons,
          List.not_mem_nil, or_false] at hv
        obtain ⟨block, _, d, _, hv⟩ := hv
        rcases hv with rfl | rfl
        all_goals
          rw [ih _ hρ, ih _ hρ]
          exact le_rfl
  exact hFuel _ σ hzero

-- Upper half of the defining recurrence; needs no well-formedness hypothesis.
example (σ : Context) (hruns : 2 ≤ σ.numRuns) (B : ℕ)
    (hcuts : ∀ block ∈ σ.blocks, ∀ d, 1 ≤ d → d ≤ σ.k - 2 →
      (σ.part block Side.lower d).bound +
          (σ.part (σ.childPositions.filter (· ∉ block)) Side.upper (σ.k - 1 - d)).bound ≤ B ∧
      (σ.part block Side.upper (σ.k - 1 - d)).bound +
          (σ.part (σ.childPositions.filter (· ∉ block)) Side.lower d).bound ≤ B) :
    σ.bound ≤ B := by
  unfold Context.bound
  rw [boundFuel.eq_2, if_neg (by omega : ¬ σ.numRuns ≤ 1)]
  apply getD_max?_le
  intro value hv
  simp only [List.mem_flatMap, List.mem_range, List.mem_cons,
    List.not_mem_nil, or_false] at hv
  obtain ⟨block, hb, d, hd, hv⟩ := hv
  have hfB : ∀ s m, (σ.part block s m).childPositions.length + 1 ≤
      σ.childPositions.length := by
    intro s m
    exact part_childPositions_length_lt_of_mem_blocks hb s m
  have hfR : ∀ s m,
      (σ.part (σ.childPositions.filter (· ∉ block)) s m).childPositions.length + 1 ≤
        σ.childPositions.length := by
    intro s m
    exact part_rest_childPositions_length_lt_of_mem_blocks hb s m
  rcases hv with rfl | rfl
  · rw [boundFuel_eq_bound _ (hfB _ _), boundFuel_eq_bound _ (hfR _ _)]
    exact (hcuts block hb (d + 1) (by omega) (by omega)).1
  · rw [boundFuel_eq_bound _ (hfB _ _), boundFuel_eq_bound _ (hfR _ _)]
    exact (hcuts block hb (d + 1) (by omega) (by omega)).2

end ErdosSzekeres
