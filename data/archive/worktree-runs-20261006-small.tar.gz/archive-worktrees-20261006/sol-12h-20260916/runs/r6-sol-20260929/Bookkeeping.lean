import ESBlueprint.B.CtxBoundExternalLetterContraction
import ESBlueprint.B.CtxBaseChildLetterContraction
import Mathlib.Data.List.Chain

namespace ErdosSzekeres

open Ctx Ctx.Context

set_option maxHeartbeats 4000000

-- Search: Boolean list compress adjacent repetitions alternating parity (no duplicate).
example (bs : List Bool) :
    (∃ (pre : List Bool) (b : Bool) (post : List Bool), bs = pre ++ b :: b :: post) ∨
      (∃ r : ℕ, r < 2 ∧ ∀ i (hi : i < bs.length), bs[i] = decide (i % 2 = r)) := by
  classical
  by_cases hc : bs.IsChain (· ≠ ·)
  · right
    cases bs with
    | nil => exact ⟨0, by omega, by simp⟩
    | cons b tl =>
      refine ⟨if b then 0 else 1, by cases b <;> simp, ?_⟩
      intro i
      induction i with
      | zero => intro hi; cases b <;> simp
      | succ i ih =>
        intro hi
        have hprev : i < (b :: tl).length := by omega
        have hne := (List.isChain_iff_getElem.mp hc) i hi
        rw [ih hprev] at hne
        have hmod : (i + 1) % 2 = 1 - i % 2 := by omega
        have hlt : i % 2 < 2 := Nat.mod_lt i (by omega)
        cases he : (b :: tl)[i + 1] <;> cases b <;> simp_all [hmod] <;> omega
  · left
    have hn := List.isChain_iff_forall_rel_of_append_cons_cons.not.mp hc
    push Not at hn
    obtain ⟨a, b, pre, post, heq, hab⟩ := hn
    have he : a = b := by simpa using hab
    subst b
    exact ⟨pre, a, post, heq⟩

-- Search: span in parts of contiguous child word (no duplicate).
example (σ : Context) (keep : List ℕ) (s : Side) (m b n : ℕ)
    (hpos : σ.childPositions = List.range' b n) :
    ∀ i ∈ (σ.part keep s m).childPositions,
      ∀ j ∈ (σ.part keep s m).childPositions, ∀ l : ℕ, i < l → l < j →
        (σ.part keep s m).letterAt l = Letter.child ∨
          (σ.part keep s m).letterAt l = Letter.ext 1 s := by
  intro i hi j hj l hil hlj
  rw [part_childPositions] at hi hj
  have hi' := (List.mem_filter.mp hi).1
  have hj' := (List.mem_filter.mp hj).1
  rw [hpos, List.mem_range'_1] at hi' hj'
  have hl : l ∈ σ.childPositions := by rw [hpos, List.mem_range'_1]; omega
  have hlw : l < σ.word.length := List.mem_range.mp (List.mem_filter.mp hl).1
  have hlc : σ.letterAt l = Letter.child := of_decide_eq_true (List.mem_filter.mp hl).2
  rw [part_letterAt_of_child σ keep s m hlw hlc]
  split_ifs <;> simp

end ErdosSzekeres
