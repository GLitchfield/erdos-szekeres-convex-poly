import ErdosSzekeres.DecomposableContext

namespace ErdosSzekeres

/-- C3 (proposed): single-run additivity for alternating singleton partitions. -/
theorem ctx_bound_additive_single_run_alternating (σ : Ctx.Context) (hwf : σ.WellFormed)
    (hruns : σ.numRuns ≤ 1) (h2 : 2 ≤ σ.childPositions.length) (r : ℕ) (hr : r < 2)
    (d : ℕ) (hd : 1 ≤ d) (hdk : d ≤ σ.k - 2) :
    let keep := ((List.range σ.childPositions.length).filter (fun i => i % 2 = r)).map
      (fun i => σ.childPositions.getD i 0)
    (σ.part keep Ctx.Side.lower d).bound +
        (σ.part (σ.childPositions.filter (fun p => p ∉ keep)) Ctx.Side.upper (σ.k - 1 - d)).bound
          ≤ σ.bound ∧
      (σ.part keep Ctx.Side.upper (σ.k - 1 - d)).bound +
        (σ.part (σ.childPositions.filter (fun p => p ∉ keep)) Ctx.Side.lower d).bound ≤ σ.bound := by
  sorry

/-- Glue (proposed): single-run additivity from run contraction under level-one spans (C1) and the
alternating case (C3), both explicit hypotheses. -/
theorem ctx_bound_additive_single_run_of_run_contraction_and_alternating
    (hcontract : ∀ (τ : Ctx.Context), τ.WellFormed → ∀ (side : Ctx.Side) (left right : List Ctx.Letter),
      τ.word = left ++ [Ctx.Letter.child, Ctx.Letter.child] ++ right →
      (∀ i ∈ τ.childPositions, ∀ j ∈ τ.childPositions, ∀ l : ℕ, i < l → l < j →
        τ.letterAt l = Ctx.Letter.child ∨ τ.letterAt l = Ctx.Letter.ext 1 side) →
      τ.bound = ({ τ with word := left ++ [Ctx.Letter.child] ++ right } : Ctx.Context).bound)
    (halternating : ∀ (τ : Ctx.Context), τ.WellFormed → τ.numRuns ≤ 1 → 2 ≤ τ.childPositions.length →
      ∀ (r : ℕ), r < 2 → ∀ (d : ℕ), 1 ≤ d → d ≤ τ.k - 2 →
      let keep := ((List.range τ.childPositions.length).filter (fun i => i % 2 = r)).map
        (fun i => τ.childPositions.getD i 0)
      (τ.part keep Ctx.Side.lower d).bound +
          (τ.part (τ.childPositions.filter (fun p => p ∉ keep)) Ctx.Side.upper (τ.k - 1 - d)).bound
            ≤ τ.bound ∧
        (τ.part keep Ctx.Side.upper (τ.k - 1 - d)).bound +
          (τ.part (τ.childPositions.filter (fun p => p ∉ keep)) Ctx.Side.lower d).bound ≤ τ.bound)
    (σ : Ctx.Context) (hwf : σ.WellFormed) (hruns : σ.numRuns ≤ 1) (keep : List ℕ)
    (hkeep : ∀ p ∈ keep, p ∈ σ.childPositions) (hne : keep ≠ [])
    (hall : keep.length < σ.childPositions.length) (d : ℕ) (hd : 1 ≤ d) (hdk : d ≤ σ.k - 2) :
    (σ.part keep Ctx.Side.lower d).bound +
        (σ.part (σ.childPositions.filter (fun p => p ∉ keep)) Ctx.Side.upper (σ.k - 1 - d)).bound
          ≤ σ.bound ∧
      (σ.part keep Ctx.Side.upper (σ.k - 1 - d)).bound +
        (σ.part (σ.childPositions.filter (fun p => p ∉ keep)) Ctx.Side.lower d).bound ≤ σ.bound := by
  sorry

end ErdosSzekeres
