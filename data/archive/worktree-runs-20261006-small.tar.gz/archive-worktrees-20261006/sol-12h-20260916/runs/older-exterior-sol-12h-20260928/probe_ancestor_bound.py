#!/usr/bin/env python3
"""Probe the proposed bound twelve for bare target ancestors.

Exploratory only.  This uses the registered recursive evaluator and does not
assert equivalence to a Lean theorem.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from harness.research.recursive import evaluator  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=9)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=1_000_000,
    )
    tested = 0
    maximum = -1
    maximizers = []
    violations = []
    for child_count in range(3, args.max_children + 1):
        size = child_count + 2
        for ext_positions in itertools.combinations(range(size), 2):
            for level_order in ((1, 2), (2, 1)):
                for s_side in ("lower", "upper"):
                    word = ["S"] * size
                    positions = {}
                    for position, level in zip(ext_positions, level_order):
                        word[position] = (level, s_side)
                        positions[level] = position
                    x, y = positions[1], positions[2]
                    children = [i for i, letter in enumerate(word) if letter == "S"]
                    candidates = [
                        q
                        for q in children
                        if (x < y < q or q < y < x)
                        and any(l < q for l in children if l != q)
                        and any(q < r for r in children if r != q)
                    ]
                    if not candidates:
                        continue
                    word = tuple(word)
                    for maxima in itertools.product((0, 1), repeat=2):
                        value = bound(word, maxima)
                        tested += 1
                        row = {
                            "word": encode(word),
                            "positions": positions,
                            "maxima": maxima,
                            "witness_q": candidates[0],
                            "bound": value,
                        }
                        if value > maximum:
                            maximum = value
                            maximizers = [row]
                        elif value == maximum and len(maximizers) < 64:
                            maximizers.append(row)
                        if value > 12:
                            violations.append(row)
                            print(json.dumps({"violation": row}), flush=True)
                            if len(violations) >= 32:
                                break
                    if len(violations) >= 32:
                        break
                if len(violations) >= 32:
                    break
            if len(violations) >= 32:
                break
        if len(violations) >= 32:
            break
        print(json.dumps({"children": child_count, "tested": tested, "maximum": maximum}), flush=True)

    result = {
        "semantics": "context-bound-zero-children-v1; diagnostic only",
        "candidate": "bare two-marker k6 both-global-five source with selected maxima at most one and an internally bracketed child beyond the older marker has bound at most twelve",
        "max_children": args.max_children,
        "tested": tested,
        "maximum": maximum,
        "maximizers": maximizers,
        "violations": violations,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
