#!/usr/bin/env python3
"""Probe exact low/high pruning bounds in the older-exterior residual.

Exploratory only.  Capacity labels use the registered legacy signature
calculation with ``lean=True`` and bounds use the registered recursive
evaluator; neither gives Lean theorem credit.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from collections import defaultdict
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))

from decomposable_depth2_tables import limits_from_signature  # noqa: E402
from harness.research.recursive import evaluator  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def prune(word, maxima, keep):
    fresh = len(maxima) + 1
    return tuple(
        letter if letter != "S" or position in keep else (fresh, "lower")
        for position, letter in enumerate(word)
    )


def child_runs(word):
    run = -1
    in_run = False
    result = {}
    for position, letter in enumerate(word):
        if letter == "S":
            if not in_run:
                run += 1
                in_run = True
            result[position] = run
        else:
            in_run = False
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=5)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=700_000,
    )
    maxima = (1, 1, 1)
    tested = 0
    maxima_by_shape = defaultdict(lambda: {"sum": -1})
    top = []
    violations = []
    for child_count in range(2, args.max_children + 1):
        size = child_count + 3
        for ext_positions in itertools.combinations(range(size), 3):
            for level_order in itertools.permutations((1, 2, 3)):
                for q_side in ("lower", "upper"):
                    s_side = "upper" if q_side == "lower" else "lower"
                    sides = {1: q_side, 2: s_side, 3: s_side}
                    word = ["S"] * size
                    positions = {}
                    for position, level in zip(ext_positions, level_order):
                        word[position] = (level, sides[level])
                        positions[level] = position
                    q, x, y = positions[1], positions[2], positions[3]
                    if not (q < y < x or x < y < q):
                        continue
                    children = [i for i, letter in enumerate(word) if letter == "S"]
                    if not (any(p < q for p in children) and any(q < p for p in children)):
                        continue
                    word = tuple(word)
                    runs = child_runs(word)
                    _, cups, caps = limits_from_signature(
                        word, maxima, 5, 5, 6, lean=True
                    )
                    capacities = {
                        p: int(caps[runs[p]][runs[p]])
                        if s_side == "upper"
                        else int(cups[runs[p]][runs[p]])
                        for p in children
                    }
                    low = frozenset(p for p in children if capacities[p] <= 2)
                    high = frozenset(p for p in children if capacities[p] >= 3)
                    if not low or not high:
                        continue
                    separated = (
                        q < y < x
                        and all(p < y for p in high)
                        and all(y < p for p in low)
                    ) or (
                        x < y < q
                        and all(p < y for p in low)
                        and all(y < p for p in high)
                    )
                    if not separated:
                        continue
                    low_bound = bound(prune(word, maxima, low), maxima)
                    high_bound = bound(prune(word, maxima, high), maxima)
                    q_left_bound = bound(
                        prune(word, maxima, frozenset(p for p in children if p < q)),
                        maxima,
                    )
                    q_right_bound = bound(
                        prune(word, maxima, frozenset(p for p in children if q < p)),
                        maxima,
                    )
                    refined_groups = {
                        (band, side): frozenset(
                            p
                            for p in children
                            if (0 if capacities[p] <= 2 else 1) == band
                            and (0 if p < q else 1) == side
                        )
                        for band in (0, 1)
                        for side in (0, 1)
                    }
                    refined_bounds = {
                        f"{band}_{side}": bound(prune(word, maxima, group), maxima)
                        for (band, side), group in refined_groups.items()
                    }
                    refined_sum = sum(refined_bounds.values())
                    source_bound = bound(word, maxima)
                    tested += 1
                    high_straddles_q = any(p < q for p in high) and any(q < p for p in high)
                    low_straddles_x = any(p < x for p in low) and any(x < p for p in low)
                    shape = f"high_q_{'split' if high_straddles_q else 'one'}__low_x_{'split' if low_straddles_x else 'one'}"
                    row = {
                        "word": encode(word),
                        "positions": positions,
                        "capacities": capacities,
                        "source": source_bound,
                        "low": low_bound,
                        "high": high_bound,
                        "sum": low_bound + high_bound,
                        "decomposition_slack": low_bound + high_bound - source_bound,
                        "q_left": q_left_bound,
                        "q_right": q_right_bound,
                        "q_sum": q_left_bound + q_right_bound,
                        "q_decomposition_slack": q_left_bound + q_right_bound - source_bound,
                        "refined": refined_bounds,
                        "refined_sum": refined_sum,
                        "refined_decomposition_slack": refined_sum - source_bound,
                        "shape": shape,
                    }
                    if row["sum"] > maxima_by_shape[shape]["sum"]:
                        maxima_by_shape[shape] = row
                    top.append(row)
                    top.sort(key=lambda item: (item["sum"], item["source"]), reverse=True)
                    del top[40:]
                    if row["sum"] > 11:
                        violations.append(row)
                        print(json.dumps({"sum_above_eleven": row}), flush=True)
                    if row["q_sum"] > 11:
                        print(json.dumps({"q_sum_above_eleven": row}), flush=True)
                    if row["refined_sum"] > 11:
                        print(json.dumps({"refined_sum_above_eleven": row}), flush=True)
                    if tested % 50 == 0:
                        print(json.dumps({"checkpoint": tested, **row}), flush=True)
    result = {
        "semantics": "limits_from_signature(..., lean=True) plus context-bound-zero-children-v1; diagnostic only",
        "candidates": [
            "target-separated canonical capacity pruning has low.bound + high.bound <= 11",
            "target-separated spatial pruning at q has left.bound + right.bound <= 11",
            "target-separated capacity-by-q-side four-group pruning has bound sum <= 11",
        ],
        "max_children": args.max_children,
        "tested": tested,
        "maxima_by_shape": dict(maxima_by_shape),
        "violations": violations[:128],
        "top": top,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
