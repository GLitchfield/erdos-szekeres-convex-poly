#!/usr/bin/env python3
"""Falsify the proposed boundary-marker maximum-three bound on small words.

Exploratory only: the retained recursive evaluator is not Lean proof evidence.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from harness.research.recursive import evaluator  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=8)
    args = parser.parse_args()

    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=500_000,
    )
    alphabet = ("S", (1, "upper"), (2, "lower"))
    maxima = (3, 1)
    tested = 0
    counterexamples = []
    for length in range(3, args.max_length + 1):
        for word in itertools.product(alphabet, repeat=length):
            children = [i for i, letter in enumerate(word) if letter == "S"]
            markers = [i for i, letter in enumerate(word) if letter == (2, "lower")]
            if not children or (1, "upper") not in word or not markers:
                continue
            if not any(
                all(p < marker for p in children) or all(marker < p for p in children)
                for marker in markers
            ):
                continue
            tested += 1
            value = bound(word, maxima)
            if value > 3:
                counterexamples.append({"word": encode(word), "bound": value})
                if len(counterexamples) == 20:
                    break
        if counterexamples:
            break
    result = {
        "semantics": "context-bound-zero-children-v1; exploratory only",
        "candidate": "k=6, globals=(5,5), level 1 upper maximum 3, actual level 2 lower marker, all children on one side of one such marker implies bound <= 3",
        "max_length": args.max_length,
        "tested": tested,
        "counterexamples": counterexamples,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
