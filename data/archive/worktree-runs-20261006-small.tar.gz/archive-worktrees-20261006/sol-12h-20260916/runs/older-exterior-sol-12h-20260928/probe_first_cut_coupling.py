#!/usr/bin/env python3
"""Classify exact first-cut charges in small older-exterior companions.

Exploratory only.  This uses the registered recursive evaluator and does not
assert equivalence to a Lean theorem.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from collections import defaultdict
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))

from decomposable_additivity_test import child  # noqa: E402
from harness.research.recursive import evaluator  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def straddles(positions, pivot):
    return any(p < pivot for p in positions) and any(pivot < p for p in positions)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=750_000,
    )
    maxima = (1, 1, 1)
    summaries = defaultdict(lambda: {"tested": 0, "maximum": -1, "examples": []})
    violations = []
    contexts = 0
    cuts = 0
    for child_count in range(3, args.max_children + 1):
        size = child_count + 3
        for ext_positions in itertools.combinations(range(size), 3):
            for level_order in itertools.permutations((1, 2, 3)):
                positions = {
                    level: position
                    for position, level in zip(ext_positions, level_order)
                }
                q, x, y = positions[1], positions[2], positions[3]
                if not (q < y < x or x < y < q):
                    continue
                for t in ("lower", "upper"):
                    s = "upper" if t == "lower" else "lower"
                    word = ["S"] * size
                    word[q] = (1, t)
                    word[x] = (2, s)
                    word[y] = (3, s)
                    word = tuple(word)
                    children = [p for p, letter in enumerate(word) if letter == "S"]
                    if not straddles(children, q):
                        continue
                    contexts += 1
                    for i in range(len(children)):
                        for j in range(i, len(children)):
                            if i == 0 and j == len(children) - 1:
                                continue
                            keep = frozenset(children[i : j + 1])
                            rest = frozenset(children) - keep
                            for s_maximum in range(1, 5):
                                t_maximum = 5 - s_maximum
                                s_word, s_maxima = child(
                                    word, maxima, keep, s, s_maximum
                                )
                                t_word, t_maxima = child(
                                    word, maxima, rest, t, t_maximum
                                )
                                s_bound = bound(s_word, s_maxima)
                                t_bound = bound(t_word, t_maxima)
                                total = s_bound + t_bound
                                cuts += 1
                                key = (
                                    s_maximum,
                                    t_maximum,
                                    straddles(keep, q),
                                    straddles(rest, q),
                                )
                                summary = summaries[key]
                                summary["tested"] += 1
                                row = {
                                    "word": encode(word),
                                    "positions": positions,
                                    "keep": sorted(keep),
                                    "rest": sorted(rest),
                                    "s_maximum": s_maximum,
                                    "t_maximum": t_maximum,
                                    "keep_straddles_q": key[2],
                                    "rest_straddles_q": key[3],
                                    "s_bound": s_bound,
                                    "t_bound": t_bound,
                                    "total": total,
                                }
                                if total > summary["maximum"]:
                                    summary["maximum"] = total
                                    summary["examples"] = [row]
                                elif total == summary["maximum"] and len(summary["examples"]) < 8:
                                    summary["examples"].append(row)
                                if total > 11:
                                    violations.append(row)
                                    print(json.dumps({"violation": row}), flush=True)
                                    if len(violations) >= 32:
                                        break
                            if len(violations) >= 32:
                                break
                        if len(violations) >= 32:
                            break
                    if len(violations) >= 32:
                        break
                if len(violations) >= 32:
                    break
            if len(violations) >= 32:
                break
        print(
            json.dumps(
                {
                    "children": child_count,
                    "contexts": contexts,
                    "cuts": cuts,
                    "violations": len(violations),
                }
            ),
            flush=True,
        )
        if len(violations) >= 32:
            break

    result = {
        "semantics": "context-bound-zero-children-v1; diagnostic only",
        "candidate": "all first cuts of an exact three-marker older-exterior companion sum to at most eleven",
        "max_children": args.max_children,
        "contexts": contexts,
        "cuts": cuts,
        "summaries": [
            {
                "s_maximum": key[0],
                "t_maximum": key[1],
                "keep_straddles_q": key[2],
                "rest_straddles_q": key[3],
                **value,
            }
            for key, value in sorted(summaries.items())
        ],
        "violations": violations,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
