"""Diagnostic exact-recursion charges for the clean older-exterior companion.

Exploratory only: this uses the registered context-bound-zero-children-v1
evaluator and does not assert equivalence to Lean.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from harness.research.primitives import extension, part  # noqa: E402
from harness.research.recursive import evaluator  # noqa: E402
from decomposable_depth2_tables import limits_from_signature  # noqa: E402


def point_limits(row: dict) -> dict[int, tuple[int, int]]:
    """Return Lean-semantics point cup/cap limits at each retained child."""
    _, cups, caps = limits_from_signature(
        row["word"], row["maxima"], row["a"], row["u"], row["k"], lean=True,
    )
    run = -1
    previous_child = False
    result = {}
    for position, letter in enumerate(row["word"]):
        if letter == "S":
            if not previous_child:
                run += 1
            result[position] = (int(cups[run][run]), int(caps[run][run]))
            previous_child = True
        else:
            previous_child = False
    return result


def prune(row: dict, kept: frozenset[int]) -> dict:
    """Original-history pruning used by the run-group decomposition theorem."""
    depth = len(row["maxima"])
    word = tuple(
        letter if letter != "S" or position in kept
        else (depth + 1, "lower")
        for position, letter in enumerate(row["word"])
    )
    return {**row, "word": word}


def capacity_pair_supports(
    row: dict, capacity_side: str, rank_side: str,
) -> dict[str, object]:
    """Exact low/high ordered-rank-pair supports used by the Lean theorem."""
    limits = point_limits(row)
    capacity_index = 0 if capacity_side == "lower" else 1
    children = frozenset(limits)
    result: dict[str, object] = {}
    pair_sets = []
    for name, support in (
        ("low", frozenset(p for p in children if limits[p][capacity_index] <= 2)),
        ("high", frozenset(p for p in children if 3 <= limits[p][capacity_index])),
    ):
        group = prune(row, support)
        group_limits = point_limits(group)
        active = frozenset(
            p for p in support if 0 < group_limits[p][0] and 0 < group_limits[p][1]
        )
        pairs = set()
        intervals = {}
        global_rank = group["u"] if rank_side == "lower" else group["a"]
        for p in active:
            left = extension(group["word"], len(group["maxima"]), rank_side, p, True)
            right = extension(group["word"], len(group["maxima"]), rank_side, p, False)
            interval = tuple(range(left + 1, max(left + 1, global_rank - right)))
            intervals[p] = interval
            pairs.update((a, b) for a in interval for b in interval if a <= b)
        pair_sets.append(pairs)
        result[name] = {
            "support": sorted(support),
            "active": sorted(active),
            "intervals": {p: list(intervals[p]) for p in sorted(intervals)},
            "pairs": sorted(pairs),
        }
    result["intersection"] = sorted(pair_sets[0] & pair_sets[1])
    result["card_sum"] = len(pair_sets[0]) + len(pair_sets[1])
    return result


def capacity_pruning_bounds(row: dict, capacity_side: str, bound) -> dict[str, object]:
    """Exact recursive bounds after canonical low/high capacity pruning."""
    limits = point_limits(row)
    capacity_index = 0 if capacity_side == "lower" else 1
    children = frozenset(limits)
    low = frozenset(p for p in children if limits[p][capacity_index] <= 2)
    high = children - low
    low_group = prune(row, low)
    high_group = prune(row, high)
    low_bound = bound(low_group["word"], low_group["maxima"])
    high_bound = bound(high_group["word"], high_group["maxima"])
    return {
        "capacity_side": capacity_side,
        "capacities": {p: limits[p][capacity_index] for p in sorted(children)},
        "low_support": sorted(low),
        "high_support": sorted(high),
        "low_bound": low_bound,
        "high_bound": high_bound,
        "sum": low_bound + high_bound,
    }


def positional_arm_pair_supports(row: dict, pivot: int, rank_side: str) -> dict[str, object]:
    """Ordered-rank-pair supports after splitting children around a pivot."""
    children = frozenset(
        i for i, letter in enumerate(row["word"]) if letter == "S"
    )
    pair_sets = []
    result: dict[str, object] = {}
    for name, support in (
        ("left", frozenset(p for p in children if p < pivot)),
        ("right", frozenset(p for p in children if pivot < p)),
    ):
        group = prune(row, support)
        group_limits = point_limits(group)
        active = frozenset(
            p for p in support if 0 < group_limits[p][0] and 0 < group_limits[p][1]
        )
        global_rank = group["u"] if rank_side == "lower" else group["a"]
        intervals = {}
        pairs = set()
        for p in active:
            left = extension(group["word"], len(group["maxima"]), rank_side, p, True)
            right = extension(group["word"], len(group["maxima"]), rank_side, p, False)
            interval = tuple(range(left + 1, max(left + 1, global_rank - right)))
            intervals[p] = interval
            pairs.update((a, b) for a in interval for b in interval if a <= b)
        pair_sets.append(pairs)
        result[name] = {
            "support": sorted(support),
            "active": sorted(active),
            "intervals": {p: list(intervals[p]) for p in sorted(intervals)},
            "pairs": sorted(pairs),
        }
    result["intersection"] = sorted(pair_sets[0] & pair_sets[1])
    result["card_sum"] = len(pair_sets[0]) + len(pair_sets[1])
    return result


def rank_triple_support(row: dict, rank_side: str) -> dict[str, object]:
    """Active ordered-rank-triple union from the global-five potential."""
    limits = point_limits(row)
    active = frozenset(
        p for p, (cup, cap) in limits.items() if 0 < cup and 0 < cap
    )
    global_rank = row["u"] if rank_side == "lower" else row["a"]
    intervals = {}
    triples = set()
    for p in active:
        left = extension(row["word"], len(row["maxima"]), rank_side, p, True)
        right = extension(row["word"], len(row["maxima"]), rank_side, p, False)
        interval = tuple(range(left + 1, max(left + 1, global_rank - right)))
        intervals[p] = interval
        triples.update(
            (a, b, c)
            for a in interval for b in interval for c in interval
            if a <= b <= c
        )
    return {
        "active": sorted(active),
        "intervals": {p: list(intervals[p]) for p in sorted(intervals)},
        "triples": sorted(triples),
        "card": len(triples),
    }


def minimum_rectangle_partition(
    row: dict, chosen_side: str, opposite_side: str,
) -> dict[str, object]:
    """Minimum thin-rectangle cover cost over active-child set partitions."""
    limits = point_limits(row)
    active = tuple(sorted(
        p for p, (cup, cap) in limits.items() if 0 < cup and 0 < cap
    ))

    def intervals(side: str) -> dict[int, frozenset[int]]:
        global_rank = row["u"] if side == "lower" else row["a"]
        result = {}
        for p in active:
            left = extension(row["word"], len(row["maxima"]), side, p, True)
            right = extension(row["word"], len(row["maxima"]), side, p, False)
            result[p] = frozenset(range(left + 1, max(left + 1, global_rank - right)))
        return result

    chosen = intervals(chosen_side)
    opposite = intervals(opposite_side)
    subset_cost = {}
    for mask in range(1, 1 << len(active)):
        support = tuple(active[i] for i in range(len(active)) if mask & (1 << i))
        chosen_union = frozenset().union(*(chosen[p] for p in support))
        opposite_union = frozenset().union(*(opposite[p] for p in support))
        subset_cost[mask] = (
            (max(0, len(chosen_union) - 1) * max(0, len(opposite_union) - 1)) + 1
        )
    best = {0: (0, [])}
    for mask in range(1, 1 << len(active)):
        anchor = mask & -mask
        sub = mask
        winner = None
        while sub:
            if sub & anchor:
                cost = subset_cost[sub] + best[mask ^ sub][0]
                if winner is None or cost < winner[0]:
                    winner = (cost, [sub] + best[mask ^ sub][1])
            sub = (sub - 1) & mask
        best[mask] = winner
    total, partition = best[(1 << len(active)) - 1]
    return {
        "active": list(active),
        "chosen_intervals": {p: sorted(chosen[p]) for p in active},
        "opposite_intervals": {p: sorted(opposite[p]) for p in active},
        "all_chosen_intervals_thin": all(len(chosen[p]) <= 2 for p in active),
        "minimum_partition_cost": total,
        "partition": [
            {
                "support": [active[i] for i in range(len(active)) if mask & (1 << i)],
                "cost": subset_cost[mask],
            }
            for mask in partition
        ],
    }


def maximizing_cuts(row: dict, bound) -> list[dict]:
    """Return every top-level interval cut attaining the row's recursive bound."""
    children = tuple(i for i, letter in enumerate(row["word"]) if letter == "S")
    target = bound(row["word"], row["maxima"])
    records = []
    for start in range(len(children)):
        for length in range(1, len(children) - start + 1):
            if length == len(children):
                continue
            block = frozenset(children[start : start + length])
            rest = frozenset(p for p in children if p not in block)
            for lower_maximum in range(1, row["k"] - 1):
                upper_maximum = row["k"] - 1 - lower_maximum
                for block_side, rest_side in (("lower", "upper"), ("upper", "lower")):
                    block_maximum = (
                        lower_maximum if block_side == "lower" else upper_maximum
                    )
                    rest_maximum = (
                        lower_maximum if rest_side == "lower" else upper_maximum
                    )
                    block_part = part(row, block, block_side, block_maximum)
                    rest_part = part(row, rest, rest_side, rest_maximum)
                    block_bound = bound(block_part["word"], block_part["maxima"])
                    rest_bound = bound(rest_part["word"], rest_part["maxima"])
                    if block_bound + rest_bound == target:
                        records.append({
                            "block": sorted(block),
                            "rest": sorted(rest),
                            "block_side": block_side,
                            "block_maximum": block_maximum,
                            "block_bound": block_bound,
                            "rest_side": rest_side,
                            "rest_maximum": rest_maximum,
                            "rest_bound": rest_bound,
                        })
    return records


def split_pruning_bounds(row: dict, bound, pivots: tuple[int, ...]) -> list[dict]:
    """Exact bounds of the two run-group prunings around each positional pivot."""
    children = frozenset(
        i for i, letter in enumerate(row["word"]) if letter == "S"
    )
    records = []
    for pivot in pivots:
        left = frozenset(p for p in children if p < pivot)
        right = frozenset(p for p in children if pivot < p)
        left_group = prune(row, left)
        right_group = prune(row, right)
        left_bound = bound(left_group["word"], left_group["maxima"])
        right_bound = bound(right_group["word"], right_group["maxima"])
        records.append({
            "pivot": pivot,
            "left": sorted(left),
            "left_bound": left_bound,
            "right": sorted(right),
            "right_bound": right_bound,
            "sum": left_bound + right_bound,
        })
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--pairs-only", action="store_true")
    parser.add_argument("--swapped-target", default="")
    parser.add_argument("--sweep-middle", action="store_true")
    parser.add_argument("--sweep-middle-rectangles", action="store_true")
    parser.add_argument("--find-middle-outer-d-two", action="store_true")
    parser.add_argument("--sweep-middle-coupled-one", action="store_true")
    parser.add_argument("--middle-word", default="")
    parser.add_argument("--maxima", default="2,1,1,1")
    parser.add_argument("--limits-only", action="store_true")
    parser.add_argument("--with-middle-companion", action="store_true")
    args = parser.parse_args()
    row = {
        "word": (
            "S", "S", (2, "lower"), (3, "lower"),
            "S", "S", (1, "upper"), "S", "S",
        ),
        "maxima": (1, 1, 1),
        "a": 5,
        "u": 5,
        "k": 6,
        "chosen": "lower",
    }
    children = tuple(i for i, letter in enumerate(row["word"]) if letter == "S")
    if args.middle_word:
        def parse_letter(token: str):
            if token == "S":
                return token
            level_text, side_text = token.split(":", 1)
            if side_text not in {"lower", "upper"}:
                raise ValueError("marker side must be lower or upper")
            return (int(level_text), side_text)

        word = tuple(parse_letter(token) for token in args.middle_word.split(","))
        maxima = tuple(int(value) for value in args.maxima.split(","))
        probe = {"a": 5, "u": 5, "k": 6, "word": word, "maxima": maxima}
        payload = {
            "semantics": "single encoded middle-word diagnostic; no Lean proof credit",
            "word": word,
            "maxima": maxima,
            "point_limits": point_limits(probe),
        }
        if not args.limits_only:
            bound = evaluator(
                5,
                5,
                6,
                semantics="context-bound-zero-children-v1",
                cache_size=512000,
            )
            payload["bound"] = bound(word, maxima)
            if args.with_middle_companion:
                if not maxima or maxima[0] != 2:
                    raise ValueError("middle companion reconstruction requires leading maximum 2")
                block = frozenset(
                    position for position, letter in enumerate(word)
                    if letter == (1, "lower")
                )
                if not block:
                    raise ValueError("middle companion reconstruction requires a level-one lower marker")
                source_word = tuple(
                    "S" if letter == "S" or letter == (1, "lower")
                    else (letter[0] - 1, letter[1])
                    for letter in word
                )
                source = {
                    "a": 5,
                    "u": 5,
                    "k": 6,
                    "chosen": "lower",
                    "word": source_word,
                    "maxima": maxima[1:],
                }
                companion = part(source, block, "upper", 3)
                companion_bound = bound(companion["word"], companion["maxima"])
                payload["source"] = source
                payload["block"] = sorted(block)
                payload["companion"] = companion
                payload["companion_bound"] = companion_bound
                payload["coupled_sum"] = payload["bound"] + companion_bound
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps(payload, default=list, sort_keys=True), flush=True)
        return
    if args.sweep_middle_rectangles:
        markers = (
            (1, "lower"),
            (2, "upper"),
            (3, "lower"),
            (4, "lower"),
        )
        tested = 0
        maximum = 0
        first_violation = None
        for length in range(7, 11):
            for positions in itertools.combinations(range(length), 4):
                for tagged in itertools.permutations(markers):
                    location = {letter[0]: position for position, letter in zip(positions, tagged)}
                    k_pos, q_pos, x_pos, y_pos = (
                        location[1], location[2], location[3], location[4]
                    )
                    inner = (
                        (x_pos < y_pos < q_pos and x_pos < k_pos)
                        or (q_pos < y_pos < x_pos and k_pos < x_pos)
                    )
                    if not inner:
                        continue
                    child_positions = tuple(p for p in range(length) if p not in positions)
                    if not (
                        any(p < k_pos for p in child_positions)
                        and any(k_pos < p for p in child_positions)
                    ):
                        continue
                    word = ["S"] * length
                    for position, letter in zip(positions, tagged):
                        word[position] = letter
                    probe = {
                        "a": 5,
                        "u": 5,
                        "k": 6,
                        "chosen": "lower",
                        "word": tuple(word),
                        "maxima": (2, 1, 1, 1),
                    }
                    cover = minimum_rectangle_partition(probe, "lower", "upper")
                    tested += 1
                    maximum = max(maximum, cover["minimum_partition_cost"])
                    if (
                        not cover["all_chosen_intervals_thin"]
                        or cover["minimum_partition_cost"] > 8
                    ):
                        first_violation = {"word": word, "cover": cover}
                        break
                if first_violation is not None:
                    break
            if first_violation is not None:
                break
        payload = {
            "semantics": "bounded inner-geometry rectangle-cover diagnostic; no Lean proof credit",
            "tested": tested,
            "maximum": maximum,
            "first_violation": first_violation,
        }
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps({"tested": tested, "maximum": maximum,
                          "violation": first_violation is not None}, sort_keys=True), flush=True)
        return
    if args.find_middle_outer_d_two:
        bound = evaluator(
            5,
            5,
            6,
            semantics="context-bound-zero-children-v1",
            cache_size=512000,
        )
        markers = (
            (1, "lower"),
            (2, "upper"),
            (3, "lower"),
            (4, "lower"),
        )
        tested = 0
        exact_tested = 0
        witness = None
        for length in range(7, 11):
            for positions in itertools.combinations(range(length), 4):
                for tagged in itertools.permutations(markers):
                    location = {letter[0]: position for position, letter in zip(positions, tagged)}
                    k_pos, x_pos, y_pos = location[1], location[3], location[4]
                    outer = (
                        (k_pos < x_pos < y_pos)
                        or (y_pos < x_pos < k_pos)
                    )
                    if not outer:
                        continue
                    child_positions = tuple(p for p in range(length) if p not in positions)
                    if not (
                        any(p < k_pos for p in child_positions)
                        and any(k_pos < p for p in child_positions)
                    ):
                        continue
                    word = ["S"] * length
                    for position, letter in zip(positions, tagged):
                        word[position] = letter
                    source_word = tuple(
                        "S" if letter == "S" or letter == (1, "lower")
                        else (letter[0] - 1, letter[1])
                        for letter in word
                    )
                    source = {
                        "a": 5,
                        "u": 5,
                        "k": 6,
                        "chosen": "lower",
                        "word": source_word,
                        "maxima": (1, 1, 1),
                    }
                    companion = part(source, frozenset({k_pos}), "upper", 3)
                    tested += 1
                    limits = point_limits(companion)
                    if not limits or max(min(cup, cap) for cup, cap in limits.values()) < 2:
                        continue
                    exact_tested += 1
                    companion_bound = bound(companion["word"], companion["maxima"])
                    if companion_bound >= 2:
                        middle = {
                            "a": 5,
                            "u": 5,
                            "k": 6,
                            "chosen": "lower",
                            "word": tuple(word),
                            "maxima": (2, 1, 1, 1),
                        }
                        middle_bound = bound(middle["word"], middle["maxima"])
                        witness = {
                            "middle": middle,
                            "middle_bound": middle_bound,
                            "source": source,
                            "block": [k_pos],
                            "companion": companion,
                            "companion_bound": companion_bound,
                            "coupled_sum": middle_bound + companion_bound,
                        }
                        break
                if witness is not None:
                    break
            if witness is not None:
                break
        payload = {
            "semantics": (
                "bounded one-occurrence outer-geometry search using "
                "context-bound-zero-children-v1; diagnostic only; no Lean proof credit"
            ),
            "tested": tested,
            "exact_tested": exact_tested,
            "witness": witness,
        }
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps({
            "tested": tested,
            "exact_tested": exact_tested,
            "found": witness is not None,
        }, sort_keys=True), flush=True)
        return
    if args.sweep_middle_coupled_one:
        bound = evaluator(
            5,
            5,
            6,
            semantics="context-bound-zero-children-v1",
            cache_size=512000,
        )
        markers = (
            (1, "lower"),
            (2, "upper"),
            (3, "lower"),
            (4, "lower"),
        )
        tested = 0
        companion_exact_tested = 0
        middle_exact_tested = 0
        maximum_sum = 0
        tight = []
        violation = None
        for length in range(7, 11):
            for positions in itertools.combinations(range(length), 4):
                for tagged in itertools.permutations(markers):
                    location = {letter[0]: position for position, letter in zip(positions, tagged)}
                    k_pos, x_pos, y_pos = location[1], location[3], location[4]
                    outer = k_pos < x_pos < y_pos or y_pos < x_pos < k_pos
                    inner = x_pos < k_pos and x_pos < y_pos or k_pos < x_pos and y_pos < x_pos
                    if not (outer or inner):
                        continue
                    child_positions = tuple(p for p in range(length) if p not in positions)
                    if not (
                        any(p < k_pos for p in child_positions)
                        and any(k_pos < p for p in child_positions)
                    ):
                        continue
                    word = ["S"] * length
                    for position, letter in zip(positions, tagged):
                        word[position] = letter
                    source_word = tuple(
                        "S" if letter == "S" or letter == (1, "lower")
                        else (letter[0] - 1, letter[1])
                        for letter in word
                    )
                    source = {
                        "a": 5,
                        "u": 5,
                        "k": 6,
                        "chosen": "lower",
                        "word": source_word,
                        "maxima": (1, 1, 1),
                    }
                    companion = part(source, frozenset({k_pos}), "upper", 3)
                    tested += 1
                    dangerous_d = 2 if outer else 3
                    limits = point_limits(companion)
                    if not limits or max(min(cup, cap) for cup, cap in limits.values()) < dangerous_d:
                        continue
                    companion_exact_tested += 1
                    companion_bound = bound(companion["word"], companion["maxima"])
                    if companion_bound != dangerous_d:
                        continue
                    middle = {
                        "a": 5,
                        "u": 5,
                        "k": 6,
                        "chosen": "lower",
                        "word": tuple(word),
                        "maxima": (2, 1, 1, 1),
                    }
                    middle_exact_tested += 1
                    middle_bound = bound(middle["word"], middle["maxima"])
                    coupled_sum = middle_bound + companion_bound
                    maximum_sum = max(maximum_sum, coupled_sum)
                    record = {
                        "geometry": "outer" if outer else "inner",
                        "middle": middle,
                        "middle_bound": middle_bound,
                        "source": source,
                        "block": [k_pos],
                        "companion": companion,
                        "companion_bound": companion_bound,
                        "coupled_sum": coupled_sum,
                    }
                    if coupled_sum == 11 and len(tight) < 20:
                        tight.append(record)
                    if coupled_sum > 11:
                        violation = record
                        break
                if violation is not None:
                    break
            if violation is not None:
                break
        payload = {
            "semantics": (
                "bounded one-occurrence coupled equality search using "
                "context-bound-zero-children-v1; diagnostic only; no Lean proof credit"
            ),
            "tested": tested,
            "companion_exact_tested": companion_exact_tested,
            "middle_exact_tested": middle_exact_tested,
            "maximum_sum": maximum_sum,
            "tight_examples": tight,
            "violation": violation,
        }
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps({
            "tested": tested,
            "companion_exact_tested": companion_exact_tested,
            "middle_exact_tested": middle_exact_tested,
            "maximum_sum": maximum_sum,
            "violation": violation is not None,
        }, sort_keys=True), flush=True)
        return
    if args.sweep_middle:
        bound = evaluator(
            5,
            5,
            6,
            semantics="context-bound-zero-children-v1",
            cache_size=512000,
        )
        markers = (
            (1, "lower"),
            (2, "upper"),
            (3, "lower"),
            (4, "lower"),
        )
        records = []
        tested = 0
        maximum = 0
        for length in range(7, 11):
            for positions in itertools.combinations(range(length), 4):
                for tagged in itertools.permutations(markers):
                    location = {letter[0]: position for position, letter in zip(positions, tagged)}
                    k_pos, q_pos, x_pos, y_pos = (
                        location[1], location[2], location[3], location[4]
                    )
                    if not (x_pos < y_pos < q_pos or q_pos < y_pos < x_pos):
                        continue
                    if not (k_pos < x_pos or x_pos < k_pos):
                        continue
                    child_positions = tuple(p for p in range(length) if p not in positions)
                    if not (
                        any(p < k_pos for p in child_positions)
                        and any(k_pos < p for p in child_positions)
                    ):
                        continue
                    word = ["S"] * length
                    for position, letter in zip(positions, tagged):
                        word[position] = letter
                    value = bound(tuple(word), (2, 1, 1, 1))
                    tested += 1
                    maximum = max(maximum, value)
                    if value >= 8:
                        records.append({
                            "word": word,
                            "bound": value,
                            "K": k_pos,
                            "q0": q_pos,
                            "x": x_pos,
                            "y": y_pos,
                        })
        payload = {
            "semantics": "bounded one-occurrence diagnostic; no Lean proof credit",
            "tested": tested,
            "maximum": maximum,
            "violations_of_eight": [record for record in records if record["bound"] > 8],
            "tight_examples": [record for record in records if record["bound"] == 8][:50],
        }
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps({"tested": tested, "maximum": maximum,
                          "violations": len(payload["violations_of_eight"])}, sort_keys=True), flush=True)
        return
    if args.swapped_target:
        kept = frozenset(int(value) for value in args.swapped_target.split(","))
        if not kept or not kept.issubset(children):
            raise ValueError("--swapped-target must be a nonempty subset of child positions")
        rest = frozenset(p for p in children if p not in kept)
        companion = part(row, rest, "upper", 1)
        middle_complement = part(row, rest, "lower", 2)
        bound = evaluator(
            5,
            5,
            6,
            semantics="context-bound-zero-children-v1",
            cache_size=256000,
        )
        payload = {
            "semantics": "context-bound-zero-children-v1; diagnostic only; no Lean proof credit",
            "source": row,
            "keep": sorted(kept),
            "rest": sorted(rest),
            "companion": companion,
            "companion_bound": bound(companion["word"], companion["maxima"]),
            "middle_complement": middle_complement,
            "middle_complement_bound": bound(
                middle_complement["word"], middle_complement["maxima"],
            ),
            "middle_rectangle_partition": minimum_rectangle_partition(
                middle_complement, "lower", "upper",
            ),
            "companion_rectangle_lower_thin": minimum_rectangle_partition(
                companion, "lower", "upper",
            ),
            "companion_rectangle_upper_thin": minimum_rectangle_partition(
                companion, "upper", "lower",
            ),
            "companion_upper_capacity_pruning": capacity_pruning_bounds(
                companion, "upper", bound,
            ),
            "companion_upper_capacity_pair_supports": capacity_pair_supports(
                companion, "upper", "lower",
            ),
            "rank_triple_support": rank_triple_support(companion, "upper"),
            "positional_pruning_bounds": split_pruning_bounds(
                companion, bound, tuple(range(len(companion["word"]))),
            ),
            "maximizing_cuts": maximizing_cuts(companion, bound),
        }
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps(payload, default=list, sort_keys=True), flush=True)
        return
    if args.pairs_only:
        records = []
        for start in range(len(children)):
            for length in range(1, len(children) - start + 1):
                if length == len(children):
                    continue
                kept = frozenset(children[start : start + length])
                rest = frozenset(p for p in children if p not in kept)
                companion = part(row, rest, "upper", 1)
                records.append({
                    "keep": sorted(kept),
                    "rest": sorted(rest),
                    "straddles_q6": min(kept) < 6 < max(kept),
                    "companion_pair_supports": capacity_pair_supports(
                        companion, "lower", "upper",
                    ),
                    "arm_pair_supports": positional_arm_pair_supports(
                        companion, min(kept), "lower",
                    ),
                })
        payload = {
            "semantics": "diagnostic exact Lean-style rank supports; no Lean proof credit",
            "source": row,
            "records": records,
        }
        args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
        print(json.dumps(payload, default=list, sort_keys=True), flush=True)
        return
    source_limits = point_limits(row)
    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=256000,
    )
    records = []
    for start in range(len(children)):
        for length in range(1, len(children) - start + 1):
            if length == len(children):
                continue
            kept = frozenset(children[start : start + length])
            rest = frozenset(p for p in children if p not in kept)
            chosen_part = part(row, kept, "lower", 2)
            opposite_part = part(row, rest, "upper", 3)
            reverse_chosen_part = part(row, rest, "lower", 2)
            reverse_opposite_part = part(row, kept, "upper", 3)
            swapped_own_part = part(row, kept, "lower", 4)
            swapped_companion_part = part(row, rest, "upper", 1)
            print(f"evaluating K={sorted(kept)}", flush=True)
            chosen_bound = bound(chosen_part["word"], chosen_part["maxima"])
            opposite_bound = bound(opposite_part["word"], opposite_part["maxima"])
            reverse_chosen_bound = bound(
                reverse_chosen_part["word"], reverse_chosen_part["maxima"],
            )
            reverse_opposite_bound = bound(
                reverse_opposite_part["word"], reverse_opposite_part["maxima"],
            )
            swapped_own_bound = bound(
                swapped_own_part["word"], swapped_own_part["maxima"],
            )
            swapped_companion_bound = bound(
                swapped_companion_part["word"], swapped_companion_part["maxima"],
            )
            chosen_limits = point_limits(chosen_part)
            opposite_limits = point_limits(opposite_part)
            reverse_chosen_limits = point_limits(reverse_chosen_part)
            reverse_opposite_limits = point_limits(reverse_opposite_part)
            regional_prunings = None
            source_capacity_prunings = None
            reverse_chosen_maximizing_cuts = None
            if reverse_chosen_bound >= 8 and reverse_opposite_bound >= 3:
                left = frozenset(p for p in rest if p < 3)
                middle = frozenset(p for p in rest if 3 < p < min(kept))
                right = frozenset(p for p in rest if max(kept) < p)
                regional_supports = (left, middle, right)
                regional_bounds = tuple(
                    bound(prune(reverse_chosen_part, support)["word"],
                          prune(reverse_chosen_part, support)["maxima"])
                    for support in regional_supports
                )
                regional_prunings = {
                    "supports": [sorted(support) for support in regional_supports],
                    "bounds": regional_bounds,
                    "sum": sum(regional_bounds),
                }
                source_low = frozenset(p for p in rest if source_limits[p][0] <= 2)
                source_high = frozenset(p for p in rest if source_limits[p][0] >= 3)
                source_supports = (source_low, source_high)
                source_bounds = tuple(
                    bound(prune(reverse_chosen_part, support)["word"],
                          prune(reverse_chosen_part, support)["maxima"])
                    for support in source_supports
                )
                source_capacity_prunings = {
                    "supports": [sorted(support) for support in source_supports],
                    "bounds": source_bounds,
                    "sum": sum(source_bounds),
                }
                reverse_chosen_maximizing_cuts = maximizing_cuts(
                    reverse_chosen_part, bound,
                )
            record = {
                "keep": sorted(kept),
                "rest": sorted(rest),
                "straddles_q6": min(kept) < 6 < max(kept),
                "chosen_maximum_two": chosen_bound,
                "opposite_maximum_three": opposite_bound,
                "sum": chosen_bound + opposite_bound,
                "reverse_chosen_maximum_two": reverse_chosen_bound,
                "reverse_opposite_maximum_three": reverse_opposite_bound,
                "reverse_sum": reverse_chosen_bound + reverse_opposite_bound,
                "swapped_own_maximum_four": swapped_own_bound,
                "swapped_companion_maximum_one": swapped_companion_bound,
                "swapped_sum": swapped_own_bound + swapped_companion_bound,
                "reverse_chosen_part_limits": reverse_chosen_limits,
                "reverse_opposite_part_limits": reverse_opposite_limits,
                "reverse_chosen_regional_prunings": regional_prunings,
                "reverse_chosen_source_capacity_prunings": source_capacity_prunings,
                "reverse_chosen_maximizing_cuts": reverse_chosen_maximizing_cuts,
                "source_limits": {p: source_limits[p] for p in sorted(kept | rest)},
                "chosen_part_limits": chosen_limits,
                "opposite_part_limits": opposite_limits,
                "chosen_retains_source_high": any(source_limits[p][0] >= 3 for p in kept),
                "chosen_retains_descendant_high": any(v[0] >= 3 for v in chosen_limits.values()),
            }
            records.append(record)
            print(json.dumps(record, sort_keys=True), flush=True)
    payload = {
        "semantics": "context-bound-zero-children-v1; diagnostic only; no Lean proof credit",
        "source": row,
        "records": records,
    }
    args.output.write_text(json.dumps(payload, default=list, indent=2, sort_keys=True) + "\n")
    print(json.dumps(payload, default=list, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
