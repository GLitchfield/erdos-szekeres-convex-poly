#!/usr/bin/env python3
"""Probe a strict spatial run-group decomposition at the younger marker.

Exploratory only.  This uses the registered recursive evaluator and does not
assert equivalence to a Lean theorem.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from harness.research.recursive import evaluator  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def prune(word, maxima, keep):
    fresh = len(maxima) + 1
    return tuple(
        letter if letter != "S" or keep(position) else (fresh, "lower")
        for position, letter in enumerate(word)
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=5)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=500_000,
    )
    maxima = (1, 1, 1)
    tested = 0
    violations = []
    tight = []
    for child_count in range(2, args.max_children + 1):
        size = child_count + 3
        for ext_positions in itertools.combinations(range(size), 3):
            for level_order in itertools.permutations((1, 2, 3)):
                for q_side in ("lower", "upper"):
                    s_side = "upper" if q_side == "lower" else "lower"
                    sides = {1: q_side, 2: s_side, 3: s_side}
                    word = ["S"] * size
                    positions = {}
                    for position, level in zip(ext_positions, level_order):
                        word[position] = (level, sides[level])
                        positions[level] = position
                    q, x, y = positions[1], positions[2], positions[3]
                    if not (q < y < x or x < y < q):
                        continue
                    children = [i for i, letter in enumerate(word) if letter == "S"]
                    if not (any(p < x for p in children) and any(x < p for p in children)):
                        continue
                    if not (any(p < q for p in children) and any(q < p for p in children)):
                        continue
                    word = tuple(word)
                    left = bound(prune(word, maxima, lambda p: p < x), maxima)
                    right = bound(prune(word, maxima, lambda p: x < p), maxima)
                    value = bound(word, maxima)
                    tested += 1
                    row = {
                        "word": encode(word),
                        "positions": positions,
                        "bound": value,
                        "left": left,
                        "right": right,
                        "slack": left + right - value,
                    }
                    if left + right < value + 1:
                        violations.append(row)
                        print(json.dumps({"violation": row}), flush=True)
                        if len(violations) >= 32:
                            break
                    if value >= 11 and len(tight) < 64:
                        tight.append(row)
                    if tested % 50 == 0:
                        print(json.dumps({"checkpoint": tested, **row}), flush=True)
                if len(violations) >= 32:
                    break
            if len(violations) >= 32:
                break
        if len(violations) >= 32:
            break
    result = {
        "semantics": "context-bound-zero-children-v1; diagnostic only",
        "candidate": "nonmonotone singleton q(t),x(s),y(s), maxima one, children on both sides of q and x implies bound+1 <= x-left-pruning bound + x-right-pruning bound",
        "max_children": args.max_children,
        "tested": tested,
        "violations": violations,
        "large_examples": tight,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
