#!/usr/bin/env python3
"""Falsify B <= 11 after adding one older opposite-axis marker.

Exploratory only.  The word is already the companion context: level one is
the retained physical marker q of maximum one; two later chosen-axis levels
have maxima one; the remaining later level is an arbitrary opposite-axis
history marker.  This uses the registered recursive evaluator and is not a
Lean certificate.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from harness.research.recursive import evaluator  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def straddles(positions, pivot):
    return any(p < pivot for p in positions) and any(pivot < p for p in positions)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=3)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bound = evaluator(
        5,
        5,
        6,
        semantics="context-bound-zero-children-v1",
        cache_size=750_000,
    )
    tested = 0
    maximum = -1
    examples = []
    violations = []
    # x is the younger chosen marker and y the older chosen marker, so their
    # companion levels satisfy x_level < y_level.  The spare level is on t.
    for child_count in range(2, args.max_children + 1):
        size = child_count + 4
        for ext_positions in itertools.combinations(range(size), 4):
            for assigned_levels in itertools.permutations((1, 2, 3, 4)):
                positions = dict(zip(assigned_levels, ext_positions))
                q = positions[1]
                for x_level, y_level in itertools.combinations((2, 3, 4), 2):
                    extra_level = ({2, 3, 4} - {x_level, y_level}).pop()
                    x = positions[x_level]
                    y = positions[y_level]
                    if not (q < y < x or x < y < q):
                        continue
                    for t in ("lower", "upper"):
                        s = "upper" if t == "lower" else "lower"
                        word = ["S"] * size
                        word[q] = (1, t)
                        word[x] = (x_level, s)
                        word[y] = (y_level, s)
                        word[positions[extra_level]] = (extra_level, t)
                        word = tuple(word)
                        children = [p for p, letter in enumerate(word) if letter == "S"]
                        if not straddles(children, q):
                            continue
                        for extra_maximum in range(1, 5):
                            maxima = [0, 0, 0, 0]
                            maxima[0] = 1
                            maxima[x_level - 1] = 1
                            maxima[y_level - 1] = 1
                            maxima[extra_level - 1] = extra_maximum
                            value = bound(word, tuple(maxima))
                            tested += 1
                            row = {
                                "word": encode(word),
                                "positions": positions,
                                "x_level": x_level,
                                "y_level": y_level,
                                "extra_level": extra_level,
                                "extra_maximum": extra_maximum,
                                "bound": value,
                            }
                            if value > maximum:
                                maximum = value
                                examples = [row]
                            elif value == maximum and len(examples) < 16:
                                examples.append(row)
                            if value > 11:
                                violations.append(row)
                                print(json.dumps({"violation": row}), flush=True)
                                if len(violations) >= 32:
                                    break
                        if len(violations) >= 32:
                            break
                    if len(violations) >= 32:
                        break
                if len(violations) >= 32:
                    break
            if len(violations) >= 32:
                break
        print(
            json.dumps(
                {
                    "children": child_count,
                    "tested": tested,
                    "maximum": maximum,
                    "violations": len(violations),
                }
            ),
            flush=True,
        )
        if len(violations) >= 32:
            break

    result = {
        "semantics": "context-bound-zero-children-v1; diagnostic only",
        "candidate": "older-exterior companion B <= 11 with one extra opposite-axis level",
        "max_children": args.max_children,
        "tested": tested,
        "maximum": maximum,
        "examples": examples,
        "violations": violations,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
