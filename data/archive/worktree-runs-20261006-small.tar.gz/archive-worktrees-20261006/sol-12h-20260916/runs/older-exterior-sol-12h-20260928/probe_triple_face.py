#!/usr/bin/env python3
"""Probe the youngest-q row/column triple-face cardinal in the residual.

Exploratory only.  Extension arithmetic and activity use registered research
primitives and the legacy Lean-style signature calculation; neither is a
kernel certificate.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path


REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))

from decomposable_depth2_tables import limits_from_signature  # noqa: E402
from harness.research.primitives import extension  # noqa: E402


def encode(word):
    return [
        "S" if letter == "S" else f"{letter[0]}{'L' if letter[1] == 'lower' else 'U'}"
        for letter in word
    ]


def child_runs(word):
    run = -1
    in_run = False
    result = {}
    for position, letter in enumerate(word):
        if letter == "S":
            if not in_run:
                run += 1
                in_run = True
            result[position] = run
        else:
            in_run = False
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=7)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    maxima = (1, 1, 1)
    tested = 0
    maximum = -1
    maximizers = []
    violations = []
    for child_count in range(2, args.max_children + 1):
        size = child_count + 3
        for ext_positions in itertools.combinations(range(size), 3):
            for level_order in itertools.permutations((1, 2, 3)):
                for q_side in ("lower", "upper"):
                    s_side = "upper" if q_side == "lower" else "lower"
                    # q is level one.  x is the younger old chosen marker at
                    # level two and y the older marker at level three.
                    positions = {
                        level: position
                        for position, level in zip(ext_positions, level_order)
                    }
                    q, x, y = positions[1], positions[2], positions[3]
                    if not (q < y < x or x < y < q):
                        continue
                    word = ["S"] * size
                    if len({q, x, y}) != 3:
                        continue
                    word[q] = (1, q_side)
                    word[x] = (2, s_side)
                    word[y] = (3, s_side)
                    word = tuple(word)
                    children = [i for i, letter in enumerate(word) if letter == "S"]
                    if not (any(p < q for p in children) and any(q < p for p in children)):
                        continue
                    runs = child_runs(word)
                    _, cups, caps = limits_from_signature(word, maxima, 5, 5, 6, lean=True)
                    active = [
                        p
                        for p in children
                        if int(cups[runs[p]][runs[p]]) > 0
                        and int(caps[runs[p]][runs[p]]) > 0
                    ]
                    rows = set()
                    columns = set()
                    intervals = {}
                    for p in active:
                        lo = extension(word, len(maxima), s_side, p, True) + 1
                        hi = 4 - extension(word, len(maxima), s_side, p, False)
                        interval = list(range(lo, hi + 1)) if lo <= hi else []
                        intervals[p] = [lo, hi]
                        pairs = [(a, b) for a in interval for b in interval if a <= b]
                        if p < q:
                            rows.update((lo, a, b) for a, b in pairs)
                        elif q < p:
                            columns.update((a, b, hi) for a, b in pairs)
                    cardinal = len(rows | columns)
                    tested += 1
                    row = {
                        "word": encode(word),
                        "positions": positions,
                        "active": active,
                        "intervals": intervals,
                        "rows": len(rows),
                        "columns": len(columns),
                        "intersection": len(rows & columns),
                        "union": cardinal,
                    }
                    if cardinal > maximum:
                        maximum = cardinal
                        maximizers = [row]
                    elif cardinal == maximum and len(maximizers) < 32:
                        maximizers.append(row)
                    if cardinal > 11:
                        violations.append(row)
                        print(json.dumps({"violation": row}), flush=True)
                        if len(violations) >= 64:
                            break
            if len(violations) >= 64:
                break
        if len(violations) >= 64:
            break
    result = {
        "semantics": "research.context-extension plus limits_from_signature(..., lean=True); diagnostic only",
        "candidate": "youngest q opposite-axis triple-face union has cardinal at most 11 when q,y,x or x,y,q are spatially ordered",
        "max_children": args.max_children,
        "tested": tested,
        "maximum": maximum,
        "maximizers": maximizers,
        "violations": violations,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
