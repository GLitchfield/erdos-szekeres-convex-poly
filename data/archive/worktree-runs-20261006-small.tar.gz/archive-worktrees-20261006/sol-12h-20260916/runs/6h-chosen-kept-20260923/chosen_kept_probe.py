"""Finite exploratory probe for the k=6 internally bracketed chosen-kept cut.

This uses the retained Lean-aligned research evaluator, not the Lean kernel.
The domain here has exactly two chosen-side external letters, both maxima one,
no opposite-side history, and up to ``--max-children`` child letters.
"""

from __future__ import annotations

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from decomposable_additivity_test import child  # noqa: E402
from harness.research.recursive import evaluator  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bound = evaluator(5, 5, 6, semantics="context-bound-zero-children-v1", cache_size=16000)
    tested = 0
    best = -1
    witnesses: list[dict] = []
    violations: list[dict] = []
    for child_count in range(3, args.max_children + 1):
        for marker_positions in combinations(range(child_count + 2), 2):
            for mirrored in (False, True):
                x, y = marker_positions if not mirrored else marker_positions[::-1]
                word = ["S"] * (child_count + 2)
                word[x] = (1, "lower")
                word[y] = (2, "lower")
                word_tuple = tuple(word)
                children = [p for p, letter in enumerate(word) if letter == "S"]
                for i in range(1, child_count - 1):
                    for j in range(i, child_count - 1):
                        keep = frozenset(children[i : j + 1])
                        older_exterior = (x < y < min(keep)) or (max(keep) < y < x)
                        if not older_exterior:
                            continue
                        rest = frozenset(children) - keep
                        a_word, a_maxima = child(word_tuple, (1, 1), keep, "lower", 4)
                        b_word, b_maxima = child(word_tuple, (1, 1), rest, "upper", 1)
                        a_bound = bound(a_word, a_maxima)
                        b_bound = bound(b_word, b_maxima)
                        total = a_bound + b_bound
                        tested += 1
                        row = {
                            "word": ["S" if z == "S" else f"{z[0]}L" for z in word_tuple],
                            "maxima": [1, 1],
                            "x": x,
                            "y": y,
                            "keep": sorted(keep),
                            "rest": sorted(rest),
                            "A": a_bound,
                            "B": b_bound,
                            "total": total,
                        }
                        if total > best:
                            best = total
                            witnesses = [row]
                        elif total == best and len(witnesses) < 10:
                            witnesses.append(row)
                        if total > 12 and len(violations) < 10:
                            violations.append(row)
    result = {
        "domain": "two chosen external letters; no opposite history; maxima=(1,1)",
        "parameters": {"a": 5, "u": 5, "k": 6, "m": 4, "n": 1},
        "semantics": "context-bound-zero-children-v1; exploratory, no Lean proof credit",
        "max_children": args.max_children,
        "tested": tested,
        "max_total": best,
        "max_witnesses": witnesses,
        "violations": violations,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"tested": tested, "max_total": best, "violations": len(violations)}))


if __name__ == "__main__":
    main()
