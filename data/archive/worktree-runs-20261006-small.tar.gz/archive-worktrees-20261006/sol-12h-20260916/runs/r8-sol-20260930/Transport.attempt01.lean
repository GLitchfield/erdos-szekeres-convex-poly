import ESBlueprint.B.CtxSingleLevelOccurrencePruneBoundMono
import ESBlueprint.B.CtxBoundAdditivePrefixSuffix
import ESBlueprint.B.CtxBoundAttainedByEndCut

set_option maxHeartbeats 8000000

namespace ErdosSzekeres
open Ctx Ctx.Context

-- Local proof laboratory: all obligations are proved, with no placeholder axiom.
example : True := by
  classical
  let up (p i : ℕ) := if i < p then i else i + 1
  have hup : ∀ p, StrictMono (up p) := by
    intro p i j hij
    dsimp [up]
    split_ifs <;> omega
  have hRange : ∀ n p, p ≤ n →
      (List.range (n + 1)).filter (fun i ↦ i ≠ p) = (List.range n).map (up p) := by
    intro n
    induction n with
    | zero => intro p hp; have : p = 0 := by omega; subst p; simp
    | succ n ih =>
      intro p hp
      by_cases hpn : p = n + 1
      · subst p
        have hpre : (List.range (n + 1)).map (up (n + 1)) = List.range (n + 1) := by
          apply List.map_id'
          intro i hi
          simp [up, List.mem_range.1 hi]
        rw [List.range_succ, List.filter_append]
        have hself : (List.range (n + 1)).filter (fun i ↦ i ≠ n + 1) =
            List.range (n + 1) := by
          apply List.filter_eq_self.2
          intro i hi
          simp only [decide_eq_true_eq]
          exact Nat.ne_of_lt (List.mem_range.1 hi)
        simp [hself, hpre]
      · have hpn' : p ≤ n := by omega
        rw [List.range_succ, List.filter_append, ih p hpn', List.range_succ,
          List.map_append]
        have hnp : n + 1 ≠ p := by omega
        have hnp' : ¬ n < p := by omega
        simp [up, hnp, hnp']
  have hFilter : ∀ n p (P Q : ℕ → Bool), p ≤ n → P p = false →
      (∀ i, i < n → P (up p i) = Q i) →
      (List.range (n + 1)).filter P = ((List.range n).filter Q).map (up p) := by
    intro n p P Q hp hfalse hletter
    have hremove : (List.range (n + 1)).filter P =
        ((List.range (n + 1)).filter (fun i ↦ i ≠ p)).filter P := by
      rw [List.filter_filter]
      apply List.filter_congr
      intro i hi
      by_cases hip : i = p
      · subst i; simp [hfalse]
      · simp [hip]
    rw [hremove, hRange n p hp, List.filter_map]
    congr 1
    apply List.filter_congr
    intro i hi
    exact hletter i (List.mem_range.1 hi)
  have hGeometry : ∀ (big small : Context) p level s,
      big.maxima = small.maxima → small.maxima.length < level →
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      big.childPositions = small.childPositions.map (up p) ∧
      (∀ N ∈ small.levels, big.extPositions N = (small.extPositions N).map (up p)) ∧
      (∀ N ∈ small.levels, big.sideAt N = small.sideAt N) := by
    intro big small p level s hm hlevel hlen hp hbp hletter
    have hchildren : big.childPositions = small.childPositions.map (up p) := by
      unfold childPositions
      rw [hlen]
      apply hFilter _ p _ _ hp
      · simp [hbp]
      · intro i hi; rw [hletter i hi]
    have hexternals : ∀ N ∈ small.levels,
        big.extPositions N = (small.extPositions N).map (up p) := by
      intro N hN
      have hNle : N ≤ small.maxima.length := by
        obtain ⟨j, hj, rfl⟩ := List.mem_map.1 hN
        have := List.mem_range.1 hj
        omega
      have hne : level ≠ N := by omega
      unfold extPositions
      rw [hlen]
      apply hFilter _ p _ _ hp
      · simp [hbp, hne]
      · intro i hi; rw [hletter i hi]
    refine ⟨hchildren, hexternals, ?_⟩
    intro N hN
    unfold sideAt
    rw [hexternals N hN, List.head?_map]
    cases hh : (small.extPositions N).head? with
    | none => rfl
    | some q =>
      simp only [Option.map_some]
      have hqn : q < small.word.length :=
        List.mem_range.1 (List.mem_filter.1 (List.mem_of_mem_head? hh)).1
      rw [hletter q hqn]
  have hFolds : ∀ (big small : Context) p,
      (∀ N ∈ small.levels, big.extPositions N = (small.extPositions N).map (up p)) →
      ∀ (ls : List ℕ), (∀ N ∈ ls, N ∈ small.levels) → ∀ e c,
      (ls.foldl (leftStep big) (up p e, c)).2 =
          (ls.foldl (leftStep small) (e, c)).2 ∧
      (ls.foldl (rightStep big) (up p e, c)).2 =
          (ls.foldl (rightStep small) (e, c)).2 := by
    intro big small p hext ls
    induction ls with
    | nil => intros; exact ⟨rfl, rfl⟩
    | cons N ls ih =>
      intro hlevels e c
      have hrest := fun j hj ↦ hlevels j (List.mem_cons_of_mem N hj)
      have hleft : ((big.extPositions N).filter (· < up p e)).getLast? =
          (((small.extPositions N).filter (· < e)).getLast?).map (up p) := by
        rw [hext N (hlevels N (List.mem_cons_self ..)), List.filter_map]
        have hf : (fun i ↦ decide (up p i < up p e)) = (fun i ↦ decide (i < e)) := by
          funext i
          simp only [(hup p).lt_iff_lt]
        rw [hf, List.getLast?_map]
      have hright : ((big.extPositions N).filter (up p e < ·)).head? =
          (((small.extPositions N).filter (e < ·)).head?).map (up p) := by
        rw [hext N (hlevels N (List.mem_cons_self ..)), List.filter_map]
        have hf : (fun i ↦ decide (up p e < up p i)) = (fun i ↦ decide (e < i)) := by
          funext i
          simp only [(hup p).lt_iff_lt]
        rw [hf, List.head?_map]
      constructor
      · simp only [List.foldl_cons, leftStep]
        rw [hleft]
        cases hq : ((small.extPositions N).filter (· < e)).getLast? with
        | none => simp only [Option.map_none]; exact (ih hrest e c).1
        | some q => simp only [Option.map_some]; exact (ih hrest q (c + 1)).1
      · simp only [List.foldl_cons, rightStep]
        rw [hright]
        cases hq : ((small.extPositions N).filter (e < ·)).head? with
        | none => simp only [Option.map_none]; exact (ih hrest e c).2
        | some q => simp only [Option.map_some]; exact (ih hrest q (c + 1)).2
  trivial

end ErdosSzekeres
