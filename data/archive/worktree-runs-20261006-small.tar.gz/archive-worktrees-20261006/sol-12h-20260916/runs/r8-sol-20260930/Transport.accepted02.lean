import ESBlueprint.B.CtxSingleLevelOccurrencePruneBoundMono
import ESBlueprint.B.CtxBoundAdditivePrefixSuffix
import ESBlueprint.B.CtxBoundAttainedByEndCut

set_option maxHeartbeats 8000000

namespace ErdosSzekeres
open Ctx Ctx.Context

-- Local proof laboratory: all obligations are proved, with no placeholder axiom.
example : True := by
  classical
  let up (p i : ℕ) := if i < p then i else i + 1
  have hup : ∀ p, StrictMono (up p) := by
    intro p i j hij
    dsimp [up]
    split_ifs <;> omega
  have hRange : ∀ n p, p ≤ n →
      (List.range (n + 1)).filter (fun i ↦ i ≠ p) = (List.range n).map (up p) := by
    intro n
    induction n with
    | zero =>
      intro p hp
      have : p = 0 := by omega
      subst p
      simp
    | succ n ih =>
      intro p hp
      by_cases hpn : p = n + 1
      · subst p
        have hpre : (List.range (n + 1)).map (up (n + 1)) = List.range (n + 1) := by
          calc
            _ = (List.range (n + 1)).map (fun i ↦ i) := by
              apply List.map_congr_left
              intro i hi
              simp [up, List.mem_range.1 hi]
            _ = _ := List.map_id' _
        rw [List.range_succ, List.filter_append]
        have hself : (List.range (n + 1)).filter (fun i ↦ i ≠ n + 1) =
            List.range (n + 1) := by
          apply List.filter_eq_self.2
          intro i hi
          simp only [decide_eq_true_eq]
          exact Nat.ne_of_lt (List.mem_range.1 hi)
        rw [hself, hpre]
        simp
      · have hpn' : p ≤ n := by omega
        rw [List.range_succ, List.filter_append, ih p hpn', List.range_succ,
          List.map_append]
        have hnp : n + 1 ≠ p := by omega
        have hnp' : ¬ n < p := by omega
        simp [up, hnp, hnp']
  have hFilter : ∀ n p (P Q : ℕ → Bool), p ≤ n → P p = false →
      (∀ i, i < n → P (up p i) = Q i) →
      (List.range (n + 1)).filter P = ((List.range n).filter Q).map (up p) := by
    intro n p P Q hp hfalse hletter
    have hremove : (List.range (n + 1)).filter P =
        ((List.range (n + 1)).filter (fun i ↦ i ≠ p)).filter P := by
      rw [List.filter_filter]
      apply List.filter_congr
      intro i hi
      by_cases hip : i = p
      · subst i; simp [hfalse]
      · simp [hip]
    rw [hremove, hRange n p hp, List.filter_map]
    congr 1
    apply List.filter_congr
    intro i hi
    exact hletter i (List.mem_range.1 hi)
  have hGeometry : ∀ (big small : Context) p level s,
      big.maxima = small.maxima → small.maxima.length < level →
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      big.childPositions = small.childPositions.map (up p) ∧
      (∀ N ∈ small.levels, big.extPositions N = (small.extPositions N).map (up p)) ∧
      (∀ N ∈ small.levels, big.sideAt N = small.sideAt N) := by
    intro big small p level s hm hlevel hlen hp hbp hletter
    have hchildren : big.childPositions = small.childPositions.map (up p) := by
      unfold childPositions
      rw [hlen]
      apply hFilter _ p _ _ hp
      · simp [hbp]
      · intro i hi; rw [hletter i hi]
    have hexternals : ∀ N ∈ small.levels,
        big.extPositions N = (small.extPositions N).map (up p) := by
      intro N hN
      have hNle : N ≤ small.maxima.length := by
        obtain ⟨j, hj, rfl⟩ := List.mem_map.1 hN
        have := List.mem_range.1 hj
        omega
      have hne : level ≠ N := by omega
      unfold extPositions
      rw [hlen]
      apply hFilter _ p _ _ hp
      · simp [hbp, hne]
      · intro i hi; rw [hletter i hi]
    refine ⟨hchildren, hexternals, ?_⟩
    intro N hN
    unfold sideAt
    rw [hexternals N hN, List.head?_map]
    cases hh : (small.extPositions N).head? with
    | none => rfl
    | some q =>
      simp only [Option.map_some]
      have hqn : q < small.word.length :=
        List.mem_range.1 (List.mem_filter.1 (List.mem_of_mem_head? hh)).1
      rw [hletter q hqn]
  have hFolds : ∀ (big small : Context) p,
      (∀ N ∈ small.levels, big.extPositions N = (small.extPositions N).map (up p)) →
      ∀ (ls : List ℕ), (∀ N ∈ ls, N ∈ small.levels) → ∀ e c,
      (ls.foldl (leftStep big) (up p e, c)).2 =
          (ls.foldl (leftStep small) (e, c)).2 ∧
      (ls.foldl (rightStep big) (up p e, c)).2 =
          (ls.foldl (rightStep small) (e, c)).2 := by
    intro big small p hext ls
    induction ls with
    | nil => intros; exact ⟨rfl, rfl⟩
    | cons N ls ih =>
      intro hlevels e c
      have hrest := fun j hj ↦ hlevels j (List.mem_cons_of_mem N hj)
      have hleft : ((big.extPositions N).filter (· < up p e)).getLast? =
          (((small.extPositions N).filter (· < e)).getLast?).map (up p) := by
        rw [hext N (hlevels N (List.mem_cons_self ..)), List.filter_map]
        have hf : (fun i ↦ decide (up p i < up p e)) = (fun i ↦ decide (i < e)) := by
          funext i
          simp only [(hup p).lt_iff_lt]
        simp only [Function.comp_def]
        rw [hf, List.getLast?_map]
      have hright : ((big.extPositions N).filter (up p e < ·)).head? =
          (((small.extPositions N).filter (e < ·)).head?).map (up p) := by
        rw [hext N (hlevels N (List.mem_cons_self ..)), List.filter_map]
        have hf : (fun i ↦ decide (up p e < up p i)) = (fun i ↦ decide (e < i)) := by
          funext i
          simp only [(hup p).lt_iff_lt]
        simp only [Function.comp_def]
        rw [hf, List.head?_map]
      constructor
      · simp only [List.foldl_cons, leftStep]
        rw [hleft]
        cases hq : ((small.extPositions N).filter (· < e)).getLast? with
        | none => simp only [Option.map_none]; exact (ih hrest e c).1
        | some q => simp only [Option.map_some]; exact (ih hrest q (c + 1)).1
      · simp only [List.foldl_cons, rightStep]
        rw [hright]
        cases hq : ((small.extPositions N).filter (e < ·)).head? with
        | none => simp only [Option.map_none]; exact (ih hrest e c).2
        | some q => simp only [Option.map_some]; exact (ih hrest q (c + 1)).2
  have hBase : ∀ (big small : Context) p level s,
      big.a = small.a → big.u = small.u → big.k = small.k → big.maxima = small.maxima →
      small.maxima.length < level →
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      big.base = small.base := by
    intro big small p level s ha hu hk hm hlevel hlen hp hbp hletter
    obtain ⟨hchildren, hexternals, hsides⟩ :=
      hGeometry big small p level s hm hlevel hlen hp hbp hletter
    have hlevels : ∀ s top, big.levelsOn s top = small.levelsOn s top := by
      intro t top
      unfold levelsOn levels
      rw [hm]
      apply List.filter_congr
      intro N hN
      rw [hsides N hN]
    have hExt : ∀ s top e,
        big.leftExt s top (up p e) = small.leftExt s top e ∧
        big.rightExt s top (up p e) = small.rightExt s top e := by
      intro t top e
      have hmap : ∀ ls ∈ (small.levelsOn t top).sublists,
          (ls.foldl (leftStep big) (up p e, 0)).2 =
            (ls.foldl (leftStep small) (e, 0)).2 ∧
          (ls.foldl (rightStep big) (up p e, 0)).2 =
            (ls.foldl (rightStep small) (e, 0)).2 := by
        intro ls hls
        apply hFolds big small p hexternals ls
        intro N hN
        exact (List.mem_filter.1 ((List.mem_sublists.1 hls).subset hN)).1
      constructor
      · rw [leftExt_eq, leftExt_eq, hlevels]
        congr 2
        exact List.map_congr_left (fun ls hls ↦ (hmap ls hls).1)
      · rw [rightExt_eq, rightExt_eq, hlevels]
        congr 2
        exact List.map_congr_left (fun ls hls ↦ (hmap ls hls).2)
    have hchain : ∀ s e,
        big.chainExt s (up p e) (up p e) = small.chainExt s e e := by
      intro t e
      unfold chainExt
      rw [(hExt t 0 e).1, (hExt t 0 e).2]
    have hjoin : ∀ s e,
        big.joinExt s (up p e) (up p e) = small.joinExt s e e := by
      intro t e
      unfold joinExt
      rw [hchain t e, hlevels]
      congr 3
      apply List.map_congr_left
      intro N hN
      rw [(hExt t N e).1, (hExt t N e).2]
      simp [maximumAt, hm]
    unfold base
    rw [hchildren, List.head?_map]
    cases hh : small.childPositions.head? with
    | none => rfl
    | some e =>
      simp only [Option.map_some]
      have hcl : big.cupLimit (up p e) (up p e) = small.cupLimit e e := by
        unfold cupLimit
        rw [hu, hk, hchain, hjoin]
      have hpl : big.capLimit (up p e) (up p e) = small.capLimit e e := by
        unfold capLimit
        rw [ha, hk, hchain, hjoin]
      rw [hcl, hpl, hk]
  have hMapMem : ∀ p (A : List ℕ) i, up p i ∈ A.map (up p) ↔ i ∈ A := by
    intro p A i
    constructor
    · intro h
      obtain ⟨j, hj, heq⟩ := List.mem_map.1 h
      have hji := (hup p).injective heq
      simpa [hji] using hj
    · exact List.mem_map_of_mem
  have hRest : ∀ p (A B : List ℕ),
      (A.map (up p)).filter (fun i ↦ i ∉ B.map (up p)) =
        (A.filter (fun i ↦ i ∉ B)).map (up p) := by
    intro p A B
    rw [List.filter_map]
    congr 1
    apply List.filter_congr
    intro i hi
    change decide (up p i ∉ B.map (up p)) = decide (i ∉ B)
    simp only [hMapMem]
  have hBlocks : ∀ (big small : Context) p,
      big.childPositions = small.childPositions.map (up p) →
      big.blocks = small.blocks.map (fun B ↦ B.map (up p)) := by
    intro big small p hc
    simp only [blocks, hc, List.length_map]
    have hraw : ((List.range small.childPositions.length).flatMap fun i ↦
          (List.range (small.childPositions.length - i)).map fun len ↦
            ((small.childPositions.map (up p)).drop i).take (len + 1)) =
        ((List.range small.childPositions.length).flatMap fun i ↦
          (List.range (small.childPositions.length - i)).map fun len ↦
            (small.childPositions.drop i).take (len + 1)).map (fun B ↦ B.map (up p)) := by
      rw [List.map_flatMap]
      apply List.flatMap_congr
      intro i hi
      rw [List.map_map]
      apply List.map_congr_left
      intro len hlen
      simp [Function.comp_def, List.map_take, List.map_drop]
    rw [hraw, List.filter_map]
    congr 1
    apply List.filter_congr
    intro B hB
    simp [Function.comp_def]
  have hIsolatedRuns (big : Context)
      (hiso : ∀ i ∈ big.childPositions, i + 1 ∉ big.childPositions) :
      big.numRuns = big.childPositions.length := by
    unfold numRuns childPositions
    congr 1
    apply List.filter_congr
    intro i hi
    simp only [decide_eq_decide]
    constructor
    · exact And.left
    · intro hchild
      refine ⟨hchild, ?_⟩
      by_cases hi0 : i = 0
      · exact Or.inl hi0
      · right
        intro hprev
        have himem : i ∈ big.childPositions := by
          simp only [childPositions, List.mem_filter, decide_eq_true_eq]
          exact ⟨hi, hchild⟩
        have hprevmem : i - 1 ∈ big.childPositions := by
          simp only [childPositions, List.mem_filter, List.mem_range, decide_eq_true_eq]
          exact ⟨by have := List.mem_range.1 hi; omega, hprev⟩
        have := hiso (i - 1) hprevmem
        have heq : i - 1 + 1 = i := by omega
        exact this (heq.symm ▸ himem)
  have hAdjacent (big small : Context) (p : ℕ)
      (hc : big.childPositions = small.childPositions.map (up p))
      (hiso : ∀ i ∈ big.childPositions, i + 1 ∉ big.childPositions) :
      ∀ i ∈ small.childPositions, i + 1 ∈ small.childPositions → i + 1 = p := by
    intro i hi hnext
    by_contra hne
    have hib : up p i ∈ big.childPositions := by rw [hc]; exact List.mem_map_of_mem hi
    have hnb : up p (i + 1) ∈ big.childPositions := by
      rw [hc]; exact List.mem_map_of_mem hnext
    have heq : up p (i + 1) = up p i + 1 := by
      dsimp [up]
      split_ifs <;> omega
    exact hiso _ hib (heq ▸ hnb)
  trivial

end ErdosSzekeres
