"""R3 candidate tracks an original internal opposite cut through legal descendants.

Random sources start with q0:1U internal to ancestor child positions and old
chosen markers 2L,3L with x<y<q0 or q0<y<x. The admission cut removes an
internal 1- or 2-child interval on one side of q0, with new lower maximum k-4
(middle) or upper maximum1 (swapped). Further rows use proper interval cuts.
No initial or descendant child multiplicity is compressed.
"""
import hashlib
from pathlib import Path
import random

import charge_certificate as engine
from charge_profile_capacity_candidate import shared_nontrivial_profile
from harness.research.primitives import part


def cut_ancestry(word, maxima, limits, rank, k):
    lower = {}
    for p, letter in enumerate(word):
        if letter != "S" and letter[1] == "lower" and letter[0] <= len(maxima):
            lower.setdefault(letter[0], []).append(p)
    oldest = sorted(lower)[-2:]
    if len(oldest) != 2 or any(len(lower[j]) != 1 for j in oldest):
        return False
    x, y = (lower[j][0] for j in oldest)

    def colors(j):
        return [int(letter != "S" and letter[0] == j) for letter in word
                if letter == "S" or letter[0] <= j]

    def runs(sequence, color):
        return sum(value == color and (i == 0 or sequence[i-1] != color)
                   for i, value in enumerate(sequence))

    levels = {letter[0] for letter in word if letter != "S" and
              letter[1] == "upper" and letter[0] < oldest[0] and
              1 <= letter[0] <= len(maxima) and maxima[letter[0]-1] == 1}
    for qlevel in levels:
        qpositions = [p for p, letter in enumerate(word) if letter == (qlevel, "upper")]
        if not any(x < y < q or q < y < x for q in qpositions):
            continue
        root = colors(qlevel)
        if not root or root[0] != 0 or root[-1] != 0 or runs(root, 1) != 1:
            continue
        legal = True
        for j in range(1, qlevel):
            sequence = colors(j)
            if not (0 in sequence and 1 in sequence and
                    (runs(sequence, 0) == 1 or runs(sequence, 1) == 1)):
                legal = False
                break
        if legal:
            return True
    return False


def legal_descendants(k, count, samples, rank):
    rng = random.Random(20260930 + 1000 * k + count)
    for _ in range(samples):
        reductions = [rng.randint(1, 2) for _ in range(rng.randint(0, 2))]
        removed_count = rng.randint(1, 2)
        initial_count = count + sum(reductions) + removed_count
        while True:
            word = ["S"] * initial_count + [(1, "upper"), (2, "lower"), (3, "lower")]
            rng.shuffle(word)
            q, x, y = (word.index(letter) for letter in ((1, "upper"), (2, "lower"), (3, "lower")))
            children = [p for p, letter in enumerate(word) if letter == "S"]
            if not (children[0] < q < children[-1] and (x < y < q or q < y < x)):
                continue
            choices = [children[start:start+removed_count]
                       for start in range(1, initial_count - removed_count)
                       if all(p < q for p in children[start:start+removed_count]) or
                          all(q < p for p in children[start:start+removed_count])]
            if choices:
                removed = rng.choice(choices)
                break
        parent = {"word": tuple(word), "maxima": (1,1,1), "a": rank,
                  "u": rank, "k": k, "chosen": "lower"}
        mode = rng.choice(("middle", "swapped"))
        side, maximum = ("lower", k-4) if mode == "middle" else ("upper", 1)
        kept = set(children) - set(removed)
        row = part(parent, kept, side, maximum)
        lineage = {"ancestor": parent, "root_mode": mode,
                   "root_kept": sorted(kept), "steps": []}
        for reduction in reductions:
            children = [p for p, letter in enumerate(row["word"]) if letter == "S"]
            if rng.choice((True, False)):
                start = rng.randrange(reduction + 1)
                kept = set(children[start:start+len(children)-reduction])
            else:
                start = rng.randrange(len(children)-reduction+1)
                kept = set(children) - set(children[start:start+reduction])
            side, maximum = rng.choice(("lower", "upper")), rng.randint(1, k-2)
            lineage["steps"].append({"kept": sorted(kept), "side": side, "maximum": maximum})
            row = part(row, kept, side, maximum)
        assert sum(letter == "S" for letter in row["word"]) == count
        row["r3_lineage"] = lineage
        yield row, "legal-descendant"


engine.EXTRA_FEATURES = (shared_nontrivial_profile, cut_ancestry)
engine.EXTRA_FEATURE_NAMES = ("low_plus_common_opposite_capacity_ge4_shared_profile",
                              "original_internal_opposite_cut_with_legal_younger_history")
engine.CANDIDATE_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
engine.CANDIDATES = {
    "lower_profile_capacity_cut_ancestry": (0, ((7, 10, 11),)),
    "mixed_both_dense_opposed_cut_ancestry": (2, ((0, 1, 2, 4, 11),)),
}
engine.random_family = legal_descendants

if __name__ == "__main__":
    engine.main()
