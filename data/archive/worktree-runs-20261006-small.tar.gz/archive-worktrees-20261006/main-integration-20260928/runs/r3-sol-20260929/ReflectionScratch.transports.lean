import ESBlueprint.B.CtxReverseExtensionTransport

set_option maxHeartbeats 4000000
set_option maxRecDepth 10000

namespace ErdosSzekeres

-- Scratch local facts only. This example is not the registered target or theorem credit.
example : True := by
  classical
  let rev (τ : Ctx.Context) : Ctx.Context := { τ with word := τ.word.reverse }
  let flip (τ : Ctx.Context) (p : ℕ) := τ.word.length - 1 - p
  have hrev : ∀ τ, rev (rev τ) = τ := by
    intro τ
    cases τ
    simp [rev]
  have hlt : ∀ τ p, p < τ.word.length → flip τ p < τ.word.length := by
    intro τ p hp
    dsimp [flip]
    omega
  have hinv : ∀ τ p, p < τ.word.length → flip τ (flip τ p) = p := by
    intro τ p hp
    dsimp [flip]
    omega
  have hletter : ∀ τ p, p < τ.word.length →
      (rev τ).letterAt (flip τ p) = τ.letterAt p := by
    intro τ p hp
    simp only [Ctx.Context.letterAt, rev, List.getElem?_reverse (hlt τ p hp)]
    change τ.word[flip τ (flip τ p)]?.getD Ctx.Letter.child =
      τ.word[p]?.getD Ctx.Letter.child
    rw [hinv τ p hp]
  have hrange : ∀ τ, (List.range τ.word.length).reverse.map (flip τ) =
      List.range τ.word.length := by
    intro τ
    have h : (List.range τ.word.length).map (flip τ) =
        (List.range τ.word.length).reverse := by
      simpa [flip, ← List.range_eq_range'] using
        (List.reverse_range' (s := 0) (n := τ.word.length)).symm
    rw [List.map_reverse, h, List.reverse_reverse]
  have hchild : ∀ τ, (rev τ).childPositions =
      τ.childPositions.reverse.map (flip τ) := by
    intro τ
    unfold Ctx.Context.childPositions
    simp only [rev, List.length_reverse]
    calc
      _ = ((List.range τ.word.length).reverse.map (flip τ)).filter
          (fun p => decide ((rev τ).letterAt p = Ctx.Letter.child)) := by rw [hrange]
      _ = ((List.range τ.word.length).filter (fun p =>
          decide ((rev τ).letterAt (flip τ p) = Ctx.Letter.child))).reverse.map
          (flip τ) := by rw [List.filter_map, List.filter_reverse]; rfl
      _ = _ := by
        congr 2
        apply List.filter_congr
        intro p hp
        rw [hletter τ p (List.mem_range.mp hp)]
  have hchildLen : ∀ τ, (rev τ).childPositions.length = τ.childPositions.length := by
    intro τ
    rw [hchild]
    simp
  have hmem : ∀ (τ : Ctx.Context) p, p ∈ τ.childPositions → p < τ.word.length := by
    intro τ p hp
    exact List.mem_range.mp (List.mem_filter.mp hp).1
  have hkeepMem : ∀ τ (keep : List ℕ), (∀ p ∈ keep, p < τ.word.length) →
      ∀ p, p < τ.word.length →
        (flip τ p ∈ keep.reverse.map (flip τ) ↔ p ∈ keep) := by
    intro τ keep hk p hp
    simp only [List.mem_map, List.mem_reverse]
    constructor
    · rintro ⟨q, hq, he⟩
      have hi := congrArg (flip τ) he
      rw [hinv τ q (hk q hq), hinv τ p hp] at hi
      simpa [hi] using hq
    · intro hpk
      exact ⟨p, hpk, rfl⟩
  have hpart : ∀ τ (keep : List ℕ), (∀ p ∈ keep, p < τ.word.length) →
      ∀ s m, rev (τ.part keep s m) =
        (rev τ).part (keep.reverse.map (flip τ)) s m := by
    intro τ keep hk s m
    let f (p : ℕ) := match τ.letterAt p with
      | Ctx.Letter.child => if p ∈ keep then Ctx.Letter.child else Ctx.Letter.ext 1 s
      | Ctx.Letter.ext l v => Ctx.Letter.ext (l + 1) v
    let g (p : ℕ) := match (rev τ).letterAt p with
      | Ctx.Letter.child => if p ∈ keep.reverse.map (flip τ) then
          Ctx.Letter.child else Ctx.Letter.ext 1 s
      | Ctx.Letter.ext l v => Ctx.Letter.ext (l + 1) v
    have hfg : ∀ p ∈ List.range τ.word.length, g (flip τ p) = f p := by
      intro p hp
      have hp' := List.mem_range.mp hp
      dsimp only [f, g]
      rw [hletter τ p hp']
      cases τ.letterAt p with
      | child => simp only [hkeepMem τ keep hk p hp']
      | ext l v => rfl
    have hw : ((List.range τ.word.length).map f).reverse =
        (List.range (rev τ).word.length).map g := by
      simp only [rev, List.length_reverse]
      calc
        _ = (List.range τ.word.length).reverse.map f := List.map_reverse.symm
        _ = (List.range τ.word.length).reverse.map (fun p => g (flip τ p)) := by
          apply List.map_congr_left
          intro p hp
          exact (hfg p (List.mem_reverse.mp hp)).symm
        _ = ((List.range τ.word.length).reverse.map (flip τ)).map g := by rw [List.map_map]; rfl
        _ = _ := by rw [hrange]
    cases τ
    simp only [rev, Ctx.Context.part]
    congr 1
  have hrest : ∀ τ (keep : List ℕ), (∀ p ∈ keep, p < τ.word.length) →
      (τ.childPositions.filter (· ∉ keep)).reverse.map (flip τ) =
        (rev τ).childPositions.filter (· ∉ keep.reverse.map (flip τ)) := by
    intro τ keep hk
    rw [hchild, List.filter_map, List.filter_reverse]
    congr 2
    apply List.filter_congr
    intro p hp
    simp only [Function.comp_def, decide_eq_decide]
    exact not_congr (hkeepMem τ keep hk p (hmem τ p hp)).symm
  have hblockData : ∀ (τ : Ctx.Context) (keep : List ℕ), keep ∈ τ.blocks →
      keep ≠ [] ∧ keep.length < τ.childPositions.length ∧ keep <:+: τ.childPositions := by
    intro τ keep hk
    simp only [Ctx.Context.blocks, List.mem_filter, List.mem_flatMap,
      List.mem_range, List.mem_map, decide_eq_true_eq] at hk
    obtain ⟨⟨i, hi, l, hl, rfl⟩, hlen⟩ := hk
    refine ⟨?_, hlen, ?_⟩
    · have hd : 0 < (τ.childPositions.drop i).length := by
        simp only [List.length_drop]
        omega
      apply List.ne_nil_of_length_pos
      simp only [List.length_take]
      omega
    · refine ⟨τ.childPositions.take i, (τ.childPositions.drop i).drop (l+1), ?_⟩
      rw [List.append_assoc, List.take_append_drop, List.take_append_drop]
  have hblock : ∀ τ (keep : List ℕ), keep ∈ τ.blocks →
      keep.reverse.map (flip τ) ∈ (rev τ).blocks := by
    intro τ keep hk
    obtain ⟨hne, hlen, hInfix⟩ := hblockData τ keep hk
    have h : keep.reverse.map (flip τ) <:+: (rev τ).childPositions := by
      rw [hchild]
      exact hInfix.reverse.map (flip τ)
    obtain ⟨pre, post, he⟩ := h
    have hlength := congrArg List.length he
    simp only [List.length_append] at hlength
    have hpos : 0 < (keep.reverse.map (flip τ)).length := by
      simpa using List.length_pos_iff.mpr hne
    have hproper : (keep.reverse.map (flip τ)).length < (rev τ).childPositions.length := by
      simpa only [List.length_map, List.length_reverse, hchildLen] using hlen
    simp only [Ctx.Context.blocks, List.mem_filter, List.mem_flatMap,
      List.mem_range, List.mem_map, decide_eq_true_eq]
    refine ⟨⟨pre.length, by omega, (keep.reverse.map (flip τ)).length - 1,
      by omega, ?_⟩, hproper⟩
    rw [Nat.sub_add_cancel (by omega : 1 ≤ (keep.reverse.map (flip τ)).length)]
    have hslice : ((pre ++ keep.reverse.map (flip τ) ++ post).drop pre.length).take
        (keep.reverse.map (flip τ)).length = keep.reverse.map (flip τ) := by
      simp [List.append_assoc]
    exact (congrArg (fun xs : List ℕ => (xs.drop pre.length).take
      (keep.reverse.map (flip τ)).length) he).symm.trans hslice
  exact True.intro

end ErdosSzekeres
