"""R3 finite inheritance diagnostic; no Lean-equivalence or theorem credit.

Families: four distinct actual markers, all permutations and all child gap
compositions at each requested total child count. The level-one marker is
internal to the children; optionally repeat that marker as a contiguous block.
The older chosen markers x,y and opposite marker q obey x<y<q or q<y<x.
Middle maxima are (k-4,1,1,1), swapped maxima (1,1,1,1).

Psi_L/Psi_U are sums of the two original-history pruning bounds, grouped by
point capacity <=2 / >=3 on that axis. Psi_best is their minimum. These are
independent group charges, not the source's exact bound. For a saving source,
test every proper child interval, every coupled maximum and both orientations.
We allow the strongest possible child predicate B(child)<=Psi(child)-1:
failure with this relaxation also defeats any geometric subpredicate for the
same potential. At k=7/globals=6 the capacity-three theorem needs separate
hypothesis checks; evaluator inequalities there remain purely diagnostic.
"""
from __future__ import annotations

import argparse
from functools import lru_cache
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.primitives import part
from harness.research.recursive import evaluator
from decomposable_depth2_tables import limits_from_signature

COMPILED_PATH = Path(__file__).with_name("context_bound.py")
spec = importlib.util.spec_from_file_location("r3_compiled_context_bound", COMPILED_PATH)
compiled_module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(compiled_module)


def point_limits(word, maxima, a, u, k):
    _, cups, caps = limits_from_signature(word, maxima, a, u, k, lean=True)
    run = -1
    previous = False
    result = {}
    for p, letter in enumerate(word):
        if letter == "S":
            if not previous:
                run += 1
            result[p] = (int(cups[run][run]), int(caps[run][run]))
        previous = letter == "S"
    return result


def compositions(total, slots):
    if slots == 1:
        yield (total,)
    else:
        for first in range(total + 1):
            for tail in compositions(total - first, slots - 1):
                yield (first,) + tail


def family(k, count, repeats, global_rank):
    for mode in ("middle", "swapped"):
        markers = ((1, "lower" if mode == "middle" else "upper"),
                   (2, "upper"), (3, "lower"), (4, "lower"))
        maxima = (k - 4 if mode == "middle" else 1, 1, 1, 1)
        for order in itertools.permutations(markers):
            for gaps in compositions(count, 5):
                word = []
                positions = {}
                for i, marker in enumerate(order):
                    word.extend(["S"] * gaps[i])
                    positions[marker[0]] = len(word)
                    word.extend([marker] * (repeats if marker[0] == 1 else 1))
                word.extend(["S"] * gaps[4])
                z, q, x, y = (positions[j] for j in (1, 2, 3, 4))
                children = [p for p, letter in enumerate(word) if letter == "S"]
                if not (any(p < z for p in children) and
                        any(z + repeats - 1 < p for p in children)):
                    continue
                if not (x < y < q or q < y < x):
                    continue
                yield {"word": tuple(word), "maxima": maxima, "a": global_rank,
                       "u": global_rank, "k": k, "chosen": "lower"}, mode


def row_key(row):
    return row["word"], row["maxima"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--crosscheck", action="store_true")
    parser.add_argument("--k", type=int, default=6)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--global-rank", type=int)
    args = parser.parse_args()
    started = time.monotonic()
    if args.crosscheck:
        records = []
        for k in (6, 7):
            c_bound = compiled_module.compiled_evaluator(5, 5, k, cache_size=16000)
            py_bound = evaluator(5, 5, k, semantics="context-bound-zero-children-v1",
                                 cache_size=16000)
            for row, mode in itertools.islice(family(k, 3, 1, 5), 24):
                word, maxima = row_key(row)
                words = [word]
                limits = point_limits(word, maxima, 5, 5, k)
                for axis in (0, 1):
                    for low in (True, False):
                        support = {p for p, cap in limits.items()
                                   if (cap[axis] <= 2) == low}
                        pruned = tuple(letter if letter != "S" or p in support
                                       else (len(maxima) + 1, "lower")
                                       for p, letter in enumerate(word))
                        if "S" in pruned:
                            words.append(pruned)
                for sample_word in words:
                    c, p = c_bound(sample_word, maxima), py_bound(sample_word, maxima)
                    records.append({"row": {**row, "word": sample_word}, "mode": mode,
                                    "compiled": c, "python": p})
                    if c != p:
                        raise AssertionError(records[-1])
        payload = {"semantics": compiled_module.SEMANTICS, "records": records,
                   "agreement": all(r["compiled"] == r["python"] for r in records),
                   "seconds": time.monotonic() - started}
        args.output.write_text(json.dumps(payload, indent=2) + "\n")
        print(json.dumps({"samples": len(records), "agreement": payload["agreement"],
                          "seconds": payload["seconds"]}), flush=True)
        return
    k = args.k
    global_rank = args.global_rank or k - 1
    compiled = compiled_module.compiled_evaluator(global_rank, global_rank, k, cache_size=64000)

    @lru_cache(maxsize=64000)
    def bound(word, maxima):
        return compiled(word, maxima) if "S" in word else 0

    @lru_cache(maxsize=64000)
    def potentials(word, maxima):
        limits = point_limits(word, maxima, global_rank, global_rank, k)
        charges = []
        for axis in (0, 1):
            groups = ({p for p, cap in limits.items() if cap[axis] <= 2},
                      {p for p, cap in limits.items() if cap[axis] >= 3})
            total = 0
            for support in groups:
                pruned = tuple(letter if letter != "S" or p in support
                               else (len(maxima) + 1, "lower")
                               for p, letter in enumerate(word))
                total += bound(pruned, maxima)
            charges.append(total)
        return tuple(charges + [min(charges)])

    names = ("capacity_lower", "capacity_upper", "capacity_best")
    stats = {name: {"saving_sources": 0, "bad_charge_sources": 0,
                    "cuts_tested": 0, "inheritance_failures": 0,
                    "first_failure": None, "first_bad_charge": None, "saving_examples": []}
             for name in names}
    by_mode = {}
    tested = 0
    for count in range(2, args.max_children + 1):
        for row, mode in family(k, count, args.repeats, global_rank):
            tested += 1
            word, maxima = row_key(row)
            exact, psi = bound(word, maxima), potentials(word, maxima)
            label = f"{mode}:children={count}"
            summary = by_mode.setdefault(label, {"contexts": 0, "maximum": 0})
            summary["contexts"] += 1
            summary["maximum"] = max(summary["maximum"], exact)
            saving = []
            for i, name in enumerate(names):
                if exact > psi[i]:
                    stats[name]["bad_charge_sources"] += 1
                    if stats[name]["first_bad_charge"] is None:
                        stats[name]["first_bad_charge"] = {"row": row, "bound": exact,
                                                            "psi": psi[i]}
                if exact <= psi[i] - 1:
                    stats[name]["saving_sources"] += 1
                    saving.append(i)
                    if len(stats[name]["saving_examples"]) < 6:
                        stats[name]["saving_examples"].append({
                            "mode": mode, "row": row, "bound": exact, "psi": psi[i],
                            "capacities": point_limits(word, maxima, global_rank, global_rank, k)})
            if not saving:
                continue
            children = tuple(p for p, letter in enumerate(word) if letter == "S")
            for start in range(count):
                for length in range(1, count - start + 1):
                    if length == count:
                        continue
                    keep = frozenset(children[start:start + length])
                    rest = frozenset(children) - keep
                    for lower_m in range(1, k - 1):
                        upper_m = k - 1 - lower_m
                        for side in ("lower", "upper"):
                            other = "upper" if side == "lower" else "lower"
                            m = lower_m if side == "lower" else upper_m
                            n = upper_m if side == "lower" else lower_m
                            left = part(row, keep, side, m)
                            right = part(row, rest, other, n)
                            left_key, right_key = row_key(left), row_key(right)
                            left_psi, right_psi = potentials(*left_key), potentials(*right_key)
                            left_bound, right_bound = bound(*left_key), bound(*right_key)
                            for i in saving:
                                stats[names[i]]["cuts_tested"] += 1
                                total = left_psi[i] + right_psi[i]
                                inherited = (total <= psi[i] - 1 or
                                             (total <= psi[i] and
                                              (left_bound <= left_psi[i] - 1 or
                                               right_bound <= right_psi[i] - 1)))
                                if not inherited:
                                    stats[names[i]]["inheritance_failures"] += 1
                                    if stats[names[i]]["first_failure"] is None:
                                        stats[names[i]]["first_failure"] = {
                                            "mode": mode, "row": row, "bound": exact,
                                            "psi": psi[i], "keep": sorted(keep),
                                            "parts": [left, right],
                                            "part_bounds": [left_bound, right_bound],
                                            "part_psi": [left_psi[i], right_psi[i]],
                                            "reason": "charge swelling" if total > psi[i]
                                                      else "no saving child"}
            if tested % 50 == 0:
                print(json.dumps({"contexts": tested, "label": label,
                                  "seconds": time.monotonic() - started}), flush=True)
        payload = {"semantics": compiled_module.SEMANTICS, "diagnostic_only": True,
                   "potential_contract": __doc__, "k": k, "global_rank": global_rank,
                   "max_children_completed": count, "repeated_level_one": args.repeats,
                   "contexts": tested, "by_mode": by_mode, "stats": stats,
                   "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   "seconds": time.monotonic() - started}
        args.output.write_text(json.dumps(payload, indent=2) + "\n")
        print(json.dumps({"completed_children": count, "contexts": tested,
                          "stats": {name: {key: value for key, value in st.items()
                                           if not key.startswith("first_") and key != "saving_examples"}
                                    for name, st in stats.items()},
                          "seconds": payload["seconds"]}), flush=True)


if __name__ == "__main__":
    main()
