import ErdosSzekeres.DecomposableContext

namespace ErdosSzekeres
open Ctx Ctx.Context

-- #eval receipts are diagnostic computations, not registered theorem credit.
-- Output: source B, lower-low group B, lower-high group B, point limits.
#eval Id.run do
  let σ : Context := ⟨5, 5, 6,
    [.child, .child, .ext 3 .lower, .ext 4 .lower, .ext 5 .lower,
      .child, .ext 1 .upper], [2,1,1,1,1]⟩
  let prune (low : Bool) : Context := ⟨σ.a, σ.u, σ.k,
    (List.range σ.word.length).map (fun p => match σ.letterAt p with
      | .child => if (if low then σ.cupLimit p p ≤ 2 else 3 ≤ σ.cupLimit p p)
          then .child else .ext (σ.maxima.length + 1) .lower
      | .ext j s => .ext j s), σ.maxima⟩
  return (σ.bound, (prune true).bound, (prune false).bound,
    σ.childPositions.map fun p => (p, σ.cupLimit p p, σ.capLimit p p))

#eval Id.run do
  let σ : Context := ⟨5, 5, 7,
    [.ext 3 .upper, .child, .child, .ext 1 .lower, .ext 4 .lower,
      .ext 5 .lower, .child, .ext 2 .upper], [2,1,1,1,1]⟩
  let prune (low : Bool) : Context := ⟨σ.a, σ.u, σ.k,
    (List.range σ.word.length).map (fun p => match σ.letterAt p with
      | .child => if (if low then σ.cupLimit p p ≤ 2 else 3 ≤ σ.cupLimit p p)
          then .child else .ext (σ.maxima.length + 1) .lower
      | .ext j s => .ext j s), σ.maxima⟩
  let keep := [1]
  return (σ.bound, (prune true).bound, (prune false).bound,
    (σ.part keep .upper 5).bound,
    (σ.part (σ.childPositions.filter (· ∉ keep)) .lower 1).bound,
    σ.childPositions.map fun p => (p, σ.cupLimit p p, σ.capLimit p p))

-- Final terminal-union failures have replayable legal interval-cut ancestry.
#eval Id.run do
  let σ : Context := ⟨5, 5, 6,
    [.ext 1 .upper, .child, .ext 3 .upper, .child, .ext 5 .lower,
      .ext 4 .lower, .ext 2 .lower, .child], [3,2,1,1,1]⟩
  let prune (low : Bool) : Context := ⟨σ.a, σ.u, σ.k,
    (List.range σ.word.length).map (fun p => match σ.letterAt p with
      | .child => if (if low then σ.cupLimit p p ≤ 2 else 3 ≤ σ.cupLimit p p)
          then .child else .ext (σ.maxima.length + 1) .lower
      | .ext j s => .ext j s), σ.maxima⟩
  let keep := [1]
  return (σ.bound, (prune true).bound, (prune false).bound,
    (σ.part keep .lower 2).bound,
    (σ.part (σ.childPositions.filter (· ∉ keep)) .upper 3).bound,
    σ.childPositions.map fun p => (p, σ.cupLimit p p, σ.capLimit p p))

#eval Id.run do
  let σ : Context := ⟨5, 5, 7,
    [.ext 2 .upper, .ext 3 .lower, .child, .ext 5 .lower, .ext 6 .lower,
      .ext 4 .upper, .child, .child, .ext 1 .upper], [3,3,3,1,1,1]⟩
  let prune (low : Bool) : Context := ⟨σ.a, σ.u, σ.k,
    (List.range σ.word.length).map (fun p => match σ.letterAt p with
      | .child => if (if low then σ.cupLimit p p ≤ 2 else 3 ≤ σ.cupLimit p p)
          then .child else .ext (σ.maxima.length + 1) .lower
      | .ext j s => .ext j s), σ.maxima⟩
  let keep := [2,6]
  return (σ.bound, (prune true).bound, (prune false).bound,
    (σ.part keep .upper 4).bound,
    (σ.part (σ.childPositions.filter (· ∉ keep)) .lower 2).bound,
    σ.childPositions.map fun p => (p, σ.cupLimit p p, σ.capLimit p p))

end ErdosSzekeres
