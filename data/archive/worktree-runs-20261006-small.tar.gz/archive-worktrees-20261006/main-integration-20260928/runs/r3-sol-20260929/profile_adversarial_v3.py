"""Broader-domain falsification of the shared-profile candidate, diagnostic only.

Use the registered exhaustive context generator before deterministic random
histories. Stop at the first violation of the strict-saving implication.
"""
from __future__ import annotations
import argparse
import itertools
import json
from pathlib import Path
import random
import time

from gate_probe import compiled_module, point_limits
from harness.research.primitives import extension
from decomposable_additivity_test import contexts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--random-count", type=int, default=2000)
    args = parser.parse_args()
    k = args.k
    compiled = compiled_module.compiled_evaluator(5, 5, k, cache_size=262144)
    started = time.monotonic()
    tested = hits = 0
    violation = None
    rng = random.Random(20260929 + k)

    def random_contexts():
        for _ in range(args.random_count):
            depth = rng.randint(3, 5)
            sides = {j: rng.choice(("lower", "upper")) for j in range(1, depth-1)}
            word = ["S"] * rng.randint(2, 4)
            word += [(depth-1, "lower"), (depth, "lower")]
            for _ in range(rng.randint(1, 4)):
                level = rng.randint(1, depth-2)
                word.append((level, sides[level]))
            rng.shuffle(word)
            maxima = tuple(rng.randint(1, k-2) for _ in range(depth-2)) + (1, 1)
            yield tuple(word), maxima

    sources = itertools.chain(contexts(3, 3, 2, k, include_unused_levels=True), random_contexts())
    for word, maxima in sources:
        tested += 1
        chosen_levels = {}
        for p, letter in enumerate(word):
            if letter != "S" and letter[1] == "lower" and letter[0] <= len(maxima):
                chosen_levels.setdefault(letter[0], []).append(p)
        if len(chosen_levels) < 2:
            continue
        oldest = sorted(chosen_levels)[-2:]
        if any(len(chosen_levels[level]) != 1 or maxima[level-1] != 1 for level in oldest):
            continue
        limits = point_limits(word, maxima, 5, 5, k)
        profiles = []
        supports = []
        for low in (True, False):
            supports.append({p for p, cap in limits.items() if (cap[0] <= 2) == low})
            profiles.append({(extension(word, len(maxima), "upper", p, True),
                              extension(word, len(maxima), "upper", p, False))
                             for p in supports[-1] if min(limits[p]) > 0})
        if not profiles[0] & profiles[1]:
            continue
        hits += 1
        charge = 0
        for support in supports:
            pruned = tuple(letter if letter != "S" or p in support
                           else (len(maxima)+1, "lower") for p, letter in enumerate(word))
            charge += compiled(pruned, maxima) if "S" in pruned else 0
        exact = compiled(word, maxima)
        if exact >= charge:
            violation = {"word": word, "maxima": maxima, "a": 5, "u": 5, "k": k,
                         "capacities": limits, "profiles": [sorted(p) for p in profiles],
                         "supports": [sorted(s) for s in supports], "bound": exact,
                         "psi_lower": charge}
            break
    payload = {"semantics": compiled_module.SEMANTICS, "diagnostic_only": True,
               "predicate": "shared profile plus two oldest lower levels singleton and maximum one",
               "k": k, "tested": tested, "predicate_hits": hits, "violation": violation,
               "random_seed": 20260929 + k, "random_count_requested": args.random_count,
               "random_domain": "conditioned two oldest lower singleton maxima1, arbitrary younger history",
               "seconds": time.monotonic() - started}
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"tested": tested, "predicate_hits": hits,
                      "violation": violation is not None, "seconds": payload["seconds"]}), flush=True)


if __name__ == "__main__":
    main()
