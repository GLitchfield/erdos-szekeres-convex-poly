"""R3 ancestry candidate permits low1/opposite2 saving children; excludes opposite1."""
import hashlib
from pathlib import Path

import charge_ancestry_candidate as ancestry
from harness.research.primitives import extension

engine = ancestry.engine


def shared_nontrivial_profile(word, maxima, limits, rank, k):
    low = [p for p, cap in limits.items() if 0 < cap[0] <= 2 and cap[1] >= 2]
    high = [p for p, cap in limits.items() if cap[0] >= 3 and cap[1] >= 2]
    profile = lambda p: (extension(word, len(maxima), "upper", p, True),
                         extension(word, len(maxima), "upper", p, False))
    return any(profile(lp) == profile(hp) for lp in low for hp in high)


engine.EXTRA_FEATURES = (shared_nontrivial_profile, ancestry.cut_ancestry)
engine.EXTRA_FEATURE_NAMES = ("chosen_low_high_share_upper_profile_and_both_upper_capacities_ge2",
                              "original_internal_opposite_cut_with_legal_younger_history")
engine.CANDIDATE_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
engine.CANDIDATES = {
    "lower_nontrivial_profile_cut_ancestry": (0, ((7, 10, 11),)),
    "mixed_both_dense_opposed_cut_ancestry": (2, ((0, 1, 2, 4, 11),)),
}

if __name__ == "__main__":
    engine.main()
