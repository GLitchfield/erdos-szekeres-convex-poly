"""R3 candidate only; reuse the recorded charge-certificate engine without compression."""
import hashlib
from pathlib import Path

import charge_certificate as engine
from harness.research.primitives import extension


def shared_nontrivial_profile(word, maxima, limits, rank, k):
    low = [(p, cap) for p, cap in limits.items() if 0 < cap[0] <= 2 and cap[1] >= 2]
    high = [(p, cap) for p, cap in limits.items() if cap[0] >= 3 and cap[1] >= 2]
    profile = lambda p: (extension(word, len(maxima), "upper", p, True),
                         extension(word, len(maxima), "upper", p, False))
    return any(lcap[0] + min(lcap[1], hcap[1]) >= 4 and profile(lp) == profile(hp)
               for lp, lcap in low for hp, hcap in high)


engine.EXTRA_FEATURES = (shared_nontrivial_profile,)
engine.EXTRA_FEATURE_NAMES = ("low_plus_common_opposite_capacity_ge4_shared_profile",)
engine.CANDIDATE_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
engine.CANDIDATES = {
    "lower_profile_capacity_complete_history": (0, ((7, 8, 9, 10),)),
    "mixed_both_dense_opposed": (2, ((0, 1, 2, 4),)),
}

if __name__ == "__main__":
    engine.main()
