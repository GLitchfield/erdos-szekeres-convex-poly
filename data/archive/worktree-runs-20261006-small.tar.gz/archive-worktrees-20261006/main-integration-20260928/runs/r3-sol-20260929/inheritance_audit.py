"""Recursive finite cut-closure audit for the R3 fixed pruning potentials.

This is diagnostic only. It allows exact-bound saving as the broadest possible
predicate, then audits that predicate recursively on every required child.
Failure defeats this potential on that source, irrespective of the chosen
geometric subpredicate. Success does NOT furnish a small-feature predicate.
"""
from __future__ import annotations
import argparse
from functools import lru_cache
import json
from pathlib import Path
import time

from gate_probe import compiled_module, family, part, point_limits, row_key


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument("--global-rank", type=int)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    k, rank = args.k, args.global_rank or args.k - 1
    compiled = compiled_module.compiled_evaluator(rank, rank, k, cache_size=64000)
    started = time.monotonic()

    @lru_cache(maxsize=128000)
    def bound(word, maxima):
        return compiled(word, maxima) if "S" in word else 0

    @lru_cache(maxsize=128000)
    def psi(word, maxima):
        limits = point_limits(word, maxima, rank, rank, k)
        charges = []
        for axis in (0, 1):
            total = 0
            for low in (True, False):
                support = {p for p, cap in limits.items() if (cap[axis] <= 2) == low}
                pruned = tuple(letter if letter != "S" or p in support
                               else (len(maxima) + 1, "lower")
                               for p, letter in enumerate(word))
                total += bound(pruned, maxima)
            charges.append(total)
        return tuple(charges + [min(charges)])

    @lru_cache(maxsize=128000)
    def inherited(word, maxima, axis):
        exact, charge = bound(word, maxima), psi(word, maxima)[axis]
        if exact >= charge:
            return False, {"reason": "not strictly saving", "bound": exact, "psi": charge}
        row = {"word": word, "maxima": maxima, "a": rank, "u": rank,
               "k": k, "chosen": "lower"}
        children = tuple(p for p, letter in enumerate(word) if letter == "S")
        for start in range(len(children)):
            for length in range(1, len(children) - start + 1):
                if length == len(children):
                    continue
                keep = frozenset(children[start:start + length])
                rest = frozenset(children) - keep
                for lower_m in range(1, k - 1):
                    upper_m = k - 1 - lower_m
                    for side in ("lower", "upper"):
                        other = "upper" if side == "lower" else "lower"
                        m = lower_m if side == "lower" else upper_m
                        n = upper_m if side == "lower" else lower_m
                        left, right = part(row, keep, side, m), part(row, rest, other, n)
                        lk, rk = row_key(left), row_key(right)
                        lp, rp = psi(*lk)[axis], psi(*rk)[axis]
                        if lp + rp <= charge - 1:
                            continue
                        witness = {"row": row, "bound": exact, "psi": charge,
                                   "keep": sorted(keep), "parts": [left, right],
                                   "part_psi": [lp, rp],
                                   "part_bounds": [bound(*lk), bound(*rk)]}
                        if lp + rp > charge:
                            return False, {**witness, "reason": "charge swelling"}
                        left_ok, left_witness = inherited(*lk, axis)
                        right_ok, right_witness = inherited(*rk, axis)
                        if not (left_ok or right_ok):
                            return False, {**witness, "reason": "no recursively saving child",
                                           "child_failures": [left_witness, right_witness]}
        return True, None

    names = ("capacity_lower", "capacity_upper", "capacity_best")
    stats = {name: {"saving_sources": 0, "recursively_inherited": 0,
                    "failed_sources": 0, "first_failure": None,
                    "first_pass": None} for name in names}
    tested = 0
    for count in range(2, args.max_children + 1):
        for row, mode in family(k, count, args.repeats, rank):
            tested += 1
            key = row_key(row)
            exact, charges = bound(*key), psi(*key)
            for axis, name in enumerate(names):
                if exact >= charges[axis]:
                    continue
                stats[name]["saving_sources"] += 1
                good, witness = inherited(*key, axis)
                stats[name]["recursively_inherited" if good else "failed_sources"] += 1
                field = "first_pass" if good else "first_failure"
                if stats[name][field] is None:
                    stats[name][field] = {"row": row, "mode": mode, "bound": exact,
                                          "psi": charges[axis], "witness": witness}
        payload = {"semantics": compiled_module.SEMANTICS, "diagnostic_only": True,
                   "predicate": "greatest exact-saving recursively inherited predicate",
                   "potential": "two original-history capacity<=2/capacity>=3 pruning charges",
                   "k": k, "global_rank": rank, "max_children_completed": count,
                   "repeated_level_one": args.repeats, "contexts": tested, "stats": stats,
                   "audited_states": inherited.cache_info().misses,
                   "seconds": time.monotonic() - started}
        args.output.write_text(json.dumps(payload, indent=2) + "\n")
        print(json.dumps({"completed_children": count, "contexts": tested,
                          "audited_states": payload["audited_states"],
                          "stats": {name: {key: value for key, value in st.items()
                                           if not key.startswith("first_")}
                                    for name, st in stats.items()},
                          "seconds": payload["seconds"]}), flush=True)


if __name__ == "__main__":
    main()
