"""R3 adds a terminal class certified by ctx_bound_le_one_of_large_sibling_maximum.

Two active children in different chosen capacity groups, with an actual
opposite maximum >= k-2, have singleton pruning charges1+1 and source B<=1.
Their cut parts are singleton, so the full recursive charge condition is
directly closed. This is a small capacity/marker feature, not a source-B test.
"""
import hashlib
from pathlib import Path

import charge_ancestry_nontrivial_candidate as ancestry

engine = ancestry.engine


def terminal_two_children_large_opposite(word, maxima, limits, rank, k):
    return (len(limits) == 2 and all(min(cap) > 0 for cap in limits.values()) and
            any(cap[0] <= 2 for cap in limits.values()) and
            any(cap[0] >= 3 for cap in limits.values()) and
            any(letter != "S" and letter[1] == "upper" and
                1 <= letter[0] <= len(maxima) and maxima[letter[0]-1] >= k-2
                for letter in word))


engine.EXTRA_FEATURES = (*engine.EXTRA_FEATURES, terminal_two_children_large_opposite)
engine.EXTRA_FEATURE_NAMES = (*engine.EXTRA_FEATURE_NAMES,
                              "two_active_low_high_children_with_actual_large_upper_maximum")
engine.CANDIDATE_SOURCE_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
engine.CANDIDATES = {
    "lower_ancestry_or_terminal_two": (0, ((7, 10, 11), (12,))),
    "mixed_both_dense_opposed_cut_ancestry": (2, ((0, 1, 2, 4, 11),)),
}

if __name__ == "__main__":
    engine.main()
