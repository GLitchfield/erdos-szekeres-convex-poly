"""Exact recursive charge certificate for R3, diagnostic only.

Features: mixed active capacities <=2/>=3 on each axis, an active (3,3)
child, no active capacity-one child, and opposed directions of two marker
level pairs on the two axes. Candidates are the conjunctions below.
Pi is mixed on both axes, has an active (3,3) child, and has opposed actual
marker directions. It excludes one-run contexts. Independent pruning charges
upper-bound each part by the checked capacity-three decomposition. Thus all
cuts closing with a charge unit, or an audited pi-child at equality, implies
strict source saving by child-count induction. No full source B is used to
define pi or certify a recursive step. No child multiplicity is compressed.
"""
from __future__ import annotations
import argparse
from functools import lru_cache
import json
from pathlib import Path
import random
import time

from gate_probe import compiled_module, family, part, point_limits, row_key
from harness.research.primitives import extension

CANDIDATES = {
    "mixed_both_dense_opposed": (2, ((0, 1, 2, 4),)),
    "lower_shared_complete_cut_history": (0, ((0, 5, 7, 8, 9),)),
}


def random_family(k, count, samples, rank):
    rng = random.Random(20260930 + 100 * k + count)
    for _ in range(samples):
        depth = rng.randint(4, 7)
        sides = {j: rng.choice(("lower", "upper")) for j in range(1, depth - 3)}
        sides.update({depth - 3: "upper", depth - 2: "upper",
                      depth - 1: "lower", depth: "lower"})
        word = ["S"] * count + [(j, sides[j]) for j in range(1, depth + 1)]
        for _ in range(rng.randint(0, 2)):
            j = rng.randint(1, depth - 2)
            word.append((j, sides[j]))
        rng.shuffle(word)
        maxima = tuple(rng.randint(1, min(2, k - 2)) for _ in range(depth - 4)) + (1, 1, 1, 1)
        yield {"word": tuple(word), "maxima": maxima, "a": rank,
               "u": rank, "k": k, "chosen": "lower"}, "random-complete-history"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--global-rank", type=int, default=5)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--min-children", type=int, default=2)
    parser.add_argument("--cache-size", type=int, default=64000)
    parser.add_argument("--sources", choices=("clean", "random"), default="clean")
    parser.add_argument("--samples", type=int, default=1000)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    k, rank = args.k, args.global_rank
    compiled = compiled_module.compiled_evaluator(rank, rank, k, cache_size=args.cache_size)
    started = time.monotonic()

    @lru_cache(maxsize=128000)
    def bound(word, maxima):
        return compiled(word, maxima) if "S" in word else 0

    @lru_cache(maxsize=128000)
    def geometric_features(word, maxima):
        limits = point_limits(word, maxima, rank, rank, k)
        active = [cap for cap in limits.values() if min(cap) > 0]
        mixed = [any(cap[axis] <= 2 for cap in active) and
                 any(cap[axis] >= 3 for cap in active) for axis in (0, 1)]
        directions = []
        for side in ("lower", "upper"):
            markers = [(p, letter[0]) for p, letter in enumerate(word)
                       if letter != "S" and letter[1] == side and letter[0] <= len(maxima)]
            directions.append({(b_level > a_level) - (b_level < a_level)
                               for i, (_, a_level) in enumerate(markers)
                               for _, b_level in markers[i+1:] if a_level != b_level})
        opposed = any(-d in directions[1] for d in directions[0])
        features = tuple(mixed + [(3, 3) in active,
                                 all(min(cap) >= 2 for cap in active), opposed])
        shared = []
        for axis, opposite in ((0, "upper"), (1, "lower")):
            profiles = []
            for low in (True, False):
                profiles.append({(extension(word, len(maxima), opposite, p, True),
                                  extension(word, len(maxima), opposite, p, False))
                                 for p, cap in limits.items()
                                 if min(cap) > 0 and (cap[axis] <= 2) == low})
            shared.append(bool(profiles[0] & profiles[1]))
        features += tuple(shared)
        chosen_levels = {}
        for p, letter in enumerate(word):
            if letter != "S" and letter[1] == "lower" and letter[0] <= len(maxima):
                chosen_levels.setdefault(letter[0], []).append(p)
        oldest = sorted(chosen_levels)[-2:]
        features += (len(oldest) == 2 and all(len(chosen_levels[level]) == 1 and
                                            maxima[level-1] == 1 for level in oldest),)
        occupied = {letter[0] for letter in word if letter != "S" and letter[0] <= len(maxima)}
        younger_chosen = sorted(chosen_levels)[:-2]
        complete_cut_history = all(j in occupied for j in range(1, max(younger_chosen, default=0) + 1))
        opposite_actual = any(letter != "S" and letter[1] == "upper" and
                              letter[0] <= len(maxima) for letter in word)
        features += (opposite_actual, complete_cut_history)
        return features

    @lru_cache(maxsize=128000)
    def information(word, maxima):
        limits = point_limits(word, maxima, rank, rank, k)
        charges = []
        for axis in (0, 1):
            total = 0
            for low in (True, False):
                support = {p for p, cap in limits.items() if (cap[axis] <= 2) == low}
                pruned = tuple(letter if letter != "S" or p in support
                               else (len(maxima) + 1, "lower")
                               for p, letter in enumerate(word))
                total += bound(pruned, maxima)
            charges.append(total)
        return geometric_features(word, maxima), tuple(charges + [min(charges)])

    def predicate(key, candidate):
        features = geometric_features(*key)
        return any(all(features[i] for i in clause) for clause in CANDIDATES[candidate][1])

    @lru_cache(maxsize=128000)
    def audit(word, maxima, candidate):
        key = (word, maxima)
        if not predicate(key, candidate):
            return False, {"reason": "predicate absent"}
        axis = CANDIDATES[candidate][0]
        features, charges = information(*key)
        charge = charges[axis]
        row = {"word": word, "maxima": maxima, "a": rank, "u": rank,
               "k": k, "chosen": "lower"}
        record = {"row": row, "features": features, "psi": charge}
        children = tuple(p for p, letter in enumerate(word) if letter == "S")
        for start in range(len(children)):
            for length in range(1, len(children) - start + 1):
                if length == len(children):
                    continue
                keep = frozenset(children[start:start+length])
                rest = frozenset(children) - keep
                for lower_m in range(1, k - 1):
                    upper_m = k - 1 - lower_m
                    for side in ("lower", "upper"):
                        other = "upper" if side == "lower" else "lower"
                        m = lower_m if side == "lower" else upper_m
                        n = upper_m if side == "lower" else lower_m
                        left, right = part(row, keep, side, m), part(row, rest, other, n)
                        lk, rk = row_key(left), row_key(right)
                        lp, rp = information(*lk)[1][axis], information(*rk)[1][axis]
                        if lp + rp <= charge - 1:
                            continue
                        witness = {**record, "keep": sorted(keep), "parts": [left, right],
                                   "part_psi": [lp, rp],
                                   "part_features": [information(*lk)[0], information(*rk)[0]]}
                        if lp + rp > charge:
                            return False, {**witness, "reason": "charge swelling"}
                        lok, lw = audit(*lk, candidate)
                        rok, rw = audit(*rk, candidate)
                        if not (lok or rok):
                            return False, {**witness, "reason": "no predicate-saving child",
                                           "child_failures": [lw, rw]}
        return True, None

    stats = {name: {"predicate_sources": 0, "passing_sources": 0, "failed_sources": 0,
                    "first_failure": None, "first_pass": None} for name in CANDIDATES}
    tested = 0
    for count in range(args.min_children, args.max_children + 1):
        sources = family(k, count, 1, rank) if args.sources == "clean" else random_family(k, count, args.samples, rank)
        for row, mode in sources:
            tested += 1
            key = row_key(row)
            for name in CANDIDATES:
                if not predicate(key, name):
                    continue
                stats[name]["predicate_sources"] += 1
                good, witness = audit(*key, name)
                stats[name]["passing_sources" if good else "failed_sources"] += 1
                field = "first_pass" if good else "first_failure"
                if stats[name][field] is None:
                    stats[name][field] = {"row": row, "mode": mode, "witness": witness}
                    if not good:
                        args.output.with_name(args.output.stem + ".failure-" + name + ".json").write_text(
                            json.dumps({"diagnostic_only": True, "k": k, "candidate": name,
                                        "tested_sources": tested, "failure": stats[name][field]}, indent=2) + "\n")
        payload = {"semantics": compiled_module.SEMANTICS, "diagnostic_only": True,
                   "features": ["mixed_active_lower", "mixed_active_upper", "active_3_3",
                                "no_active_one", "opposed_marker_directions",
                                "lower_groups_share_opposite_profile",
                                "upper_groups_share_opposite_profile",
                                "two_oldest_lower_levels_singleton_maxima1",
                                "actual_upper_marker", "occupied_prefix_through_all_younger_lower_markers"],
                   "candidates": CANDIDATES, "k": k, "global_rank": rank,
                   "max_children_completed": count, "contexts": tested,
                   "min_children": args.min_children, "cache_size": args.cache_size,
                   "certificate_contract": __doc__, "root_bound_evaluated": False,
                   "source_domain": args.sources, "samples_per_children": args.samples if args.sources == "random" else None,
                   "stats": stats, "audit_states": audit.cache_info().misses,
                   "seconds": time.monotonic() - started}
        args.output.write_text(json.dumps(payload, indent=2) + "\n")
        print(json.dumps({"completed_children": count, "contexts": tested,
                          "stats": {name: {key: value for key, value in st.items()
                                           if not key.startswith("first_")}
                                    for name, st in stats.items()},
                          "seconds": payload["seconds"]}), flush=True)


if __name__ == "__main__":
    main()
