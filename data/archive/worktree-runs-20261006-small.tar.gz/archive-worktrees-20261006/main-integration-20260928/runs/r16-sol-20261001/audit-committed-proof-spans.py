"""Read-only R16 committed-proof/frozen-candidate audit; no compiler or DB use."""
import argparse, hashlib, json, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "es"))
from es.proofs import whole_span
p = argparse.ArgumentParser()
p.add_argument("--first", type=int)
args = p.parse_args()
started = time.monotonic()
run = Path(__file__).resolve().parent
inventory = json.loads((run / "ACCEPTED-RECEIPTS.final-audit-1646.json").read_text())
rows = inventory["receipt_audit"][:args.first]
candidates = [(f, f.read_bytes()) for f in sorted(run.glob("*.lean"))
              if ".closed" in f.name or ".commit" in f.name]
results = []
for row in rows:
    module = row["module"].replace(".", "/") + ".lean"
    src = subprocess.run(
        ["git", "-c", "gc.auto=0", "-c", "maintenance.auto=false",
         "--git-dir=.git-data", "--work-tree=.", "show", row["commit"]+":"+module],
        cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
    short = row["node"].rsplit(".", 1)[-1]
    start, end = whole_span(src.decode(), short)
    body = src[start:end].strip()
    matches = []
    for f, raw in candidates:
        full = raw == src
        candidate = raw.strip()
        if not candidate.startswith(b"by"):
            try:
                lo, hi = whole_span(raw.decode(), short)
                candidate = raw[lo:hi].strip()
            except Exception:
                continue
        if candidate == body or full:
            matches.append({"file":f.name, "file_sha256":hashlib.sha256(raw).hexdigest(),
                            "full_module_equal":full, "proof_body_equal":candidate==body})
    results.append({"node":row["node"], "commit":row["commit"], "module":module,
                    "module_sha256":hashlib.sha256(src).hexdigest(),
                    "proof_sha256":hashlib.sha256(body).hexdigest(), "matches":matches})
    print(f"proof spans {len(results)}/{len(rows)}, elapsed {time.monotonic()-started:.2f}s", file=sys.stderr, flush=True)
print(json.dumps({"schema_version":1, "semantics":
    "Read-only exact stripped proof-span/full-module comparison; not compilation or new proof credit.",
    "rows":len(results), "candidate_files":len(candidates), "seconds":time.monotonic()-started,
    "all_match":all(r["matches"] for r in results), "results":results}, indent=2))
