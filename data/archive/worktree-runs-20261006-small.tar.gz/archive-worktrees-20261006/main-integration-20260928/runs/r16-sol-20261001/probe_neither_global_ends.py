#!/usr/bin/env python3
"""R16 diagnostic: each outer singleton on nondegenerate neither-marked roots."""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"scripts"))
from harness.research.context_bound import compiled_evaluator
from harness.research.singleton_cuts import singleton_cut_values
from probe_boundary_normalization import root_words

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--k",type=int,required=True)
    p.add_argument("--timing-only",action="store_true")
    p.add_argument("--out",required=True)
    a=p.parse_args()
    assert a.k>=3
    words=[w for w in root_words(4,3,5) if w[0]=="S" and w[-1]=="S"]
    parameters=list(itertools.product(range(3,a.k+1),repeat=2))
    maxima=list(range(1,a.k-1))
    if a.timing_only:
        words=[max(words,key=len)]
        parameters=[(a.k,a.k)]
        maxima=[1]
    paths=[Path(__file__),Path(__file__).with_name("probe_boundary_normalization.py"),
           Path(__file__).with_name("N-ends.falsifier.py"),
           ROOT/"harness/research/context_bound.py",ROOT/"harness/research/context_bound.c",
           ROOT/"harness/research/singleton_cuts.py",ROOT/"harness/research/primitives.py"]
    def hashes():
        return {str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in paths}
    before=hashes()
    total=len(words)*len(parameters)*len(maxima)
    counts={"roots":0,"cuts":0,"first_failures":0,"last_failures":0,"paired_failures":0,
            "first_fixed_coupling_failures":0}
    examples={key:[] for key in counts if key.endswith("failures")}
    start=time.monotonic()
    print(json.dumps({"done":0,"total":total,"k":a.k}),flush=True)
    for cap,cup in parameters:
        F=compiled_evaluator(cap,cup,a.k,cache_size=2_000_000,persistent=True)
        try:
            for m in maxima:
                for w in words:
                    row={"word":w,"maxima":(m,),"a":cap,"u":cup,"k":a.k,"chosen":"lower"}
                    b=F(w,(m,))
                    cs=singleton_cut_values(F,row)
                    first=next(i for i,z in enumerate(w) if z=="S")
                    last=max(i for i,z in enumerate(w) if z=="S")
                    fc=max(c for c in cs if c[1]==first)
                    lc=max(c for c in cs if c[1]==last)
                    oldside=next(z[1] for z in w if z!="S")
                    opposite="upper" if oldside=="lower" else "lower"
                    opposite_global=cap if oldside=="lower" else cup
                    fixed_c=a.k-opposite_global+1
                    fixed=[c for c in cs if c[1]==first and c[2]==opposite and c[3]==fixed_c]
                    fixed_value=fixed[0][0] if fixed else None
                    tests={"first_failures":b>fc[0],"last_failures":b>lc[0],
                           "paired_failures":b>max(fc[0],lc[0]),
                           "first_fixed_coupling_failures":fixed_value is not None and b>fixed_value}
                    counts["roots"]+=1
                    counts["cuts"]+=len(cs)
                    for key,fails in tests.items():
                        if fails:
                            counts[key]+=1
                            if len(examples[key])<20:
                                examples[key].append({**row,"bound":b,"first_best":fc,"last_best":lc,
                                                      "fixed_opposite_coupling":fixed_c,"fixed_value":fixed_value})
                    if counts["roots"]%100==0 or counts["roots"]==total:
                        elapsed=time.monotonic()-start
                        print(json.dumps({"done":counts["roots"],"total":total,"seconds":elapsed,
                                          "rate":counts["roots"]/elapsed,"counts":counts}),flush=True)
        finally:
            F.close()
    assert before==hashes(),"source changed during diagnostic"
    result={"candidate":"Each global end singleton attains on neither-marked legal roots with both globals>=3",
            "semantics":"context-bound-zero-children-c-v1","args":vars(a),
            "scope":{"runs":"2..4","lengths":"1..3","children_max":5,"endmarkers":False,
                     "sides":["lower","upper"],"parameters":parameters,"maxima":maxima,"words":len(words)},
            "counts":counts,"examples":examples,"seconds":time.monotonic()-start,
            "source_sha256":before,"complete":counts["roots"]==total}
    Path(a.out).write_text(json.dumps(result,indent=2)+"\n")
    return 2 if counts["first_failures"] or counts["last_failures"] else 0
if __name__=="__main__":
    raise SystemExit(main())
