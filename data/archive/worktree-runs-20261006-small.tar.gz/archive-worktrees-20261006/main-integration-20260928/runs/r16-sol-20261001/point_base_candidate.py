"""R16 candidate potential on exactly-one-marked one-level roots; diagnostic only."""
from decomposable_depth2_tables import limits_from_signature
from enumerate_decomposable_colorings import threshold


def _root_point_base_comparison(evaluate, row, unit_axis_bound_rule=False):
    """Compare the full recursive bound to the largest initial per-run point base."""
    word = tuple(row["word"])
    runs, cups, caps = limits_from_signature(word, row["maxima"],
        row["a"], row["u"], row["k"], lean=True)
    assert runs >= 2
    bases = [threshold(int(caps[i, i]) + 1, int(cups[i, i]) + 1, row["k"])
        for i in range(runs)]
    use_zero = unit_axis_bound_rule and (row["a"] <= 1 or row["u"] <= 1)
    value = 0 if use_zero else evaluate(word, row["maxima"])
    return {"bound": value, "point_bases": bases, "largest_point_base": max(bases),
        "bound_rule": ("ErdosSzekeres.ctx_bound_zero_of_unit_global_axis"
            if use_zero else "context-bound-zero-children-c-v1")}


def root_point_base_comparison(evaluate, row, unit_axis_bound_rule=False):
    word = tuple(row["word"])
    assert (word[0] == "S") != (word[-1] == "S")
    return _root_point_base_comparison(evaluate, row, unit_axis_bound_rule)


def both_marked_point_base_comparison(evaluate, row, unit_axis_bound_rule=False):
    word = tuple(row["word"])
    assert word[0] != "S" and word[-1] != "S"
    old_side = word[0][1]
    opposite_global = row["a"] if old_side == "lower" else row["u"]
    assert opposite_global >= 3
    return _root_point_base_comparison(evaluate, row, unit_axis_bound_rule)
