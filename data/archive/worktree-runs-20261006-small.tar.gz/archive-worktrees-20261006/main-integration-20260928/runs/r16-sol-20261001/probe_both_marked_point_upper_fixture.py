#!/usr/bin/env python3
"""Four fixed diagnostic rows for the extra both-marked point-upper candidate."""
from pathlib import Path
import hashlib
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from point_base_candidate import both_marked_point_base_comparison

paths = [Path(__file__), Path(__file__).with_name("point_base_candidate.py"),
    ROOT / "harness/research/context_bound.py", ROOT / "harness/research/context_bound.c",
    ROOT / "scripts/decomposable_depth2_tables.py",
    ROOT / "scripts/enumerate_decomposable_colorings.py"]
def hashes():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before = hashes()
started = time.monotonic()
rows = []
for k in (5, 6):
    evaluate = compiled_evaluator(k, k, k, cache_size=200000, persistent=True)
    try:
        for side in ("lower", "upper"):
            word = tuple([item for _ in range(4) for item in ((1, side), "S")] + [(1, side)])
            row = {"word": word, "maxima": (1,), "a": k, "u": k, "k": k}
            comparison = both_marked_point_base_comparison(evaluate, row)
            rows.append({**row, **comparison,
                "upper_holds": comparison["bound"] <= comparison["largest_point_base"]})
            print(json.dumps({"done": len(rows), "total": 4, "seconds": time.monotonic()-started}), flush=True)
    finally:
        evaluate.close()
after = hashes()
assert before == after, "diagnostic sources changed during execution"
result = {"candidate": "extra both-marked full bound <= largest initial point base",
    "semantics": "context-bound-zero-children-c-v1; lean=True initial limits",
    "rows": rows, "complete": len(rows) == 4, "source_sha256": before,
    "seconds": time.monotonic()-started,
    "violations": sum(not row["upper_holds"] for row in rows)}
Path(sys.argv[1]).write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({"complete": True, "violations": result["violations"]}), flush=True)
raise SystemExit(2 if result["violations"] else 0)
