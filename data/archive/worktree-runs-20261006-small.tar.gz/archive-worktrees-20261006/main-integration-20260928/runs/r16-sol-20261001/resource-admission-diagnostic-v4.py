import json
import os
import sqlite3
from pathlib import Path
from es.config import load_config
from es.jobs import job_memory_gib, budget_problem
from es.build import available_gib

cfg = load_config(Path("/home/gavin/git/erdos-szekeres-convex-poly/runs/worktrees/main-integration-20260928"))
con = sqlite3.connect(f"file:{cfg.db_path}?mode=ro", uri=True)
con.row_factory = sqlite3.Row
leases = [dict(r) for r in con.execute("SELECT * FROM resource_leases")]
live = [dict(r) for r in con.execute("SELECT id,status,memory_max,kind,node,pid,process_start,scope_unit,created_at,started_at FROM jobs WHERE status IN ('starting','running','unknown_execution')")]
queued = [dict(r) for r in con.execute("SELECT id,status,memory_max,kind,lock_key,created_at FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 15")]
result = {"available_gib": available_gib(), "margin_gib": cfg.jobs_run_margin_gib, "budget": cfg.jobs_memory_budget, "budget_problem": budget_problem(cfg, 5, "5G", live), "oldest_queued": queued, "job": os.environ.get("ES_JOB_ID"), "semantics": "read-only-current-resource-admission-v1", "leases": leases, "live": live, "live_cap_gib": sum(job_memory_gib(cfg, j) for j in live), "lease_gib": sum(r["memory_gib"] for r in leases), "requested_gib": 5}
Path("/home/gavin/git/erdos-szekeres-convex-poly/runs/worktrees/main-integration-20260928/runs/r16-sol-20261001/resource-admission-diagnostic-v4.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result), flush=True)
