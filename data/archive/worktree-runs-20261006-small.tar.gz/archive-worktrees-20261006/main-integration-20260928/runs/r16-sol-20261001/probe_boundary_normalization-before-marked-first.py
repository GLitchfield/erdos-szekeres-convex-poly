#!/usr/bin/env python3
"""Finite diagnostic for R16's p=0 complement normal forms.

Reuses the registered selector root family and shared part/normalization/C
primitives. The comparison checks initial run-limit matrices and full recursive
bounds; neither supplies kernel theorem credit. Includes exactly-one and neither
marked ends, because the normal forms only require an unmarked left word end.
Execution, memory admission and review checkpoints belong to es job run.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import ExitStack
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from decomposable_depth2_tables import limits_from_signature
from boundary_candidates import complement_normal_form

selector_path = Path(__file__).with_name("N-ends.falsifier.py")
selector_spec = importlib.util.spec_from_file_location("r16_selector_family", selector_path)
assert selector_spec is not None and selector_spec.loader is not None
selector_module = importlib.util.module_from_spec(selector_spec)
selector_spec.loader.exec_module(selector_module)
root_words = selector_module.root_words


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ks", default="5")
    parser.add_argument("--max-runs", type=int, default=4)
    parser.add_argument("--max-len", type=int, default=2)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--cache-size", type=int, default=200000)
    parser.add_argument("--timing-only", action="store_true")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    words = [word for word in root_words(args.max_runs, args.max_len,
        args.max_children) if word[0] == "S"]
    if args.timing_only:
        words = [max(words, key=len)]
    domains = []
    for k in map(int, args.ks.split(",")):
        assert k >= 3
        parameters = [(k, k)] if args.timing_only else list(
            itertools.product(range(1, k + 1), repeat=2))
        maxima = [1] if args.timing_only else list(range(1, k - 1))
        domains.append((k, parameters, maxima))
    total = sum(len(parameters) * len(maxima) * len(words)
        for _, parameters, maxima in domains)
    counts = Counter()
    failures = []
    started = time.monotonic()
    print(json.dumps({"roots_done": 0, "total_roots": total}), flush=True)
    for k, parameters, maxima in domains:
        for a, u in parameters:
            with ExitStack() as stack:
                evaluators = {}

                def bound(row):
                    key = (row["a"], row["u"], row["k"])
                    if key not in evaluators:
                        evaluator = compiled_evaluator(*key, persistent=True,
                            cache_size=args.cache_size)
                        stack.callback(evaluator.close)
                        evaluators[key] = evaluator
                    return evaluators[key](row["word"], row["maxima"])

                for m in maxima:
                    for word in words:
                        side = next(x[1] for x in word if x != "S")
                        row = {"word": word, "maxima": (m,), "a": a,
                            "u": u, "k": k, "chosen": side}
                        for complementary_side in ("lower", "upper"):
                            for maximum in range(1, k - 1):
                                candidate = complement_normal_form(row,
                                    complementary_side, maximum)
                                if candidate is None:
                                    counts["skipped_opposite_unit_globals"] += 1
                                    continue
                                kind, actual, normalized = candidate
                                av, nv = bound(actual), bound(normalized)
                                ar, ac, ap = limits_from_signature(actual["word"],
                                    actual["maxima"], a, u, k, lean=True)
                                nr, nc, np = limits_from_signature(normalized["word"],
                                    normalized["maxima"], normalized["a"],
                                    normalized["u"], k, lean=True)
                                equal_limits = ar == nr and ac.tolist() == nc.tolist() \
                                    and ap.tolist() == np.tolist()
                                counts[kind] += 1
                                counts["bound_equalities"] += av == nv
                                counts["limit_equalities"] += equal_limits
                                if av != nv or not equal_limits:
                                    counts["failures"] += 1
                                    if len(failures) < 20:
                                        failures.append({"root": row, "kind": kind,
                                            "side": complementary_side,
                                            "maximum": maximum, "actual": actual,
                                            "normalized": normalized, "actual_bound": av,
                                            "normalized_bound": nv,
                                            "equal_initial_limits": equal_limits})
                        counts["roots"] += 1
                        if counts["roots"] % 100 == 0 or counts["roots"] == total:
                            elapsed = time.monotonic() - started
                            print(json.dumps({"roots_done": counts["roots"],
                                "total_roots": total, "seconds": elapsed,
                                "roots_per_second": counts["roots"] / elapsed,
                                "counts": dict(counts)}), flush=True)
    sources = [Path(__file__), Path(__file__).with_name("boundary_candidates.py"),
        selector_path,
        ROOT / "harness/research/primitives.py",
        ROOT / "harness/research/context_bound.py"]
    result = {"semantics": "context-bound-zero-children-c-v1",
        "candidate_semantics": "r16-p0-complement-normalization-v1",
        "args": vars(args), "total_roots": total, "counts": dict(counts),
        "seconds": time.monotonic() - started, "failures": failures,
        "source_sha256": {str(path.relative_to(ROOT)):
            hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
        "complete": True}
    Path(args.out).write_text(json.dumps(result, indent=2) + "\n")
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
