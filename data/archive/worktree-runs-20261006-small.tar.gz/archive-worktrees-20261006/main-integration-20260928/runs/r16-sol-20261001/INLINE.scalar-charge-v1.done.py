from pathlib import Path
import sys,json,time,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/"scripts"),str(root/"runs/r16-sol-20261001")]
from harness.research.recursive import evaluator
from harness.research.primitives import part
from larger_axis_upper_candidates import scalar_normalized_split_charge
input_path=root/"runs/r16-sol-20261001/larger-axis-triple-charge-family.json"
family=json.loads(input_path.read_text());assert family["complete"] and len(family["rows"])==36
paths=[input_path]+[root/p for p in ["runs/r16-sol-20261001/larger_axis_upper_candidates.py","harness/research/recursive.py","harness/research/primitives.py","scripts/decomposable_recursive_formula.py","scripts/decomposable_additivity_test.py","scripts/decomposable_depth2_tables.py","scripts/enumerate_decomposable_colorings.py"]]
hashes=lambda:{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes();start=time.monotonic();rows=[];checked_roots=[]
references={(7,5):evaluator(7,5,7,semantics="context-bound-zero-children-v1",cache_size=200000),(5,7):evaluator(5,7,7,semantics="context-bound-zero-children-v1",cache_size=200000)}
for index,item in enumerate(family["rows"]):
 source=dict(item["normalized"]);source["word"]=tuple("S" if z=="S" else tuple(z) for z in source["word"]);source["maxima"]=()
 selected="lower" if source["u"]==7 else "upper";other="upper" if selected=="lower" else "lower";source["chosen"]=selected
 ref=references[(source["a"],source["u"])];v=ref(source["word"],());assert v==item["normalized_bound"]==26
 ps=[p for p,z in enumerate(source["word"]) if z=="S"];counts=0
 for i in range(len(ps)):
  for j in range(i+1,len(ps)+1):
   if i==0 and j==len(ps):continue
   keep=ps[i:j];rest=[p for p in ps if p not in keep]
   for m in range(1,6):
    charge=scalar_normalized_split_charge(5,7,7,m);own=part(source,set(keep),selected,m);comp=part(source,set(rest),other,6-m)
    own_value=ref(own["word"],own["maxima"]);comp_value=ref(comp["word"],comp["maxima"])
    rows.append({"family_index":index,"a":source["a"],"u":source["u"],"selected":selected,"keep":keep,"rest":rest,**charge,"own_bound":own_value,"other_bound":comp_value,"actual_cut":own_value+comp_value,"scalar_bridge_holds":charge["charge"]<=charge["target"],"individual_estimates_hold":own_value<=charge["own"] and comp_value<=charge["other"],"cut_upper_holds":own_value+comp_value<=26});counts+=1
 checked_roots.append({"index":index,"cuts":counts,"bound":v})
 print(json.dumps({"roots_done":index+1,"total_roots":36,"cuts":len(rows),"seconds":time.monotonic()-start}),flush=True)
assert before==hashes()
result={"claim":"normalized scalar childcount-induction cut charges <= source saturated T","semantics":"context-bound-zero-children-v1 Python reference; shared part and threshold","diagnostic_only":True,"complete":len(checked_roots)==36,"roots":checked_roots,"rows":rows,"scalar_bridge_failures":sum(not r["scalar_bridge_holds"] for r in rows),"individual_estimate_violations":sum(not r["individual_estimates_hold"] for r in rows),"actual_cut_upper_violations":sum(not r["cut_upper_holds"] for r in rows),"seconds":time.monotonic()-start,"source_sha256":before}
(root/"runs/r16-sol-20261001/larger-axis-scalar-charge-family.json").write_text(json.dumps(result,indent=2)+"\n")
