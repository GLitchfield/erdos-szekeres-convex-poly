"""Audited correction of R16's own research/review boundary; no usage values change."""
import datetime as dt
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/gavin/git/erdos-szekeres-convex-poly/tools/es")
from es.config import load_config
from es.store import Store

cfg = load_config(Path(__file__).resolve().parents[2])
agent = "codex:agent-run-58eb8a64138d4dfc"
with Store(cfg) as st:
    research = dict(st.conn.execute("SELECT * FROM research_windows WHERE id=?",
        ("window-ba706cd5c60c4a0e",)).fetchone())
    review = dict(st.conn.execute("SELECT * FROM research_windows WHERE id=?",
        ("window-3f3a2be329af4056",)).fetchone())
    assert research["agent"] == agent and review["agent"] == agent
    assert research["status"] == "complete"
    assert research["started_at"] < review["started_at"] < research["ended_at"]
    detail = {"window": research["id"], "old_ended_at": research["ended_at"],
        "new_ended_at": review["started_at"], "review_window": review["id"],
        "reason": "Research stopped at review begin; operator closed metadata later.",
        "usage_values_changed": False}
    metadata = json.loads(research["metadata_json"])
    metadata.setdefault("events", []).append({"at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "kind": "actual-boundary-correction", **detail})
    st.conn.execute("UPDATE research_windows SET ended_at=?,metadata_json=? WHERE id=?",
        (review["started_at"], json.dumps(metadata), research["id"]))
    st.event("usage-window-boundary-correction", None, agent, detail)
print(json.dumps(detail, indent=2))
