from pathlib import Path
import sys,json,time,hashlib
root=Path.cwd(); sys.path[:0]=[str(root),str(root/"scripts"),str(root/"runs/r16-sol-20261001")]
from harness.research.context_bound import compiled_evaluator
from probe_boundary_normalization import root_words
from larger_axis_upper_candidates import empty_history_triple_charge
from point_base_candidate import both_marked_point_base_comparison
paths=[root/p for p in ["runs/r16-sol-20261001/larger_axis_upper_candidates.py","runs/r16-sol-20261001/probe_boundary_normalization.py","runs/r16-sol-20261001/point_base_candidate.py","runs/r16-sol-20261001/N-ends.falsifier.py","harness/research/context_bound.py","harness/research/context_bound.c","scripts/decomposable_depth2_tables.py","scripts/enumerate_decomposable_colorings.py"]]
hashes=lambda:{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes();start=time.monotonic();words=[w for w in root_words(4,2,4) if w[0]!="S" and w[-1]!="S"];rows=[]
evaluators={(7,7):compiled_evaluator(7,7,7,cache_size=200000,persistent=True),(7,5):compiled_evaluator(7,5,7,cache_size=200000,persistent=True),(5,7):compiled_evaluator(5,7,7,cache_size=200000,persistent=True)}
try:
 for m in (1,2):
  for w in words:
   side=w[0][1];a,u=(7,5) if side=="lower" else (5,7)
   original={"word":w,"maxima":(m,),"a":7,"u":7,"k":7}
   source=both_marked_point_base_comparison(evaluators[(7,7)],original)
   v=evaluators[(a,u)](w,());compact=evaluators[(a,u)](("S",)*w.count("S"),())
   charge=empty_history_triple_charge(a,u,7)
   rows.append({"origin":original,"normalized":{"word":w,"maxima":[],"a":a,"u":u,"k":7},"source":source,"normalized_bound":v,"compact_bound":compact,**charge,"bridge_holds":charge["ordered_triples"]<=charge["target"],"upper_holds":v<=charge["target"]})
   print(json.dumps({"done":len(rows),"total":2*len(words),"seconds":time.monotonic()-start}),flush=True)
finally:
 for e in evaluators.values():e.close()
assert before==hashes()
result={"claim":"empty-history ordered-rank-triple support cardinality <= exact saturated T","diagnostic_only":True,"semantics":"context-bound-zero-children-c-v1; threshold shared; normalization source point matrices lean=True","rows":rows,"complete":len(rows)==2*len(words),"bridge_failures":sum(not r["bridge_holds"] for r in rows),"upper_violations":sum(not r["upper_holds"] for r in rows),"seconds":time.monotonic()-start,"source_sha256":before}
(root/"runs/r16-sol-20261001/larger-axis-triple-charge-family.json").write_text(json.dumps(result,indent=2)+"\n")
