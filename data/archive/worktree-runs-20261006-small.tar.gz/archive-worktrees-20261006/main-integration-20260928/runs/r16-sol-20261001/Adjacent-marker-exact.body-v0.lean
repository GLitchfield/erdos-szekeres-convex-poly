  classical
  let letter (L : ℕ) : Letter → Letter := fun x => match x with
    | Letter.ext j s => if j ≤ L then Letter.ext j s else Letter.ext (j - 1) s
    | Letter.child => Letter.child
  let norm (ρ : Context) (L : ℕ) : Context :=
    { ρ with
      a := match ρ.sideAt L with | Side.lower => ρ.a | Side.upper => ρ.a - 1
      u := match ρ.sideAt L with | Side.lower => ρ.u - 1 | Side.upper => ρ.u
      word := ρ.word.map (letter L)
      maxima := ρ.maxima.take (L - 1) ++ [max (ρ.maximumAt L) (ρ.maximumAt (L + 1) + 1)] ++
        ρ.maxima.drop (L + 1) }
  let lv (ρ : Context) (i : ℕ) : ℕ → Bool := fun p => match ρ.letterAt p with
    | Letter.ext j _ => decide (j = i)
    | Letter.child => false
  let up (L j : ℕ) := if j < L then j else j + 1
  let upTop (L t : ℕ) := if t ≤ L then t else t + 1
  let img (L j x : ℕ) : Prop := (j < L ∧ x = j) ∨ (j = L ∧ (x = L ∨ x = L + 1)) ∨ (L < j ∧ x = j + 1)
  change (∀ p ∈ σ.childPositions, ∀ q ∈ σ.childPositions,
      σ.cupLimit p q = (norm σ N).cupLimit p q ∧
      σ.capLimit p q = (norm σ N).capLimit p q) ∧
    (∀ fuel, boundFuel fuel σ = boundFuel fuel (norm σ N)) ∧
      σ.bound = (norm σ N).bound
  -- basic transport ----------------------------------------------------------
  have hLevelMem (ρ : Context) (j : ℕ) : j ∈ ρ.levels ↔ 1 ≤ j ∧ j ≤ ρ.maxima.length := by
    simp only [levels, List.mem_map, List.mem_range]
    constructor
    · rintro ⟨i, hi, rfl⟩; omega
    · intro hj; exact ⟨j - 1, by omega, by omega⟩
  have hSorted (ρ : Context) : ρ.levels.Pairwise (· < ·) := by
    unfold levels
    exact List.pairwise_lt_range.map (fun x => x + 1) (fun a b h => Nat.add_lt_add_right h 1)
  have hLen (ρ : Context) (L : ℕ) : (norm ρ L).word.length = ρ.word.length := by
    simp only [norm, List.length_map]
  have hLetter (ρ : Context) (L p : ℕ) : (norm ρ L).letterAt p = letter L (ρ.letterAt p) := by
    simp only [norm, letterAt, List.getElem?_map]
    cases ρ.word[p]? <;> rfl
  have hIsChild (ρ : Context) (L p : ℕ) :
      (norm ρ L).letterAt p = Letter.child ↔ ρ.letterAt p = Letter.child := by
    rw [hLetter]
    cases ρ.letterAt p with
    | child => simp [letter]
    | ext j v => by_cases hj : j ≤ L <;> simp [letter, hj]
  have hChild (ρ : Context) (L : ℕ) : (norm ρ L).childPositions = ρ.childPositions := by
    simp only [childPositions, hLen, hIsChild]
  have hRuns (ρ : Context) (L : ℕ) : (norm ρ L).numRuns = ρ.numRuns := by
    simp only [numRuns, hLen, ne_eq, hIsChild]
  have hBlocks (ρ : Context) (L : ℕ) : (norm ρ L).blocks = ρ.blocks := by
    simp only [blocks, hChild]
  have hK (ρ : Context) (L : ℕ) : (norm ρ L).k = ρ.k := rfl
  have hDepth (ρ : Context) (L : ℕ) (hL : Inv ρ L) :
      (norm ρ L).maxima.length = ρ.maxima.length - 1 := by
    obtain ⟨h1, h2, -, -⟩ := hL
    simp only [norm, List.length_append, List.length_take, List.length_singleton, List.length_drop]
    omega
  have hNormLevel (ρ : Context) (L : ℕ) (hL : Inv ρ L) (j : ℕ) (hj : j ∈ (norm ρ L).levels) :
      1 ≤ j ∧ j + 1 ≤ ρ.maxima.length := by
    have h := (hLevelMem (norm ρ L) j).mp hj
    rw [hDepth ρ L hL] at h
    omega
  -- levels and letters ---------------------------------------------------------
  have hExtLv (ρ : Context) (i : ℕ) : ρ.extPositions i = (List.range ρ.word.length).filter (lv ρ i) := by
    unfold extPositions
    apply List.filter_congr
    intro p _
    cases h : ρ.letterAt p with
    | child => simp [lv, h]
    | ext j v => simp [lv, h]
  have hExtMerged (ρ : Context) (L : ℕ) :
      (norm ρ L).extPositions L =
        (List.range ρ.word.length).filter (fun p => lv ρ L p || lv ρ (L + 1) p) := by
    unfold extPositions
    rw [hLen]
    apply List.filter_congr
    intro p _
    rw [hLetter]
    cases h : ρ.letterAt p with
    | child => simp [lv, h, letter]
    | ext j v =>
      by_cases hj : j ≤ L
      · simp only [letter, hj, if_true, lv, h]
        by_cases hjL : j = L <;> simp [hjL] <;> omega
      · simp only [letter, hj, if_false, lv, h]
        by_cases hjL : j = L + 1 <;> simp [hjL] <;> omega
  have hExtNe (ρ : Context) (L j : ℕ) (hj1 : 1 ≤ j) (hjL : j ≠ L) :
      (norm ρ L).extPositions j = ρ.extPositions (up L j) := by
    unfold extPositions
    rw [hLen]
    apply List.filter_congr
    intro p _
    rw [hLetter]
    cases h : ρ.letterAt p with
    | child => simp [letter]
    | ext i v =>
      by_cases hi : i ≤ L <;> by_cases hjl : j < L <;> simp [letter, hi, hjl, up] <;> omega
  have hMemMerged (ρ : Context) (L p : ℕ) (hp : p ∈ ρ.extPositions L) :
      p ∈ (norm ρ L).extPositions L := by
    rw [hExtMerged, List.mem_filter]
    rw [hExtLv, List.mem_filter] at hp
    exact ⟨hp.1, by simp [hp.2]⟩
  have hSideL (ρ : Context) (L : ℕ) (hL : Inv ρ L) : (norm ρ L).sideAt L = ρ.sideAt L := by
    obtain ⟨-, -, h3, -⟩ := hL
    rcases hh : ((norm ρ L).extPositions L).head? with _ | p
    · have hρ : (ρ.extPositions L).head? = none := by
        cases hh2 : (ρ.extPositions L).head? with
        | none => rfl
        | some q =>
          exfalso
          have hq := hMemMerged ρ L q (List.mem_of_mem_head? (Option.mem_def.mpr hh2))
          rw [List.head?_eq_none_iff] at hh
          rw [hh] at hq
          exact List.not_mem_nil hq
      simp only [sideAt, hh, hρ]
    · have hp : p ∈ (norm ρ L).extPositions L := List.mem_of_mem_head? (Option.mem_def.mpr hh)
      rw [hExtMerged, List.mem_filter] at hp
      cases hlet : ρ.letterAt p with
      | child => simp [lv, hlet] at hp
      | ext j v =>
        have hj : j = L ∨ j = L + 1 := by
          have := hp.2
          simp only [lv, hlet, Bool.or_eq_true, decide_eq_true_eq] at this
          exact this
        have hv := h3 p j v hlet hj
        rw [← hv]
        simp only [sideAt, hh, hLetter, hlet]
        by_cases hjL : j ≤ L <;> simp [letter, hjL]
  have hSideNe (ρ : Context) (L j : ℕ) (hj1 : 1 ≤ j) (hjL : j ≠ L) :
      (norm ρ L).sideAt j = ρ.sideAt (up L j) := by
    unfold sideAt
    rw [hExtNe ρ L j hj1 hjL]
    cases hh : (ρ.extPositions (up L j)).head? with
    | none => rfl
    | some p =>
      dsimp only
      rw [hLetter]
      cases ρ.letterAt p with
      | child => rfl
      | ext i v => by_cases hi : i ≤ L <;> simp [letter, hi]
  have hMax (ρ : Context) (L : ℕ) (hL : Inv ρ L) (j : ℕ) (hj1 : 1 ≤ j) :
      (norm ρ L).maximumAt j =
        if j < L then ρ.maximumAt j else if j = L then max (ρ.maximumAt L) (ρ.maximumAt (L + 1) + 1)
        else ρ.maximumAt (j + 1) := by
    obtain ⟨h1, h2, -, -⟩ := hL
    simp only [maximumAt, norm]
    rw [getElem?_merge ρ.maxima L (j - 1) _ h1 h2]
    by_cases hjl : j < L
    · simp [hjl, show j - 1 < L - 1 by omega]
    · by_cases hjL : j = L
      · subst hjL; simp
      · simp [hjl, hjL, show ¬ j - 1 < L - 1 by omega, show j - 1 ≠ L - 1 by omega,
          show j - 1 + 1 = j by omega]
  have hUpMono (L i j : ℕ) (h : i < j) : up L i < up L j := by
    dsimp [up]
    split_ifs <;> omega
  have hUpZero (L : ℕ) (hL : 1 ≤ L) : up L 0 = 0 := by
    simp [up, show 0 < L by omega]
  have hLive (ρ : Context) (L j : ℕ) (hL : Inv ρ L)
      (hj : j ∈ (norm ρ L).levels) :
      1 ≤ j ∧ j < ρ.maxima.length ∧ up L j ∈ ρ.levels := by
    have hh := hNormLevel ρ L hL j hj
    refine ⟨hh.1, by omega, ?_⟩
    apply (hLevelMem ρ _).mpr
    dsimp [up]
    split_ifs <;> omega
  have hSide (ρ : Context) (L j : ℕ) (hL : Inv ρ L)
      (hj : j ∈ (norm ρ L).levels) :
      (norm ρ L).sideAt j = ρ.sideAt (up L j) := by
    have hj1 := (hNormLevel ρ L hL j hj).1
    by_cases he : j = L
    · subst j
      rw [hSideL ρ L hL]
      simpa only [up, lt_self_iff_false, if_false] using hL.2.2.2
    · exact hSideNe ρ L j hj1 he
  have hNoMerged (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (v : Side) (hv : v ≠ ρ.sideAt L) (top j : ℕ)
      (hj : j ∈ (norm ρ L).levelsOn v top) : j ≠ L := by
    intro he
    subst j
    have hc : (norm ρ L).sideAt L = v ∧ (top = 0 ∨ L < top) :=
      of_decide_eq_true (List.mem_filter.mp hj).2
    rw [hSideL ρ L hL] at hc
    exact hv hc.1.symm
  have hMaximum (ρ : Context) (L j : ℕ) (hL : Inv ρ L)
      (hj : j ∈ (norm ρ L).levels) (hne : j ≠ L) :
      (norm ρ L).maximumAt j = ρ.maximumAt (up L j) := by
    rw [hMax ρ L hL j ((hNormLevel ρ L hL j hj).1)]
    by_cases hjl : j < L <;> simp [hjl, hne, up]
  have hOppLevels (ρ : Context) (L : ℕ) (hL : Inv ρ L) (v : Side)
      (hv : v ≠ ρ.sideAt L) (top : ℕ) :
      (((norm ρ L).levelsOn v top).map (up L)) = ρ.levelsOn v (up L top) := by
    have hs : (((norm ρ L).levelsOn v top).map (up L)).Pairwise (· < ·) :=
      ((hSorted (norm ρ L)).filter _).map (up L) (fun i j hij => hUpMono L i j hij)
    apply hs.eq_of_mem_iff ((hSorted ρ).filter _)
    intro i
    constructor
    · intro hi
      obtain ⟨j, hj, rfl⟩ := List.mem_map.mp hi
      have hjl := (List.mem_filter.mp hj).1
      have hjc : (norm ρ L).sideAt j = v ∧ (top = 0 ∨ j < top) :=
        of_decide_eq_true (List.mem_filter.mp hj).2
      apply List.mem_filter.mpr
      refine ⟨(hLive ρ L j hL hjl).2.2, ?_⟩
      apply decide_eq_true
      refine ⟨?_, ?_⟩
      · rw [← hSide ρ L j hL hjl]
        exact hjc.1
      · rcases hjc.2 with rfl | hlt
        · exact Or.inl (hUpZero L hL.1)
        · exact Or.inr (hUpMono L j top hlt)
    · intro hi
      have hil := (List.mem_filter.mp hi).1
      have hic : ρ.sideAt i = v ∧ (up L top = 0 ∨ i < up L top) :=
        of_decide_eq_true (List.mem_filter.mp hi).2
      have hiL : i ≠ L := by
        intro he
        subst i
        exact hv hic.1.symm
      let j := if i < L then i else i-1
      have hLr : 1 ≤ L ∧ L ≤ ρ.maxima.length := ⟨hL.1, by omega⟩
      have hir := (hLevelMem ρ i).mp hil
      have hjr : 1 ≤ j ∧ j < ρ.maxima.length ∧ up L j = i := by
        dsimp [j, up]
        split_ifs <;> omega
      have hjl : j ∈ (norm ρ L).levels := by
        apply (hLevelMem (norm ρ L) j).mpr
        rw [hDepth ρ L hL]
        omega
      apply List.mem_map.mpr
      refine ⟨j, ?_, hjr.2.2⟩
      apply List.mem_filter.mpr
      refine ⟨hjl, ?_⟩
      apply decide_eq_true
      refine ⟨?_, ?_⟩
      · rw [hSide ρ L j hL hjl, hjr.2.2]
        exact hic.1
      · rcases hic.2 with hzero | hlt
        · left
          by_contra hne
          have h := hUpMono L 0 top (by omega)
          rw [hUpZero L hLr.1, hzero] at h
          omega
        · right
          by_contra hn
          have hm : up L top ≤ up L j := by
            rcases lt_or_eq_of_le (show top ≤ j by omega) with hm | he
            · exact (hUpMono L top j hm).le
            · rw [he]
          rw [hjr.2.2] at hm
          omega
  have hFoldNormLeft (ρ : Context) (L : ℕ) (hL : Inv ρ L) :
      ∀ (ls : List ℕ), (∀ j ∈ ls, j ∈ (norm ρ L).levels ∧ j ≠ L) → ∀ z,
      ls.foldl (leftStep (norm ρ L)) z =
        (ls.map (up L)).foldl (leftStep ρ) z := by
    intro ls
    induction ls with
    | nil => intro _ z; rfl
    | cons j ls ih =>
      intro hj z
      simp only [List.foldl_cons, List.map_cons, leftStep,
        hExtNe ρ L j ((hLevelMem (norm ρ L) j).mp (hj j (by simp)).1).1
          (hj j (by simp)).2]
      exact ih (fun i hi => hj i (by simp [hi])) _
  have hFoldNormRight (ρ : Context) (L : ℕ) (hL : Inv ρ L) :
      ∀ (ls : List ℕ), (∀ j ∈ ls, j ∈ (norm ρ L).levels ∧ j ≠ L) → ∀ z,
      ls.foldl (rightStep (norm ρ L)) z =
        (ls.map (up L)).foldl (rightStep ρ) z := by
    intro ls
    induction ls with
    | nil => intro _ z; rfl
    | cons j ls ih =>
      intro hj z
      simp only [List.foldl_cons, List.map_cons, rightStep,
        hExtNe ρ L j ((hLevelMem (norm ρ L) j).mp (hj j (by simp)).1).1
          (hj j (by simp)).2]
      exact ih (fun i hi => hj i (by simp [hi])) _
  have hOppLeft (ρ : Context) (L : ℕ) (hL : Inv ρ L) (v : Side)
      (hv : v ≠ ρ.sideAt L) (top p : ℕ) :
      (norm ρ L).leftExt v top p = ρ.leftExt v (up L top) p := by
    rw [leftExt_eq, leftExt_eq, ← hOppLevels ρ L hL v hv top,
      List.sublists_map, List.map_map]
    apply congrArg (fun vals : List ℕ => vals.max?.getD 0)
    apply List.map_congr_left
    intro ls hls
    exact congrArg Prod.snd (hFoldNormLeft ρ L hL ls
      (fun j hj => ⟨(List.mem_filter.mp ((List.mem_sublists.mp hls).subset hj)).1,
        hNoMerged ρ L hL v hv top j ((List.mem_sublists.mp hls).subset hj)⟩) (p,0))
  have hOppRight (ρ : Context) (L : ℕ) (hL : Inv ρ L) (v : Side)
      (hv : v ≠ ρ.sideAt L) (top p : ℕ) :
      (norm ρ L).rightExt v top p = ρ.rightExt v (up L top) p := by
    rw [rightExt_eq, rightExt_eq, ← hOppLevels ρ L hL v hv top,
      List.sublists_map, List.map_map]
    apply congrArg (fun vals : List ℕ => vals.max?.getD 0)
    apply List.map_congr_left
    intro ls hls
    exact congrArg Prod.snd (hFoldNormRight ρ L hL ls
      (fun j hj => ⟨(List.mem_filter.mp ((List.mem_sublists.mp hls).subset hj)).1,
        hNoMerged ρ L hL v hv top j ((List.mem_sublists.mp hls).subset hj)⟩) (p,0))
  have hOppChain (ρ : Context) (L : ℕ) (hL : Inv ρ L) (v : Side)
      (hv : v ≠ ρ.sideAt L) (p q : ℕ) :
      (norm ρ L).chainExt v p q = ρ.chainExt v p q := by
    simp only [chainExt, hOppLeft ρ L hL v hv, hOppRight ρ L hL v hv,
      hUpZero L hL.1]
  have hOppJoin (ρ : Context) (L : ℕ) (hL : Inv ρ L) (v : Side)
      (hv : v ≠ ρ.sideAt L) (p q : ℕ) :
      (norm ρ L).joinExt v p q = ρ.joinExt v p q := by
    have hl : (((norm ρ L).levelsOn v 0).map (up L)) = ρ.levelsOn v 0 := by
      simpa only [hUpZero L hL.1] using hOppLevels ρ L hL v hv 0
    rw [joinExt, joinExt, hOppChain ρ L hL v hv, ← hl, List.map_map]
    congr 1
    apply congrArg (fun vals : List ℕ => vals.max?.getD 0)
    apply List.map_congr_left
    intro j hj
    rw [hOppLeft ρ L hL v hv, hOppRight ρ L hL v hv,
      hMaximum ρ L j hL (List.mem_filter.mp hj).1
        (hNoMerged ρ L hL v hv 0 j hj)]
    rfl
  sorry
