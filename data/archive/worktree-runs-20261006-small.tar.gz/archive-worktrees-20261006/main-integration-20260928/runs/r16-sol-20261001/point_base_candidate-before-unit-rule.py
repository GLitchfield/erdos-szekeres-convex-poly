"""R16 candidate potential on exactly-one-marked one-level roots; diagnostic only."""
from decomposable_depth2_tables import limits_from_signature
from enumerate_decomposable_colorings import threshold


def _root_point_base_comparison(evaluate, row):
    """Compare the full recursive bound to the largest initial per-run point base."""
    word = tuple(row["word"])
    runs, cups, caps = limits_from_signature(word, row["maxima"],
        row["a"], row["u"], row["k"], lean=True)
    assert runs >= 2
    bases = [threshold(int(caps[i, i]) + 1, int(cups[i, i]) + 1, row["k"])
        for i in range(runs)]
    value = evaluate(word, row["maxima"])
    return {"bound": value, "point_bases": bases, "largest_point_base": max(bases)}


def root_point_base_comparison(evaluate, row):
    word = tuple(row["word"])
    assert (word[0] == "S") != (word[-1] == "S")
    return _root_point_base_comparison(evaluate, row)


def both_marked_point_base_comparison(evaluate, row):
    word = tuple(row["word"])
    assert word[0] != "S" and word[-1] != "S"
    old_side = word[0][1]
    opposite_global = row["a"] if old_side == "lower" else row["u"]
    assert opposite_global >= 3
    return _root_point_base_comparison(evaluate, row)
