"""Small R16 upper-proof bridges; diagnostic claims, not Lean theorems."""
from math import comb
from enumerate_decomposable_colorings import threshold

def empty_history_triple_charge(a, u, k):
    """Chosen global exactly5; other global7/k7 in the tested family."""
    assert min(a, u) == 5 and a >= 2 and u >= 2
    opposite = max(a, u)
    return {"rank_interval": [1, opposite-1],
            "ordered_triples": comb(opposite+1, 3),
            "target": threshold(a, u, k)}

def scalar_normalized_split_charge(a, u, k, maximum):
    """Opposite cap a, chosen cup u; positive coupled maxima in1..k-2."""
    assert 3 <= a <= k and 3 <= u <= k and 1 <= maximum <= k-2
    companion = k-1-maximum
    own = threshold(a, min(u-1, k-maximum), k)
    other = threshold(min(a, k-companion), u, k)
    return {"maximum": maximum, "companion": companion,
            "own": own, "other": other, "charge": own+other,
            "target": threshold(a, u, k)}
