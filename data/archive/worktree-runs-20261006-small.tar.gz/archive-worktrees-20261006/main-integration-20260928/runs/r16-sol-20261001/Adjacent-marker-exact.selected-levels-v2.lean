  have hYoungLevels (ρ : Context) (L : ℕ) (hL : Inv ρ L) :
      (norm ρ L).levelsOn (ρ.sideAt L) L = ρ.levelsOn (ρ.sideAt L) L := by
    apply ((hSorted (norm ρ L)).filter _).eq_of_mem_iff ((hSorted ρ).filter _)
    intro j
    constructor
    · intro hj
      have hjl := (List.mem_filter.mp hj).1
      have hjc : (norm ρ L).sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
        of_decide_eq_true (List.mem_filter.mp hj).2
      have hjlt : j < L := by omega
      have hj1 := (hNormLevel ρ L hL j hjl).1
      have hs := hSideNe ρ L j hj1 (by omega)
      have hu : up L j = j := by simp [up, hjlt]
      rw [hu] at hs
      exact List.mem_filter.mpr ⟨by
        have hh := (hLive ρ L j hL hjl).2.2
        simpa only [hu] using hh,
        by apply decide_eq_true; exact ⟨hs.symm.trans hjc.1, Or.inr hjlt⟩⟩
    · intro hj
      have hjl := (List.mem_filter.mp hj).1
      have hjc : ρ.sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
        of_decide_eq_true (List.mem_filter.mp hj).2
      have hjlt : j < L := by omega
      have hj1 := ((hLevelMem ρ j).mp hjl).1
      have hjn : j ∈ (norm ρ L).levels := by
        apply (hLevelMem (norm ρ L) j).mpr
        rw [hDepth ρ L hL]
        omega
      have hs := hSideNe ρ L j hj1 (by omega)
      have hu : up L j = j := by simp [up, hjlt]
      rw [hu] at hs
      exact List.mem_filter.mpr ⟨hjn,
        by apply decide_eq_true; exact ⟨hs.trans hjc.1, Or.inr hjlt⟩⟩
  have hSourcePairLevels (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1) :
      ρ.levelsOn (ρ.sideAt L) 0 = ρ.levelsOn (ρ.sideAt L) L ++ [L, L + 1] := by
    have hLs : L ∈ ρ.levelsOn (ρ.sideAt L) 0 := by
      apply List.mem_filter.mpr
      exact ⟨(hLevelMem ρ L).mpr ⟨hL.1, by omega⟩, by simp⟩
    have hL1s : L + 1 ∈ ρ.levelsOn (ρ.sideAt L) 0 := by
      apply List.mem_filter.mpr
      exact ⟨(hLevelMem ρ (L + 1)).mpr ⟨by omega, hL.2.1⟩,
        by simp only [decide_eq_true_eq]; exact ⟨hL.2.2.2.symm, Or.inl rfl⟩⟩
    have hs : (ρ.levelsOn (ρ.sideAt L) L ++ [L, L + 1]).Pairwise (· < ·) := by
      apply List.pairwise_append.mpr
      refine ⟨(hSorted ρ).filter _, by simp, ?_⟩
      intro i hi j hj
      have hc : ρ.sideAt i = ρ.sideAt L ∧ (L = 0 ∨ i < L) :=
        of_decide_eq_true (List.mem_filter.mp hi).2
      have hiL : i < L := by omega
      simp only [List.mem_cons, List.mem_singleton] at hj
      rcases hj with rfl | rfl <;> omega
    apply ((hSorted ρ).filter _).eq_of_mem_iff hs
    intro j
    constructor
    · intro hj
      have hjL := ht j hj
      by_cases he : j = L
      · simp [he]
      by_cases he1 : j = L + 1
      · simp [he1]
      apply List.mem_append.mpr
      left
      apply List.mem_filter.mpr
      refine ⟨(List.mem_filter.mp hj).1, ?_⟩
      apply decide_eq_true
      have hc : ρ.sideAt j = ρ.sideAt L ∧ (0 = 0 ∨ j < 0) :=
        of_decide_eq_true (List.mem_filter.mp hj).2
      exact ⟨hc.1, Or.inr (by omega)⟩
    · intro hj
      rcases List.mem_append.mp hj with hj | hj
      · apply List.mem_filter.mpr
        refine ⟨(List.mem_filter.mp hj).1, ?_⟩
        apply decide_eq_true
        have hc : ρ.sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
          of_decide_eq_true (List.mem_filter.mp hj).2
        exact ⟨hc.1, Or.inl rfl⟩
      · simp only [List.mem_cons, List.mem_singleton] at hj
        rcases hj with rfl | rfl
        · exact hLs
        · exact hL1s
  have hSourceOwnLevels (ρ : Context) (L : ℕ) (hL : L ∈ ρ.levels)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L) :
      ρ.levelsOn (ρ.sideAt L) 0 = ρ.levelsOn (ρ.sideAt L) L ++ [L] := by
    have hLs : L ∈ ρ.levelsOn (ρ.sideAt L) 0 := by simp [levelsOn, hL]
    have hs : (ρ.levelsOn (ρ.sideAt L) L ++ [L]).Pairwise (· < ·) := by
      apply List.pairwise_append.mpr
      refine ⟨(hSorted ρ).filter _, by simp, ?_⟩
      intro i hi j hj
      have he : j = L := by simpa using hj
      subst j
      have hc : ρ.sideAt i = ρ.sideAt L ∧ (L = 0 ∨ i < L) :=
        of_decide_eq_true (List.mem_filter.mp hi).2
      have hL1 := one_le_of_mem_levels hL
      omega
    apply ((hSorted ρ).filter _).eq_of_mem_iff hs
    intro j
    constructor
    · intro hj
      have hjL := ht j hj
      by_cases he : j = L
      · simp [he]
      · apply List.mem_append.mpr
        left
        apply List.mem_filter.mpr
        refine ⟨(List.mem_filter.mp hj).1, ?_⟩
        apply decide_eq_true
        have hc : ρ.sideAt j = ρ.sideAt L ∧ (0 = 0 ∨ j < 0) :=
          of_decide_eq_true (List.mem_filter.mp hj).2
        exact ⟨hc.1, Or.inr (by omega)⟩
    · intro hj
      rcases List.mem_append.mp hj with hj | hj
      · apply List.mem_filter.mpr
        refine ⟨(List.mem_filter.mp hj).1, ?_⟩
        apply decide_eq_true
        have hc : ρ.sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
          of_decide_eq_true (List.mem_filter.mp hj).2
        exact ⟨hc.1, Or.inl rfl⟩
      · have he : j = L := by simpa using hj
        simpa [levelsOn, he] using hLs
  have hNormOwnLevels (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1) :
      (norm ρ L).levelsOn (ρ.sideAt L) 0 =
        ρ.levelsOn (ρ.sideAt L) L ++ [L] := by
    have hNL : L ∈ (norm ρ L).levels := by
      apply (hLevelMem (norm ρ L) L).mpr
      rw [hDepth ρ L hL]
      omega
    have hAll : ∀ j ∈ (norm ρ L).levelsOn ((norm ρ L).sideAt L) 0, j ≤ L := by
      intro j hj
      have hjl := (List.mem_filter.mp hj).1
      have hjc : (norm ρ L).sideAt j = (norm ρ L).sideAt L ∧ (0 = 0 ∨ j < 0) :=
        of_decide_eq_true (List.mem_filter.mp hj).2
      have hh : up L j ∈ ρ.levelsOn (ρ.sideAt L) 0 := by
        apply List.mem_filter.mpr
        refine ⟨(hLive ρ L j hL hjl).2.2, ?_⟩
        apply decide_eq_true
        rw [← hSide ρ L j hL hjl, ← hSideL ρ L hL]
        exact ⟨hjc.1, Or.inl rfl⟩
      have hm := ht (up L j) hh
      dsimp [up] at hm
      split_ifs at hm <;> omega
    have hh := hSourceOwnLevels (norm ρ L) L hNL hAll
    rw [hSideL ρ L hL, hYoungLevels ρ L hL] at hh
    exact hh
  have hYoungFoldLeft (ρ : Context) (L : ℕ) (hL : Inv ρ L) :
      ∀ ls, ls ∈ (ρ.levelsOn (ρ.sideAt L) L).sublists → ∀ z,
      ls.foldl (leftStep (norm ρ L)) z = ls.foldl (leftStep ρ) z := by
    intro ls
    have hGeneral : ∀ ls, (∀ j ∈ ls, j ∈ ρ.levelsOn (ρ.sideAt L) L) → ∀ z,
        ls.foldl (leftStep (norm ρ L)) z = ls.foldl (leftStep ρ) z := by
      intro ls
      induction ls with
      | nil => intro _ z; rfl
      | cons j ls ih =>
        intro hj z
        have hjl := (List.mem_filter.mp (hj j (by simp))).1
        have hjc : ρ.sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
          of_decide_eq_true (List.mem_filter.mp (hj j (by simp))).2
        have hjlt : j < L := by omega
        have hj1 := ((hLevelMem ρ j).mp hjl).1
        have he := hExtNe ρ L j hj1 (by omega)
        rw [show up L j = j by simp [up, hjlt]] at he
        simp only [List.foldl_cons, leftStep, he]
        exact ih (fun i hi => hj i (by simp [hi])) _
    intro hls z
    exact hGeneral ls (fun j hj => (List.mem_sublists.mp hls).subset hj) z
  have hDecomposeSublists (Y T ls : List ℕ) (hls : ls ∈ (Y ++ T).sublists) :
      ∃ ys ∈ Y.sublists, ∃ ts ∈ T.sublists, ls = ys ++ ts := by
    rw [List.sublists_append, List.bind_eq_flatMap] at hls
    obtain ⟨ts, hts, hh⟩ := List.mem_flatMap.mp hls
    obtain ⟨ys, hys, he⟩ := List.mem_map.mp hh
    exact ⟨ys, hys, ts, hts, he.symm⟩
  have hFoldCountLeft (ρ : Context) : ∀ ls (z : ℕ × ℕ),
      (ls.foldl (leftStep ρ) z).2 ≤ z.2 + ls.length := by
    intro ls
    induction ls with
    | nil => intro z; simp
    | cons j ls ih =>
      intro z
      have hstep : (leftStep ρ z j).2 ≤ z.2 + 1 := by
        cases hh : ((ρ.extPositions j).filter (· < z.1)).getLast? <;>
          simp [leftStep, hh]
      have hh := ih (leftStep ρ z j)
      simp only [List.foldl_cons, List.length_cons]
      omega
  have hLeftStepAdd (ρ : Context) (j e c : ℕ)
      (hex : ∃ y ∈ ρ.extPositions j, y < e) :
      (leftStep ρ (e,c) j).2 = c + 1 := by
    cases hh : ((ρ.extPositions j).filter (· < e)).getLast? with
    | some y => simp [leftStep, hh]
    | none =>
      obtain ⟨y, hy, hye⟩ := hex
      have hm : y ∈ (ρ.extPositions j).filter (· < e) := by simp [hy, hye]
      rw [List.getLast?_eq_none_iff] at hh
      rw [hh] at hm
      exact False.elim (List.not_mem_nil hm)
  have hFoldBoundary (ρ : Context) (x : ℕ) (dir : Bool) :
      ∀ (ls : List ℕ),
      (∀ j ∈ ls, ∀ y ∈ ρ.extPositions j, if dir then y < x else x < y) →
      ∀ z : ℕ × ℕ, (if dir then z.1 < x else x < z.1) →
      (if dir then (ls.foldl (leftStep ρ) z).1 < x
        else x < (ls.foldl (leftStep ρ) z).1) ∧
      (if dir then (ls.foldl (rightStep ρ) z).1 < x
        else x < (ls.foldl (rightStep ρ) z).1) := by
    intro ls
    induction ls with
    | nil => intro _ z hz; exact ⟨hz,hz⟩
    | cons j ls ih =>
      intro hy z hz
      have ht := fun i hi y hiy => hy i (List.mem_cons_of_mem j hi) y hiy
      constructor
      · cases hh : ((ρ.extPositions j).filter (· < z.1)).getLast? with
        | none => simpa only [List.foldl_cons, leftStep, hh] using (ih ht z hz).1
        | some y =>
          have hm := List.mem_of_mem_getLast? (Option.mem_def.mpr hh)
          have hyx := hy j (by simp) y (List.mem_filter.mp hm).1
          simpa only [List.foldl_cons, leftStep, hh] using (ih ht (y,z.2+1) hyx).1
      · cases hh : ((ρ.extPositions j).filter (z.1 < ·)).head? with
        | none => simpa only [List.foldl_cons, rightStep, hh] using (ih ht z hz).2
        | some y =>
          have hm := List.mem_of_mem_head? (Option.mem_def.mpr hh)
          have hyx := hy j (by simp) y (List.mem_filter.mp hm).1
          simpa only [List.foldl_cons, rightStep, hh] using (ih ht (y,z.2+1) hyx).2
