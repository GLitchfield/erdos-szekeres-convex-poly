import json, hashlib, time
from pathlib import Path
from harness.research.context_bound import compiled_evaluator
from harness.research.singleton_cuts import singleton_cut_values
paths = [Path("harness/research/context_bound.py"), Path("harness/research/context_bound.c"), Path("harness/research/singleton_cuts.py"), Path("harness/research/primitives.py")]
pins = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
row = {"a":2,"u":3,"k":4,"word":("S","S",(1,"lower"),"S","S"),"maxima":(1,),"chosen":"lower"}
print(json.dumps({"done":0,"total":1,"row":row}),flush=True)
start = time.monotonic()
F = compiled_evaluator(2,3,4,cache_size=16000,persistent=True)
try:
    b = F(row["word"],row["maxima"])
    cuts = singleton_cut_values(F,row)
finally:
    F.close()
assert pins == {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
result = {"semantics":"context-bound-zero-children-c-v1","row":row,"bound":b,"cuts":cuts,"best_by_position":{p:max(c[0] for c in cuts if c[1]==p) for p in (0,1,3,4)},"seconds":time.monotonic()-start,"source_sha256":pins,"complete":True}
Path("runs/r16-sol-20261001/global-end-k4-obstruction-timing.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"done":1,"total":1,"result":result}),flush=True)
