import sqlite3,json,time
started=time.monotonic()
try:
 c=sqlite3.connect("file:/home/gavin/git/erdos-szekeres-convex-poly/.es/erdos-szekeres/es.db?mode=ro",uri=True,timeout=1)
 c.row_factory=sqlite3.Row
 row=c.execute("SELECT id,status,started_at,finished_at,exit_code,result_json,agent FROM jobs WHERE id=?",("20261001-120130-152844",)).fetchone()
 result={"ok":True,"job":dict(row) if row else None,"semantics":"read-only-job-metadata-v1"}
 c.close()
except sqlite3.OperationalError as e:
 result={"ok":False,"error":str(e),"semantics":"read-only-job-metadata-v1"}
result["seconds"]=time.monotonic()-started
print(json.dumps(result))
