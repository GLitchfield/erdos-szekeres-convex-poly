#!/usr/bin/env python3
"""Measure/test the R16 one-marked-end point-base candidate using shared evaluators."""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from probe_boundary_normalization import root_words
from point_base_candidate import root_point_base_comparison


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--max-runs", type=int, default=4)
    parser.add_argument("--max-len", type=int, default=2)
    parser.add_argument("--max-children", type=int, default=4)
    parser.add_argument("--timing-only", action="store_true")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    k = args.k
    assert k >= 3
    words = [w for w in root_words(args.max_runs, args.max_len, args.max_children)
        if (w[0] == "S") != (w[-1] == "S")]
    parameters = [(k, k)] if args.timing_only else list(
        itertools.product(range(1, k + 1), repeat=2))
    maxima = [1] if args.timing_only else list(range(1, k - 1))
    if args.timing_only:
        words = [max(words, key=len)]
    total = len(parameters) * len(maxima) * len(words)
    done = violations_count = 0
    witnesses = []
    started = time.monotonic()
    print(json.dumps({"roots_done": 0, "total_roots": total}), flush=True)
    for a, u in parameters:
        evaluate = compiled_evaluator(a, u, k, cache_size=200000, persistent=True)
        try:
            for m in maxima:
                for word in words:
                    row = {"word": word, "maxima": (m,), "a": a, "u": u, "k": k}
                    comparison = root_point_base_comparison(evaluate, row)
                    if comparison["bound"] > comparison["largest_point_base"]:
                        violations_count += 1
                        if len(witnesses) < 20:
                            witnesses.append({**row, **comparison})
                    done += 1
                    if done % 100 == 0 or done == total:
                        elapsed = time.monotonic() - started
                        print(json.dumps({"roots_done": done, "total_roots": total,
                            "seconds": elapsed, "roots_per_second": done / elapsed,
                            "violations": violations_count}), flush=True)
        finally:
            evaluate.close()
    paths = [Path(__file__), Path(__file__).with_name("point_base_candidate.py"),
        Path(__file__).with_name("probe_boundary_normalization.py"),
        Path(__file__).with_name("N-ends.falsifier.py"),
        ROOT / "harness/research/context_bound.py",
        ROOT / "harness/research/context_bound.c",
        ROOT / "scripts/decomposable_depth2_tables.py",
        ROOT / "scripts/enumerate_decomposable_colorings.py"]
    result = {"candidate": "R16 exactly-one-marked root bound <= largest initial point base",
        "semantics": "context-bound-zero-children-c-v1", "args": vars(args),
        "roots_done": done, "total_roots": total, "violations": violations_count,
        "witnesses": witnesses, "seconds": time.monotonic() - started,
        "source_sha256": {str(p.relative_to(ROOT)):
            hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        "complete": done == total}
    Path(args.out).write_text(json.dumps(result, indent=2) + "\n")
    return 2 if violations_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
