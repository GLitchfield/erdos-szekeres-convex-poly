  have hYoungFoldRight (ρ : Context) (L : ℕ) (hL : Inv ρ L) :
      ∀ (ls : List ℕ), ls ∈ (ρ.levelsOn (ρ.sideAt L) L).sublists → ∀ (z : ℕ × ℕ),
      ls.foldl (rightStep (norm ρ L)) z = ls.foldl (rightStep ρ) z := by
    intro ls
    have hGeneral : ∀ (ls : List ℕ),
        (∀ j ∈ ls, j ∈ ρ.levelsOn (ρ.sideAt L) L) → ∀ (z : ℕ × ℕ),
        ls.foldl (rightStep (norm ρ L)) z = ls.foldl (rightStep ρ) z := by
      intro ls
      induction ls with
      | nil => intro _ z; rfl
      | cons j ls ih =>
        intro hj z
        have hjl := (List.mem_filter.mp (hj j (by simp))).1
        have hjc : ρ.sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
          of_decide_eq_true (List.mem_filter.mp (hj j (by simp))).2
        have hjlt : j < L := by omega
        have hj1 := ((hLevelMem ρ j).mp hjl).1
        have he := hExtNe ρ L j hj1 (by omega)
        rw [show up L j = j by simp [up, hjlt]] at he
        simp only [List.foldl_cons, rightStep, he]
        exact ih (fun i hi => hj i (by simp [hi])) _
    intro hls z
    exact hGeneral ls (fun j hj => (List.mem_sublists.mp hls).subset hj) z
  have hMergedRightStep (ρ : Context) (L x : ℕ)
      (hsingle : ρ.extPositions L = [x]) (z : ℕ × ℕ) (hx : x < z.1) :
      rightStep (norm ρ L) z L = rightStep ρ z (L + 1) := by
    have he : ((norm ρ L).extPositions L).filter (z.1 < ·) =
        (ρ.extPositions (L + 1)).filter (z.1 < ·) := by
      have hs₁ : ((norm ρ L).extPositions L).Pairwise (· < ·) :=
        List.pairwise_lt_range.filter _
      have hs₂ : (ρ.extPositions (L + 1)).Pairwise (· < ·) :=
        List.pairwise_lt_range.filter _
      apply (hs₁.filter _).eq_of_mem_iff (hs₂.filter _)
      intro p
      rw [hExtMerged, hExtLv]
      simp only [List.mem_filter, Bool.or_eq_true, decide_eq_true_eq]
      constructor
      · rintro ⟨⟨hp, hpL | hpO⟩, hzp⟩
        · have hm : p ∈ ρ.extPositions L := by
            rw [hExtLv]
            exact List.mem_filter.mpr ⟨hp, hpL⟩
          have hpx : p = x := by simpa [hsingle] using hm
          omega
        · exact ⟨⟨hp, hpO⟩, hzp⟩
      · rintro ⟨⟨hp, hpO⟩, hzp⟩
        exact ⟨⟨hp, Or.inr hpO⟩, hzp⟩
    simp only [rightStep, he]
  have hNewRightStep (ρ : Context) (L x : ℕ)
      (hsingle : ρ.extPositions L = [x]) (z : ℕ × ℕ) (hx : x < z.1) :
      rightStep ρ z L = z := by
    rcases z with ⟨e,c⟩
    simp only at hx
    simp [rightStep, hsingle, show ¬ e < x by omega]
  have hOwnRight (ρ : Context) (L x : ℕ) (hL : Inv ρ L)
      (hsingle : ρ.extPositions L = [x])
      (hc : ∀ p ∈ ρ.childPositions, x < p)
      (hy : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) L, ∀ p ∈ ρ.extPositions j, x < p)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (p : ℕ) (hp : p ∈ ρ.childPositions) :
      ρ.rightExt (ρ.sideAt L) 0 p = (norm ρ L).rightExt (ρ.sideAt L) 0 p := by
    let Y := ρ.levelsOn (ρ.sideAt L) L
    have hTail (ys ts : List ℕ) (hys : ys ∈ Y.sublists)
        (hts : ts ∈ [L, L + 1].sublists) :
        ∃ us ∈ [L].sublists,
          (ys ++ ts).foldl (rightStep ρ) (p,0) =
            (ys ++ us).foldl (rightStep (norm ρ L)) (p,0) := by
      let z := ys.foldl (rightStep ρ) (p,0)
      have hz := (hFoldBoundary ρ x false ys
        (fun j hj y hiy => hy j ((List.mem_sublists.mp hys).subset hj) y hiy)
        (p,0) (hc p hp)).2
      change x < z.1 at hz
      have hcases : ts = [] ∨ ts = [L] ∨ ts = [L + 1] ∨ ts = [L, L + 1] := by
        simpa [List.sublists_cons] using hts
      rcases hcases with rfl | rfl | rfl | rfl
      · refine ⟨[], by simp, ?_⟩
        simpa only [List.append_nil] using (hYoungFoldRight ρ L hL ys hys (p,0)).symm
      · refine ⟨[], by simp, ?_⟩
        rw [List.foldl_append, List.append_nil, hYoungFoldRight ρ L hL ys hys]
        change rightStep ρ z L = z
        exact hNewRightStep ρ L x hsingle z hz
      · refine ⟨[L], by simp [List.sublists_cons], ?_⟩
        rw [List.foldl_append, List.foldl_append, hYoungFoldRight ρ L hL ys hys]
        change rightStep ρ z (L + 1) = rightStep (norm ρ L) z L
        exact (hMergedRightStep ρ L x hsingle z hz).symm
      · refine ⟨[L], by simp [List.sublists_cons], ?_⟩
        rw [List.foldl_append, List.foldl_append, hYoungFoldRight ρ L hL ys hys]
        change rightStep ρ (rightStep ρ z L) (L + 1) = rightStep (norm ρ L) z L
        rw [hNewRightStep ρ L x hsingle z hz]
        exact (hMergedRightStep ρ L x hsingle z hz).symm
    have hBack (ys us : List ℕ) (hys : ys ∈ Y.sublists)
        (hus : us ∈ [L].sublists) :
        ∃ ts ∈ [L, L + 1].sublists,
          (ys ++ us).foldl (rightStep (norm ρ L)) (p,0) =
            (ys ++ ts).foldl (rightStep ρ) (p,0) := by
      let z := ys.foldl (rightStep ρ) (p,0)
      have hz := (hFoldBoundary ρ x false ys
        (fun j hj y hiy => hy j ((List.mem_sublists.mp hys).subset hj) y hiy)
        (p,0) (hc p hp)).2
      change x < z.1 at hz
      have hcases : us = [] ∨ us = [L] := by simpa [List.sublists_cons] using hus
      rcases hcases with rfl | rfl
      · refine ⟨[], by simp, ?_⟩
        simpa only [List.append_nil] using hYoungFoldRight ρ L hL ys hys (p,0)
      · refine ⟨[L + 1], by simp [List.sublists_cons], ?_⟩
        rw [List.foldl_append, List.foldl_append, hYoungFoldRight ρ L hL ys hys]
        change rightStep (norm ρ L) z L = rightStep ρ z (L + 1)
        exact hMergedRightStep ρ L x hsingle z hz
    apply le_antisymm
    · rw [rightExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ls, hls, rfl⟩ := List.mem_map.mp hz
      rw [hSourcePairLevels ρ L hL ht] at hls
      obtain ⟨ys, hys, ts, hts, rfl⟩ := hDecomposeSublists Y [L, L + 1] ls hls
      obtain ⟨us, hus, he⟩ := hTail ys ts hys hts
      have hsub : ys ++ us ∈ ((norm ρ L).levelsOn (ρ.sideAt L) 0).sublists := by
        rw [hNormOwnLevels ρ L hL ht]
        exact List.mem_sublists.mpr ((List.mem_sublists.mp hys).append (List.mem_sublists.mp hus))
      rw [he, rightExt_eq]
      exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys ++ us, hsub, rfl⟩)
    · rw [rightExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ls, hls, rfl⟩ := List.mem_map.mp hz
      rw [hNormOwnLevels ρ L hL ht] at hls
      obtain ⟨ys, hys, us, hus, rfl⟩ := hDecomposeSublists Y [L] ls hls
      obtain ⟨ts, hts, he⟩ := hBack ys us hys hus
      have hsub : ys ++ ts ∈ (ρ.levelsOn (ρ.sideAt L) 0).sublists := by
        rw [hSourcePairLevels ρ L hL ht]
        exact List.mem_sublists.mpr ((List.mem_sublists.mp hys).append (List.mem_sublists.mp hts))
      rw [he, rightExt_eq]
      exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys ++ ts, hsub, rfl⟩)
