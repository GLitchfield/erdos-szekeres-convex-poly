  have hSourceLeft (ρ : Context) (L x : ℕ) (hL : Inv ρ L)
      (hsingle : ρ.extPositions L = [x])
      (hbefore : ∃ y ∈ ρ.extPositions (L + 1), y < x)
      (hc : ∀ p ∈ ρ.childPositions, x < p)
      (hy : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) L, ∀ p ∈ ρ.extPositions j, x < p)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (p : ℕ) (hp : p ∈ ρ.childPositions) :
      ρ.leftExt (ρ.sideAt L) 0 p = ρ.leftExt (ρ.sideAt L) L p + 2 := by
    let Y := ρ.levelsOn (ρ.sideAt L) L
    have hAdd (ys : List ℕ) (hys : ys ∈ Y.sublists) :
        ((ys ++ [L, L + 1]).foldl (leftStep ρ) (p,0)).2 =
          (ys.foldl (leftStep ρ) (p,0)).2 + 2 := by
      let z := ys.foldl (leftStep ρ) (p,0)
      have hz := (hFoldBoundary ρ x false ys
        (fun j hj y hiy => hy j ((List.mem_sublists.mp hys).subset hj) y hiy)
        (p,0) (hc p hp)).1
      change x < z.1 at hz
      have hs : leftStep ρ z L = (x, z.2 + 1) := by
        simp [leftStep, hsingle, hz]
      rw [List.foldl_append]
      change (leftStep ρ (leftStep ρ z L) (L + 1)).2 = z.2 + 2
      rw [hs, hLeftStepAdd ρ (L + 1) x (z.2 + 1) hbefore]
      omega
    have hLe (ys : List ℕ) (hys : ys ∈ Y.sublists) :
        (ys.foldl (leftStep ρ) (p,0)).2 + 2 ≤ ρ.leftExt (ρ.sideAt L) 0 p := by
      have hsub : ys ++ [L, L + 1] ∈ (ρ.levelsOn (ρ.sideAt L) 0).sublists := by
        rw [hSourcePairLevels ρ L hL ht]
        exact List.mem_sublists.mpr ((List.mem_sublists.mp hys).append (List.Sublist.refl _))
      have hh : ((ys ++ [L, L + 1]).foldl (leftStep ρ) (p,0)).2 ≤
          ρ.leftExt (ρ.sideAt L) 0 p := by
        rw [leftExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys ++ [L, L + 1], hsub, rfl⟩)
      rwa [hAdd ys hys] at hh
    apply le_antisymm
    · rw [leftExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ls, hls, rfl⟩ := List.mem_map.mp hz
      rw [hSourcePairLevels ρ L hL ht] at hls
      obtain ⟨ys, hys, ts, hts, rfl⟩ := hDecomposeSublists Y [L, L + 1] ls hls
      have hcount := hFoldCountLeft ρ ts (ys.foldl (leftStep ρ) (p,0))
      have hlen : ts.length ≤ 2 := by
        simpa using (List.mem_sublists.mp hts).length_le
      have hprefix : (ys.foldl (leftStep ρ) (p,0)).2 ≤
          ρ.leftExt (ρ.sideAt L) L p := by
        rw [leftExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys, hys, rfl⟩)
      rw [List.foldl_append]
      omega
    · have h2 : 2 ≤ ρ.leftExt (ρ.sideAt L) 0 p := by
        simpa using hLe [] (List.mem_sublists.mpr (List.nil_sublist _))
      have hyoung : ρ.leftExt (ρ.sideAt L) L p ≤ ρ.leftExt (ρ.sideAt L) 0 p - 2 := by
        rw [leftExt_eq]
        apply getD_max?_le
        intro z hz
        obtain ⟨ys, hys, rfl⟩ := List.mem_map.mp hz
        have hh := hLe ys hys
        omega
      omega
  have hNormLeft (ρ : Context) (L x : ℕ) (hL : Inv ρ L)
      (hsingle : ρ.extPositions L = [x])
      (hc : ∀ p ∈ ρ.childPositions, x < p)
      (hy : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) L, ∀ p ∈ ρ.extPositions j, x < p)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (p : ℕ) (hp : p ∈ ρ.childPositions) :
      (norm ρ L).leftExt (ρ.sideAt L) 0 p = ρ.leftExt (ρ.sideAt L) L p + 1 := by
    let Y := ρ.levelsOn (ρ.sideAt L) L
    have hx : x ∈ (norm ρ L).extPositions L :=
      hMemMerged ρ L x (by simp [hsingle])
    have hAdd (ys : List ℕ) (hys : ys ∈ Y.sublists) :
        ((ys ++ [L]).foldl (leftStep (norm ρ L)) (p,0)).2 =
          (ys.foldl (leftStep ρ) (p,0)).2 + 1 := by
      let z := ys.foldl (leftStep ρ) (p,0)
      have hz := (hFoldBoundary ρ x false ys
        (fun j hj y hiy => hy j ((List.mem_sublists.mp hys).subset hj) y hiy)
        (p,0) (hc p hp)).1
      change x < z.1 at hz
      rw [List.foldl_append, hYoungFoldLeft ρ L hL ys hys]
      change (leftStep (norm ρ L) z L).2 = z.2 + 1
      exact hLeftStepAdd (norm ρ L) L z.1 z.2 ⟨x, hx, hz⟩
    have hLe (ys : List ℕ) (hys : ys ∈ Y.sublists) :
        (ys.foldl (leftStep ρ) (p,0)).2 + 1 ≤
          (norm ρ L).leftExt (ρ.sideAt L) 0 p := by
      have hsub : ys ++ [L] ∈ ((norm ρ L).levelsOn (ρ.sideAt L) 0).sublists := by
        rw [hNormOwnLevels ρ L hL ht]
        exact List.mem_sublists.mpr ((List.mem_sublists.mp hys).append (List.Sublist.refl _))
      have hh : ((ys ++ [L]).foldl (leftStep (norm ρ L)) (p,0)).2 ≤
          (norm ρ L).leftExt (ρ.sideAt L) 0 p := by
        rw [leftExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys ++ [L], hsub, rfl⟩)
      rwa [hAdd ys hys] at hh
    apply le_antisymm
    · rw [leftExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ls, hls, rfl⟩ := List.mem_map.mp hz
      rw [hNormOwnLevels ρ L hL ht] at hls
      obtain ⟨ys, hys, ts, hts, rfl⟩ := hDecomposeSublists Y [L] ls hls
      have hcount := hFoldCountLeft (norm ρ L) ts
        (ys.foldl (leftStep (norm ρ L)) (p,0))
      rw [hYoungFoldLeft ρ L hL ys hys] at hcount
      have hlen : ts.length ≤ 1 := by
        simpa using (List.mem_sublists.mp hts).length_le
      have hprefix : (ys.foldl (leftStep ρ) (p,0)).2 ≤
          ρ.leftExt (ρ.sideAt L) L p := by
        rw [leftExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys, hys, rfl⟩)
      rw [List.foldl_append, hYoungFoldLeft ρ L hL ys hys]
      omega
    · have h1 : 1 ≤ (norm ρ L).leftExt (ρ.sideAt L) 0 p := by
        simpa using hLe [] (List.mem_sublists.mpr (List.nil_sublist _))
      have hyoung : ρ.leftExt (ρ.sideAt L) L p ≤
          (norm ρ L).leftExt (ρ.sideAt L) 0 p - 1 := by
        rw [leftExt_eq]
        apply getD_max?_le
        intro z hz
        obtain ⟨ys, hys, rfl⟩ := List.mem_map.mp hz
        have hh := hLe ys hys
        omega
      omega
