from pathlib import Path
import sys,json,time,hashlib
root=Path.cwd();sys.path[:0]=[str(root),str(root/"scripts"),str(root/"runs/r16-sol-20261001")]
from harness.research.recursive import evaluator
from harness.research.context_bound import compiled_evaluator
from enumerate_decomposable_colorings import threshold
paths=[root/p for p in ["harness/research/recursive.py","scripts/decomposable_recursive_formula.py","scripts/decomposable_additivity_test.py","scripts/decomposable_depth2_tables.py","scripts/enumerate_decomposable_colorings.py"]]
before={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
w=tuple([z for _ in range(4) for z in ((1,"lower"),"S")]+[(1,"lower")])
e=evaluator(7,5,7,semantics="context-bound-zero-children-v1",cache_size=200000)
start=time.monotonic();v=e(w,());elapsed=time.monotonic()-start
compact=compiled_evaluator(7,5,7,persistent=True)
try:cv=compact(("S",)*4,())
finally:compact.close()
assert before=={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
row={"word":w,"maxima":[],"a":7,"u":5,"k":7,"bound":v,"bound_semantics":"context-bound-zero-children-v1 Python reference","compact_bound":cv,"compact_semantics":"context-bound-zero-children-c-v1","target":threshold(7,5,7),"seconds":elapsed,"source_sha256":before,"diagnostic_only":True}
(root/"runs/r16-sol-20261001/larger-axis-reference-timing.json").write_text(json.dumps(row,indent=2)+"\n");print(json.dumps(row),flush=True)
