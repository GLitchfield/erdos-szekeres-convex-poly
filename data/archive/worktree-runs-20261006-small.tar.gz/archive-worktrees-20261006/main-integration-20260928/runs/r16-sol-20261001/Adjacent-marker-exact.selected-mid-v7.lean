  have hTopFilter (ρ : Context) (v : Side) (top : ℕ) (htop : 1 ≤ top) :
      ρ.levelsOn v top = (ρ.levelsOn v 0).filter (· < top) := by
    simp only [levelsOn, List.filter_filter]
    apply List.filter_congr
    intro j _
    simp [show top ≠ 0 by omega]
  have hLevelsAtTop (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (top : ℕ) (htop : 1 ≤ top) (htL : top ≤ L) :
      (norm ρ L).levelsOn (ρ.sideAt L) top = ρ.levelsOn (ρ.sideAt L) top := by
    rw [hTopFilter (norm ρ L) (ρ.sideAt L) top htop, hNormOwnLevels ρ L hL ht,
      hTopFilter ρ (ρ.sideAt L) top htop, hSourcePairLevels ρ L hL ht,
      List.filter_append, List.filter_append]
    simp [show ¬ L < top by omega, show ¬ L + 1 < top by omega]
  have hMidLevels (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1) :
      ρ.levelsOn (ρ.sideAt L) (L + 1) = ρ.levelsOn (ρ.sideAt L) L ++ [L] := by
    rw [hTopFilter ρ (ρ.sideAt L) (L + 1) (by omega),
      hSourcePairLevels ρ L hL ht, List.filter_append]
    have hf : (ρ.levelsOn (ρ.sideAt L) L).filter (· < L + 1) =
        ρ.levelsOn (ρ.sideAt L) L := by
      apply List.filter_eq_self.mpr
      intro j hj
      apply decide_eq_true
      have hc : ρ.sideAt j = ρ.sideAt L ∧ (L = 0 ∨ j < L) :=
        of_decide_eq_true (List.mem_filter.mp hj).2
      omega
    rw [hf]
    simp
  have hYoungLeftTop (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (top : ℕ) (htop : 1 ≤ top) (htL : top ≤ L) (p : ℕ) :
      (norm ρ L).leftExt (ρ.sideAt L) top p = ρ.leftExt (ρ.sideAt L) top p := by
    rw [leftExt_eq, leftExt_eq, hLevelsAtTop ρ L hL ht top htop htL]
    apply congrArg (fun vals : List ℕ => vals.max?.getD 0)
    apply List.map_congr_left
    intro ls hls
    have hs : ls ∈ (ρ.levelsOn (ρ.sideAt L) L).sublists :=
      List.mem_sublists.mpr ((List.mem_sublists.mp hls).trans
        (levelsOn_sublist_of_le ρ (ρ.sideAt L) htop htL))
    exact congrArg Prod.snd (hYoungFoldLeft ρ L hL ls hs (p,0))
  have hYoungRightTop (ρ : Context) (L : ℕ) (hL : Inv ρ L)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (top : ℕ) (htop : 1 ≤ top) (htL : top ≤ L) (p : ℕ) :
      (norm ρ L).rightExt (ρ.sideAt L) top p = ρ.rightExt (ρ.sideAt L) top p := by
    rw [rightExt_eq, rightExt_eq, hLevelsAtTop ρ L hL ht top htop htL]
    apply congrArg (fun vals : List ℕ => vals.max?.getD 0)
    apply List.map_congr_left
    intro ls hls
    have hs : ls ∈ (ρ.levelsOn (ρ.sideAt L) L).sublists :=
      List.mem_sublists.mpr ((List.mem_sublists.mp hls).trans
        (levelsOn_sublist_of_le ρ (ρ.sideAt L) htop htL))
    exact congrArg Prod.snd (hYoungFoldRight ρ L hL ls hs (p,0))
  have hMidLeft (ρ : Context) (L x : ℕ) (hL : Inv ρ L)
      (hsingle : ρ.extPositions L = [x])
      (hc : ∀ p ∈ ρ.childPositions, x < p)
      (hy : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) L, ∀ p ∈ ρ.extPositions j, x < p)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (p : ℕ) (hp : p ∈ ρ.childPositions) :
      ρ.leftExt (ρ.sideAt L) (L + 1) p = ρ.leftExt (ρ.sideAt L) L p + 1 := by
    let Y := ρ.levelsOn (ρ.sideAt L) L
    have hx : x ∈ ρ.extPositions L := by simp [hsingle]
    have hAdd (ys : List ℕ) (hys : ys ∈ Y.sublists) :
        ((ys ++ [L]).foldl (leftStep ρ) (p,0)).2 =
          (ys.foldl (leftStep ρ) (p,0)).2 + 1 := by
      let z := ys.foldl (leftStep ρ) (p,0)
      have hz := (hFoldBoundary ρ x false ys
        (fun j hj y hiy => hy j ((List.mem_sublists.mp hys).subset hj) y hiy)
        (p,0) (hc p hp)).1
      change x < z.1 at hz
      rw [List.foldl_append]
      change (leftStep ρ z L).2 = z.2 + 1
      exact hLeftStepAdd ρ L z.1 z.2 ⟨x, hx, hz⟩
    have hLe (ys : List ℕ) (hys : ys ∈ Y.sublists) :
        (ys.foldl (leftStep ρ) (p,0)).2 + 1 ≤
          ρ.leftExt (ρ.sideAt L) (L + 1) p := by
      have hsub : ys ++ [L] ∈ (ρ.levelsOn (ρ.sideAt L) 0).sublists := by
        rw [hMidLevels ρ L hL ht]
        exact List.mem_sublists.mpr ((List.mem_sublists.mp hys).append (List.Sublist.refl _))
      have hh : ((ys ++ [L]).foldl (leftStep ρ) (p,0)).2 ≤
          ρ.leftExt (ρ.sideAt L) (L + 1) p := by
        rw [leftExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys ++ [L], hsub, rfl⟩)
      rwa [hAdd ys hys] at hh
    apply le_antisymm
    · rw [leftExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ls, hls, rfl⟩ := List.mem_map.mp hz
      rw [hMidLevels ρ L hL ht] at hls
      obtain ⟨ys, hys, ts, hts, rfl⟩ := hDecomposeSublists Y [L] ls hls
      have hcount := hFoldCountLeft ρ ts
        (ys.foldl (leftStep ρ) (p,0))
      have hlen : ts.length ≤ 1 := by
        simpa using (List.mem_sublists.mp hts).length_le
      have hprefix : (ys.foldl (leftStep ρ) (p,0)).2 ≤
          ρ.leftExt (ρ.sideAt L) L p := by
        rw [leftExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys, hys, rfl⟩)
      rw [List.foldl_append]
      omega
    · have h1 : 1 ≤ ρ.leftExt (ρ.sideAt L) (L + 1) p := by
        simpa using hLe [] (List.mem_sublists.mpr (List.nil_sublist _))
      have hyoung : ρ.leftExt (ρ.sideAt L) L p ≤
          ρ.leftExt (ρ.sideAt L) (L + 1) p - 1 := by
        rw [leftExt_eq]
        apply getD_max?_le
        intro z hz
        obtain ⟨ys, hys, rfl⟩ := List.mem_map.mp hz
        have hh := hLe ys hys
        omega
      omega
  have hMidRight (ρ : Context) (L x : ℕ) (hL : Inv ρ L)
      (hsingle : ρ.extPositions L = [x])
      (hc : ∀ p ∈ ρ.childPositions, x < p)
      (hy : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) L, ∀ p ∈ ρ.extPositions j, x < p)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (p : ℕ) (hp : p ∈ ρ.childPositions) :
      ρ.rightExt (ρ.sideAt L) (L + 1) p = ρ.rightExt (ρ.sideAt L) L p := by
    let Y := ρ.levelsOn (ρ.sideAt L) L
    apply le_antisymm
    · rw [rightExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ls, hls, rfl⟩ := List.mem_map.mp hz
      rw [hMidLevels ρ L hL ht] at hls
      obtain ⟨ys, hys, ts, hts, rfl⟩ := hDecomposeSublists Y [L] ls hls
      have hz := (hFoldBoundary ρ x false ys
        (fun j hj y hiy => hy j ((List.mem_sublists.mp hys).subset hj) y hiy)
        (p,0) (hc p hp)).2
      change x < (ys.foldl (rightStep ρ) (p,0)).1 at hz
      have hcases : ts = [] ∨ ts = [L] := by simpa [List.sublists_cons] using hts
      have hprefix : (ys.foldl (rightStep ρ) (p,0)).2 ≤
          ρ.rightExt (ρ.sideAt L) L p := by
        rw [rightExt_eq]
        exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys, hys, rfl⟩)
      rcases hcases with rfl | rfl
      · simpa only [List.append_nil] using hprefix
      · rw [List.foldl_append]
        change (rightStep ρ (ys.foldl (rightStep ρ) (p,0)) L).2 ≤ _
        rw [hNewRightStep ρ L x hsingle _ hz]
        exact hprefix
    · rw [rightExt_eq]
      apply getD_max?_le
      intro z hz
      obtain ⟨ys, hys, rfl⟩ := List.mem_map.mp hz
      have hsub : ys ∈ (ρ.levelsOn (ρ.sideAt L) (L + 1)).sublists := by
        rw [hMidLevels ρ L hL ht]
        exact List.mem_sublists.mpr (by
          simpa only [List.append_nil] using
            ((List.mem_sublists.mp hys).append (List.nil_sublist [L])))
      rw [rightExt_eq]
      exact le_getD_max?_of_mem (List.mem_map.mpr ⟨ys, hsub, rfl⟩)
  have hOwnChain (ρ : Context) (L x : ℕ) (hL : Inv ρ L)
      (hsingle : ρ.extPositions L = [x])
      (hbefore : ∃ y ∈ ρ.extPositions (L + 1), y < x)
      (hc : ∀ p ∈ ρ.childPositions, x < p)
      (hy : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) L, ∀ p ∈ ρ.extPositions j, x < p)
      (ht : ∀ j ∈ ρ.levelsOn (ρ.sideAt L) 0, j ≤ L + 1)
      (p q : ℕ) (hp : p ∈ ρ.childPositions) (hq : q ∈ ρ.childPositions) :
      ρ.chainExt (ρ.sideAt L) p q = (norm ρ L).chainExt (ρ.sideAt L) p q + 1 := by
    have hl := hSourceLeft ρ L x hL hsingle hbefore hc hy ht p hp
    have hn := hNormLeft ρ L x hL hsingle hc hy ht p hp
    have hr := hOwnRight ρ L x hL hsingle hc hy ht q hq
    unfold chainExt
    omega
