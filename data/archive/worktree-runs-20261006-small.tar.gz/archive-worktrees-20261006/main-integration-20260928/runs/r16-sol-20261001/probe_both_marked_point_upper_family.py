#!/usr/bin/env python3
"""Extra upper direction on the existing R16 four-child both-marked domains."""
from pathlib import Path
import hashlib
import itertools
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from harness.research.context_bound import compiled_evaluator
from probe_boundary_normalization import root_words
from point_base_candidate import both_marked_point_base_comparison

paths = [Path(__file__), Path(__file__).with_name("point_base_candidate.py"),
    Path(__file__).with_name("probe_boundary_normalization.py"),
    Path(__file__).with_name("N-ends.falsifier.py"),
    ROOT / "harness/research/context_bound.py", ROOT / "harness/research/context_bound.c",
    ROOT / "scripts/decomposable_depth2_tables.py",
    ROOT / "scripts/enumerate_decomposable_colorings.py"]
def hashes():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before = hashes()
words = [w for w in root_words(4, 2, 4) if w[0] != "S" and w[-1] != "S"]
def eligible(a, u, w):
    return (a if w[0][1] == "lower" else u) >= 3
total = sum((k-2)*sum(eligible(a,u,w) for a,u in itertools.product(range(1,k+1),repeat=2)
    for w in words) for k in (5,6))
started = time.monotonic()
done = violations = 0
witnesses = []
per_k = {}
print(json.dumps({"done": 0, "total": total}), flush=True)
for k in (5,6):
    count = fails = 0
    for a,u in itertools.product(range(1,k+1), repeat=2):
        evaluate = compiled_evaluator(a,u,k,cache_size=200000,persistent=True)
        try:
            for m in range(1,k-1):
                for word in words:
                    if not eligible(a,u,word):
                        continue
                    row = {"a":a,"u":u,"k":k,"maxima":(m,),"word":word}
                    result = both_marked_point_base_comparison(evaluate,row,True)
                    fail = result["bound"] > result["largest_point_base"]
                    done += 1
                    count += 1
                    violations += fail
                    fails += fail
                    if fail and len(witnesses)<20:
                        witnesses.append({**row,**result})
                    if done%100==0 or done==total:
                        print(json.dumps({"done":done,"total":total,"violations":violations,
                            "seconds":time.monotonic()-started}),flush=True)
        finally:
            evaluate.close()
    per_k[str(k)] = {"roots":count,"violations":fails}
assert before == hashes(), "sources changed during diagnostic"
out = {"candidate":"both-marked root opposite global>=3: bound<=largest initial point base",
    "semantics":"context-bound-zero-children-c-v1; lean=True limits; explicit unit-axis rule",
    "complete":done==total,"done":done,"total":total,"violations":violations,
    "per_k":per_k,"witnesses":witnesses,"source_sha256":before,
    "seconds":time.monotonic()-started}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+"\n")
raise SystemExit(2 if violations else 0)
