"""R16 candidate normal forms; diagnostic, with no Lean equivalence claim."""
from harness.research.primitives import part, sole_opposite_normalize


def complement_normal_form(row, complementary_side, maximum):
    """Return the actual p=0 complement and its proposed one-level normal form.

    The root must start with S, have exactly one actual uniform side, and have
    one maximum. Opposite-side normalization requires its global >=2. The
    same-side merged maximum is allowed to exceed the root's legal k-2 bound.
    """
    word = tuple(row["word"])
    assert word[0] == "S" and len(row["maxima"]) == 1
    markers = [x for x in word if x != "S"]
    assert markers and all(x == (1, row["chosen"]) for x in markers)
    assert complementary_side in ("lower", "upper")
    assert 1 <= maximum <= row["k"] - 2
    positions = {p for p, x in enumerate(word) if x == "S"}
    actual = part(row, positions - {0}, complementary_side, maximum)
    if complementary_side == row["chosen"]:
        normalized = {**row, "word": ((1, complementary_side),) + word[1:],
            "maxima": (max(maximum, row["maxima"][0] + 1),)}
        return "same_axis_merge", actual, normalized
    field = "u" if complementary_side == "lower" else "a"
    if row[field] < 2:
        return None
    # Reuse the retained level erasure, then add the boundary decrement and
    # remove the sole now-unindexed endpoint letter. No interior marker moves.
    normalized = sole_opposite_normalize(actual)
    normalized[field] = min(normalized[field], row[field] - 1)
    normalized["word"] = normalized["word"][1:]
    return "opposite_axis_boundary", actual, normalized


def marked_first_child_same_axis_normal_form(row, maximum):
    """Same-axis first-child complement with old markers before and after.

    A candidate exact normal form only: the selected global decreases by one,
    the first child becomes an old-axis marker, and the two maxima merge with
    the extra younger-marker extension of the older maximum.
    """
    word = tuple(row["word"])
    side = row["chosen"]
    assert word[0] != "S" and word[-1] != "S"
    assert len(row["maxima"]) == 1
    assert all(x == "S" or x == (1, side) for x in word)
    assert 1 <= maximum <= row["k"] - 2
    positions = {p for p, x in enumerate(word) if x == "S"}
    first = min(positions)
    actual = part(row, positions - {first}, side, maximum)
    normalized = {**row, "word": tuple(
        (1, side) if p == first else x for p, x in enumerate(word)),
        "maxima": (max(maximum, row["maxima"][0] + 1),)}
    field = "u" if side == "lower" else "a"
    assert 1 <= row[field] <= row["k"]
    normalized[field] = row[field] - 1
    return "marked_first_same_axis_merge", actual, normalized
