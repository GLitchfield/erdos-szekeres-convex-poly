  have hEraseLetter (ρ : Context) (p i : ℕ) :
      ({ ρ with word := ρ.word.eraseIdx p } : Context).letterAt i =
        ρ.letterAt (up p i) := by
    simp only [letterAt, List.getElem?_eraseIdx, up]
    split <;> rfl
  have hPartErase : ∀ (ρ : Context) p keep s m, p < ρ.word.length →
      let small : Context := { ρ with word := ρ.word.eraseIdx p }
      let kept := (List.range small.word.length).filter (fun i ↦ up p i ∈ keep)
      (small.part kept s m).word = (ρ.part keep s m).word.eraseIdx p := by
    intro ρ p keep s m hp
    dsimp only
    let small : Context := { ρ with word := ρ.word.eraseIdx p }
    let kept := (List.range small.word.length).filter (fun i ↦ up p i ∈ keep)
    let π := ρ.part keep s m
    change (small.part kept s m).word = π.word.eraseIdx p
    apply List.ext_getElem
    · rw [part_word_length, List.length_eraseIdx_of_lt]
      · exact List.length_eraseIdx_of_lt hp
      · simpa only [π, part_word_length] using hp
    · intro i hi hj
      have hi' : i < small.word.length := by simpa only [part_word_length] using hi
      have hlen : small.word.length = ρ.word.length - 1 := List.length_eraseIdx_of_lt hp
      have hup' : up p i < ρ.word.length := by
        dsimp [up]
        split_ifs <;> omega
      have hk : i ∈ kept ↔ up p i ∈ keep := by simp [kept, hi']
      have hletter : (small.part kept s m).letterAt i =
          ({ π with word := π.word.eraseIdx p } : Context).letterAt i := by
        rw [hEraseLetter]
        cases he : ρ.letterAt (up p i) with
        | child =>
          rw [part_letterAt_of_child small kept s m hi'
            ((hEraseLetter ρ p i).trans he), part_letterAt_of_child ρ keep s m hup' he]
          simp only [hk]
        | ext lev side =>
          rw [part_letterAt_of_ext small kept s m hi'
            ((hEraseLetter ρ p i).trans he), part_letterAt_of_ext ρ keep s m hup' he]
      simpa only [letterAt, List.getElem?_eq_getElem hi,
        List.getElem?_eq_getElem hj, Option.getD_some] using hletter
  have hNormalizePart : ∀ (ρ : Context) b N,
      ρ.childPositions = List.range' b N →
      (∀ p lev side, ρ.letterAt p = Letter.ext lev side → 1 ≤ lev) →
      ∀ keep s m,
      (ρ.part keep s m).bound =
        ({ a := ρ.capLimit b b + 1, u := ρ.cupLimit b b + 1, k := ρ.k,
          word := (ρ.part keep s m).word, maxima := [m] } : Context).bound := by
    intro ρ b N hpos hpositive keep s m
    let π := ρ.part keep s m
    have hhist : π.a = ρ.a ∧ π.u = ρ.u ∧ π.k = ρ.k ∧
        π.maxima.length = 1 + ρ.maxima.length ∧
        (∀ l, 1 ≤ l → π.extPositions (l + 1) = ρ.extPositions l) ∧
        (∀ l, 1 ≤ l → π.sideAt (l + 1) = ρ.sideAt l) ∧
        (∀ l, 1 ≤ l → π.maximumAt (l + 1) = ρ.maximumAt l) := by
      refine ⟨rfl, rfl, rfl, ?_, ?_, ?_, ?_⟩
      · simp [π, part_maxima, Nat.add_comm]
      · exact fun l hl ↦ part_extPositions_succ ρ keep s m hl
      · exact fun l hl ↦ part_sideAt_succ ρ keep s m hl
      · exact fun l hl ↦ part_maximumAt_succ ρ keep s m hl
    have hnew : ∀ l x, 1 ≤ l → l ≤ 1 → x ∈ π.extPositions l →
        x ∈ ρ.childPositions := by
      intro l x hl hl1 hx
      have : l = 1 := by omega
      subst l
      rw [part_extPositions_one hpositive keep s m] at hx
      exact (List.mem_filter.1 hx).1
    have hchild : ∀ x ∈ π.childPositions, x ∈ ρ.childPositions := by
      intro x hx
      rw [part_childPositions] at hx
      exact (List.mem_filter.1 hx).1
    have hposπ : ∀ x lev side, π.letterAt x = Letter.ext lev side → 1 ≤ lev := by
      intro x lev side hx
      have hxl : x < ρ.word.length := by
        by_contra h
        have hn := letterAt_of_length_le π
          (show π.word.length ≤ x by rw [part_word_length]; omega)
        rw [hn] at hx
        cases hx
      cases he : ρ.letterAt x with
      | child =>
        rw [part_letterAt_of_child ρ keep s m hxl he] at hx
        split at hx
        · cases hx
        · cases hx
          omega
      | ext oldLevel oldSide =>
        rw [part_letterAt_of_ext ρ keep s m hxl he] at hx
        cases hx
        omega
    exact (ctx_single_run_descendant_bound_normalize ρ b N hpos π 1 hhist hnew hchild
      hposπ).2
  have hEraseMiddle (L T R : List Letter) (p : ℕ)
      (hpL : L.length ≤ p) (hpT : p - L.length < T.length) :
      (L ++ T ++ R).eraseIdx p = L ++ T.eraseIdx (p - L.length) ++ R := by
    rw [List.append_assoc, List.eraseIdx_append_of_length_le hpL,
      List.eraseIdx_append_of_lt_length hpT]
    exact List.append_assoc .. |>.symm
  let π := σ.part keep s m
  let p := left.length
  have hπp : π.letterAt p = Letter.child := by
    simp [π, p, letterAt, hword, List.getElem?_append_right]
  have hπp1 : π.letterAt (p + 1) = Letter.child := by
    simp [π, p, letterAt, hword, List.getElem?_append_right]
  have hp1 : p + 1 < σ.word.length := by
    have hlen : σ.word.length = left.length + 2 + right.length := by
      rw [← part_word_length σ keep s m, hword]
      simp
    dsimp [p]
    omega
  have hpmem : p ∈ σ.childPositions := by
    have hh : p ∈ π.childPositions := by
      simp only [childPositions, List.mem_filter, List.mem_range, decide_eq_true_eq]
      exact ⟨by simpa only [π, part_word_length] using (show p < σ.word.length by omega),
        hπp⟩
    rw [part_childPositions] at hh
    exact (List.mem_filter.1 hh).1
  have hp1mem : p + 1 ∈ σ.childPositions := by
    have hh : p + 1 ∈ π.childPositions := by
      simp only [childPositions, List.mem_filter, List.mem_range, decide_eq_true_eq]
      exact ⟨by simpa only [π, part_word_length] using hp1, hπp1⟩
    rw [part_childPositions] at hh
    exact (List.mem_filter.1 hh).1
  have hne : σ.childPositions ≠ [] := by intro hn; simp [hn] at hpmem
  obtain ⟨b, hpos⟩ := hInterval σ hruns hne
  let N := σ.childPositions.length
  have hpb : b ≤ p ∧ p < b + N := by simpa only [hpos, List.mem_range'_1] using hpmem
  have hp1b : b ≤ p + 1 ∧ p + 1 < b + N := by
    simpa only [hpos, List.mem_range'_1] using hp1mem
  have hN : 2 ≤ N := by omega
  obtain ⟨L, R, hLb, hσword, hout⟩ := hReconstruct σ b N (by omega) hpos
  let small : Context := { σ with word := σ.word.eraseIdx p }
  let kept := (List.range small.word.length).filter (fun i ↦ up p i ∈ keep)
  let π' := small.part kept s m
  have hsmallword : small.word = L ++ List.replicate (N - 1) Letter.child ++ R := by
    change σ.word.eraseIdx p = _
    rw [hσword, hEraseMiddle L (List.replicate N Letter.child) R p
      (by omega) (by simp; omega), List.eraseIdx_replicate, if_pos (by omega)]
  have hsmallpos : small.childPositions = List.range' b (N - 1) := by
    rw [← hLb]
    exact hPositions small L R (N - 1) hout hsmallword
  have hpositive : ∀ q lev side, σ.letterAt q = Letter.ext lev side → 1 ≤ lev :=
    fun q lev side h ↦ (hwf.2.2.2.2.2 q lev side h).1
  have hsmallpositive : ∀ q lev side,
      small.letterAt q = Letter.ext lev side → 1 ≤ lev := by
    intro q lev side h
    exact hpositive (up p q) lev side ((hEraseLetter σ p q).symm.trans h)
  have hσp : σ.letterAt p = Letter.child := of_decide_eq_true (List.mem_filter.1 hpmem).2
  have hlen : σ.word.length = small.word.length + 1 := by
    have he := List.length_eraseIdx_of_lt (show p < σ.word.length by omega)
    change σ.word.length = (σ.word.eraseIdx p).length + 1
    omega
  have hpc : p ≤ small.word.length := by omega
  have hletter : ∀ i, i < small.word.length → σ.letterAt (up p i) = small.letterAt i :=
    fun i _ ↦ (hEraseLetter σ p i).symm
  have hb : b ∈ σ.childPositions := by rw [hpos, List.mem_range'_1]; omega
  have hbb : up p b ∈ σ.childPositions := by
    rw [hpos, List.mem_range'_1]
    dsimp [up]
    split_ifs <;> omega
  have hconstant := ctx_point_limits_eq_of_child_interval σ b (up p b) hb hbb
    (by dsimp [up]; split_ifs <;> omega) (by
      intro r hbr hrb
      rw [hpos, List.mem_range'_1]
      dsimp [up] at hrb
      split_ifs at hrb <;> omega)
  have hdeleted := hDeletePoint σ small p rfl rfl rfl rfl hlen hpc hσp hletter b
  have hcup : σ.cupLimit b b = small.cupLimit b b := hconstant.1.trans hdeleted.1
  have hcap : σ.capLimit b b = small.capLimit b b := hconstant.2.trans hdeleted.2
  let T := (List.range N).map (fun i ↦ if i + L.length ∈ keep then Letter.child
    else Letter.ext 1 s)
  have hTlen : T.length = N := by simp [T]
  have hπword : π.word = L.map shift ++ T ++ R.map shift :=
    hPartWord σ L R N keep s m hout hσword
  have hπ'word : π'.word = L.map shift ++ T.eraseIdx (p - b) ++ R.map shift := by
    rw [hPartErase σ p keep s m (by omega), hπword]
    rw [hEraseMiddle (L.map shift) T (R.map shift) p (by simp; omega)
      (by simp; omega)]
    simpa only [List.length_map, hLb]
  have hπ'contract : π'.word = left ++ [Letter.child] ++ right := by
    rw [hPartErase σ p keep s m (by omega), hword]
    simp only [List.append_assoc]
    rw [List.eraseIdx_append_of_length_le (show left.length ≤ p from le_rfl)]
    simp [p]
  have hNorm := hNormalizePart σ b N hpos hpositive keep s m
  have hNorm' := hNormalizePart small b (N - 1) hsmallpos hsmallpositive kept s m
  let τ : Context := { a := σ.capLimit b b + 1, u := σ.cupLimit b b + 1,
    k := σ.k, word := π.word, maxima := [m] }
  let τ' : Context := { τ with word := π'.word }
  have hnorm : π.bound = τ.bound := hNorm
  have hnorm' : π'.bound = τ'.bound := by
    simpa only [← hcup, ← hcap] using hNorm'
  have hinert : ∀ x ∈ L.map shift ++ R.map shift,
      ∃ lev side, x = Letter.ext lev side ∧ τ.maxima.length < lev := by
    intro x hx
    rw [← List.map_append] at hx
    obtain ⟨y, hy, rfl⟩ := List.mem_map.1 hx
    have hyword : y ∈ σ.word := by
      rw [hσword]
      rcases List.mem_append.1 hy with hy | hy
      · exact List.mem_append_left _ (List.mem_append_left _ hy)
      · exact List.mem_append_right _ hy
    cases he : y with
    | child => exact (hout _ hy he).elim
    | ext lev side =>
      obtain ⟨q, hq⟩ := List.mem_iff_getElem?.1 hyword
      have hlev := hpositive q lev side (by simp [letterAt, hq])
      exact ⟨lev + 1, side, rfl, by simp [τ]; omega⟩
  have hstrip := hStrip τ (L.map shift) T (R.map shift) hπword hinert
  have hstrip' := hStrip τ' (L.map shift) (T.eraseIdx (p - b)) (R.map shift) hπ'word
    hinert
  let active : Letter → Bool
    | .child => true
    | .ext lev _ => decide (lev = 1)
  have hTletters : ∀ x ∈ T, x = Letter.child ∨ x = Letter.ext 1 s := by
    intro x hx
    obtain ⟨i, hi, rfl⟩ := List.mem_map.1 hx
    split <;> simp
  have hTfilter : T.filter active = T := by
    apply List.filter_eq_self.2
    intro x hx
    rcases hTletters x hx with rfl | rfl <;> rfl
  have houterfilter : (L.map shift).filter active = [] ∧
      (R.map shift).filter active = [] := by
    constructor <;> apply List.filter_eq_nil_iff.2 <;> intro x hx
    · obtain ⟨lev, side, rfl, hlev⟩ := hinert x (List.mem_append_left _ hx)
      have hn : lev ≠ 1 := by simp only [τ, List.length_singleton] at hlev; omega
      simp [active, hn]
    · obtain ⟨lev, side, rfl, hlev⟩ := hinert x (List.mem_append_right _ hx)
      have hn : lev ≠ 1 := by simp only [τ, List.length_singleton] at hlev; omega
      simp [active, hn]
  have hT'filter : (T.eraseIdx (p - b)).filter active = T.eraseIdx (p - b) := by
    apply List.filter_eq_self.2
    intro x hx
    rcases hTletters x (List.mem_of_mem_eraseIdx hx) with rfl | rfl <;> rfl
  have hfiltered : left.filter active ++ [Letter.child, Letter.child] ++
      right.filter active = T := by
    have hh := congrArg (List.filter active) hword
    rw [hπword, List.filter_append, List.filter_append, houterfilter.1,
      houterfilter.2, hTfilter] at hh
    simpa [List.filter_append, active] using hh.symm
  have hfiltered' : left.filter active ++ [Letter.child] ++ right.filter active =
      T.eraseIdx (p - b) := by
    have hh := congrArg (List.filter active) hπ'contract
    rw [hπ'word, List.filter_append, List.filter_append, houterfilter.1,
      houterfilter.2, hT'filter] at hh
    simpa [List.filter_append, active] using hh.symm
  have hallowed : ∀ x ∈ left.filter active ++ right.filter active,
      x = Letter.child ∨ x = Letter.ext 1 s := by
    intro x hx
    apply hTletters x
    rw [← hfiltered]
    rcases List.mem_append.1 hx with hx | hx
    · exact List.mem_append_left _ (List.mem_append_left _ hx)
    · exact List.mem_append_right _ hx
  have hk : 3 ≤ σ.k := by omega
  have ha : σ.capLimit b b + 1 ≤ σ.k := by
    have hh : σ.capLimit b b ≤ σ.k - 1 :=
      (Nat.min_le_right _ _).trans (Nat.sub_le ..)
    omega
  have hu : σ.cupLimit b b + 1 ≤ σ.k := by
    have hh : σ.cupLimit b b ≤ σ.k - 1 :=
      (Nat.min_le_right _ _).trans (Nat.sub_le ..)
    omega
  have hc := hroot (σ.capLimit b b + 1) (σ.cupLimit b b + 1) σ.k m hk
    (by omega) ha (by omega) hu hm hmk s (left.filter active) (right.filter active)
    hallowed
  rw [hfiltered, hfiltered'] at hc
  have heq : ({ π with word := left ++ [Letter.child] ++ right } : Context) = π' :=
    hCtxEq _ _ rfl rfl rfl hπ'contract.symm rfl
  calc
    π.bound = τ.bound := hnorm
    _ = ({ τ with word := T } : Context).bound := hstrip
    _ = ({ τ' with word := T.eraseIdx (p - b) } : Context).bound := hc
    _ = τ'.bound := hstrip'.symm
    _ = π'.bound := hnorm'.symm
    _ = ({ π with word := left ++ [Letter.child] ++ right } : Context).bound :=
      congrArg Context.bound heq.symm
