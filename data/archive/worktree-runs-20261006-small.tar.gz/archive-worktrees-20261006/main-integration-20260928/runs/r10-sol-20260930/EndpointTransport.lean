import ESBlueprint.B.CtxSingleRunDescendantBoundNormalize

set_option maxHeartbeats 8000000
set_option maxRecDepth 10000

namespace ErdosSzekeres
open Ctx Ctx.Context

example : ∀ (big small : Context) p level s,
    big.a = small.a → big.u = small.u → big.k = small.k → big.maxima = small.maxima →
    small.maxima.length < level →
    big.word.length = small.word.length + 1 → p ≤ small.word.length →
    big.letterAt p = Letter.ext level s →
    (∀ i, i < small.word.length →
      big.letterAt (if i < p then i else i + 1) = small.letterAt i) →
    (p = 0 ∨ p = small.word.length) →
    (∀ fuel, boundFuel fuel big = boundFuel fuel small) ∧ big.bound = small.bound := by
  classical
  let up (p i : ℕ) := if i < p then i else i + 1
  have hup : ∀ p, StrictMono (up p) := by
    intro p i j hij
    dsimp [up]
    split_ifs <;> omega
  have hRange : ∀ n p, p ≤ n →
      (List.range (n + 1)).filter (fun i ↦ i ≠ p) = (List.range n).map (up p) := by
    intro n
    induction n with
    | zero =>
      intro p hp
      have : p = 0 := by omega
      subst p
      simp
    | succ n ih =>
      intro p hp
      by_cases hpn : p = n + 1
      · subst p
        have hpre : (List.range (n + 1)).map (up (n + 1)) = List.range (n + 1) := by
          calc
            _ = (List.range (n + 1)).map (fun i ↦ i) := by
              apply List.map_congr_left
              intro i hi
              simp [up, List.mem_range.1 hi]
            _ = _ := List.map_id' _
        rw [List.range_succ, List.filter_append]
        have hself : (List.range (n + 1)).filter (fun i ↦ i ≠ n + 1) =
            List.range (n + 1) := by
          apply List.filter_eq_self.2
          intro i hi
          simp only [decide_eq_true_eq]
          exact Nat.ne_of_lt (List.mem_range.1 hi)
        rw [hself, hpre]
        simp
      · have hpn' : p ≤ n := by omega
        rw [List.range_succ, List.filter_append, ih p hpn', List.range_succ,
          List.map_append]
        have hnp : n + 1 ≠ p := by omega
        have hnp' : ¬ n < p := by omega
        simp [up, hnp, hnp']
  have hFilter : ∀ n p (P Q : ℕ → Bool), p ≤ n → P p = false →
      (∀ i, i < n → P (up p i) = Q i) →
      (List.range (n + 1)).filter P = ((List.range n).filter Q).map (up p) := by
    intro n p P Q hp hfalse hletter
    have hremove : (List.range (n + 1)).filter P =
        ((List.range (n + 1)).filter (fun i ↦ i ≠ p)).filter P := by
      rw [List.filter_filter]
      apply List.filter_congr
      intro i hi
      by_cases hip : i = p
      · subst i; simp [hfalse]
      · simp [hip]
    rw [hremove, hRange n p hp, List.filter_map]
    congr 1
    apply List.filter_congr
    intro i hi
    exact hletter i (List.mem_range.1 hi)
  have hGeometry : ∀ (big small : Context) p level s,
      big.maxima = small.maxima → small.maxima.length < level →
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      big.childPositions = small.childPositions.map (up p) ∧
      (∀ N ∈ small.levels, big.extPositions N = (small.extPositions N).map (up p)) ∧
      (∀ N ∈ small.levels, big.sideAt N = small.sideAt N) := by
    intro big small p level s hm hlevel hlen hp hbp hletter
    have hchildren : big.childPositions = small.childPositions.map (up p) := by
      unfold childPositions
      rw [hlen]
      apply hFilter _ p _ _ hp
      · simp [hbp]
      · intro i hi; rw [hletter i hi]
    have hexternals : ∀ N ∈ small.levels,
        big.extPositions N = (small.extPositions N).map (up p) := by
      intro N hN
      have hNle : N ≤ small.maxima.length := by
        obtain ⟨j, hj, rfl⟩ := List.mem_map.1 hN
        have := List.mem_range.1 hj
        omega
      have hne : level ≠ N := by omega
      unfold extPositions
      rw [hlen]
      apply hFilter _ p _ _ hp
      · simp [hbp, hne]
      · intro i hi; rw [hletter i hi]
    refine ⟨hchildren, hexternals, ?_⟩
    intro N hN
    unfold sideAt
    rw [hexternals N hN, List.head?_map]
    cases hh : (small.extPositions N).head? with
    | none => rfl
    | some q =>
      simp only [Option.map_some]
      have hqn : q < small.word.length :=
        List.mem_range.1 (List.mem_filter.1 (List.mem_of_mem_head? hh)).1
      rw [hletter q hqn]
  have hFolds : ∀ (big small : Context) p,
      (∀ N ∈ small.levels, big.extPositions N = (small.extPositions N).map (up p)) →
      ∀ (ls : List ℕ), (∀ N ∈ ls, N ∈ small.levels) → ∀ e c,
      (ls.foldl (leftStep big) (up p e, c)).2 =
          (ls.foldl (leftStep small) (e, c)).2 ∧
      (ls.foldl (rightStep big) (up p e, c)).2 =
          (ls.foldl (rightStep small) (e, c)).2 := by
    intro big small p hext ls
    induction ls with
    | nil => intros; exact ⟨rfl, rfl⟩
    | cons N ls ih =>
      intro hlevels e c
      have hrest := fun j hj ↦ hlevels j (List.mem_cons_of_mem N hj)
      have hleft : ((big.extPositions N).filter (· < up p e)).getLast? =
          (((small.extPositions N).filter (· < e)).getLast?).map (up p) := by
        rw [hext N (hlevels N (List.mem_cons_self ..)), List.filter_map]
        have hf : (fun i ↦ decide (up p i < up p e)) = (fun i ↦ decide (i < e)) := by
          funext i
          simp only [(hup p).lt_iff_lt]
        simp only [Function.comp_def]
        rw [hf, List.getLast?_map]
      have hright : ((big.extPositions N).filter (up p e < ·)).head? =
          (((small.extPositions N).filter (e < ·)).head?).map (up p) := by
        rw [hext N (hlevels N (List.mem_cons_self ..)), List.filter_map]
        have hf : (fun i ↦ decide (up p e < up p i)) = (fun i ↦ decide (e < i)) := by
          funext i
          simp only [(hup p).lt_iff_lt]
        simp only [Function.comp_def]
        rw [hf, List.head?_map]
      constructor
      · simp only [List.foldl_cons, leftStep]
        rw [hleft]
        cases hq : ((small.extPositions N).filter (· < e)).getLast? with
        | none => simp only [Option.map_none]; exact (ih hrest e c).1
        | some q => simp only [Option.map_some]; exact (ih hrest q (c + 1)).1
      · simp only [List.foldl_cons, rightStep]
        rw [hright]
        cases hq : ((small.extPositions N).filter (e < ·)).head? with
        | none => simp only [Option.map_none]; exact (ih hrest e c).2
        | some q => simp only [Option.map_some]; exact (ih hrest q (c + 1)).2
  have hBase : ∀ (big small : Context) p level s,
      big.a = small.a → big.u = small.u → big.k = small.k → big.maxima = small.maxima →
      small.maxima.length < level →
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      big.base = small.base := by
    intro big small p level s ha hu hk hm hlevel hlen hp hbp hletter
    obtain ⟨hchildren, hexternals, hsides⟩ :=
      hGeometry big small p level s hm hlevel hlen hp hbp hletter
    have hlevels : ∀ s top, big.levelsOn s top = small.levelsOn s top := by
      intro t top
      unfold levelsOn levels
      rw [hm]
      apply List.filter_congr
      intro N hN
      rw [hsides N hN]
    have hExt : ∀ s top e,
        big.leftExt s top (up p e) = small.leftExt s top e ∧
        big.rightExt s top (up p e) = small.rightExt s top e := by
      intro t top e
      have hmap : ∀ ls ∈ (small.levelsOn t top).sublists,
          (ls.foldl (leftStep big) (up p e, 0)).2 =
            (ls.foldl (leftStep small) (e, 0)).2 ∧
          (ls.foldl (rightStep big) (up p e, 0)).2 =
            (ls.foldl (rightStep small) (e, 0)).2 := by
        intro ls hls
        apply hFolds big small p hexternals ls
        intro N hN
        exact (List.mem_filter.1 ((List.mem_sublists.1 hls).subset hN)).1
      constructor
      · rw [leftExt_eq, leftExt_eq, hlevels]
        congr 2
        exact List.map_congr_left (fun ls hls ↦ (hmap ls hls).1)
      · rw [rightExt_eq, rightExt_eq, hlevels]
        congr 2
        exact List.map_congr_left (fun ls hls ↦ (hmap ls hls).2)
    have hchain : ∀ s e,
        big.chainExt s (up p e) (up p e) = small.chainExt s e e := by
      intro t e
      unfold chainExt
      rw [(hExt t 0 e).1, (hExt t 0 e).2]
    have hjoin : ∀ s e,
        big.joinExt s (up p e) (up p e) = small.joinExt s e e := by
      intro t e
      unfold joinExt
      rw [hchain t e, hlevels]
      congr 3
      apply List.map_congr_left
      intro N hN
      rw [(hExt t N e).1, (hExt t N e).2]
      simp [maximumAt, hm]
    unfold base
    rw [hchildren, List.head?_map]
    cases hh : small.childPositions.head? with
    | none => rfl
    | some e =>
      simp only [Option.map_some]
      have hcl : big.cupLimit (up p e) (up p e) = small.cupLimit e e := by
        unfold cupLimit
        rw [hu, hk, hchain, hjoin]
      have hpl : big.capLimit (up p e) (up p e) = small.capLimit e e := by
        unfold capLimit
        rw [ha, hk, hchain, hjoin]
      rw [hcl, hpl, hk]
  have hMapMem : ∀ p (A : List ℕ) i, up p i ∈ A.map (up p) ↔ i ∈ A := by
    intro p A i
    constructor
    · intro h
      obtain ⟨j, hj, heq⟩ := List.mem_map.1 h
      have hji := (hup p).injective heq
      simpa [hji] using hj
    · exact List.mem_map_of_mem
  have hRest : ∀ p (A B : List ℕ),
      (A.map (up p)).filter (fun i ↦ i ∉ B.map (up p)) =
        (A.filter (fun i ↦ i ∉ B)).map (up p) := by
    intro p A B
    rw [List.filter_map]
    congr 1
    apply List.filter_congr
    intro i hi
    change decide (up p i ∉ B.map (up p)) = decide (i ∉ B)
    simp only [hMapMem]
  have hBlocks : ∀ (big small : Context) p,
      big.childPositions = small.childPositions.map (up p) →
      big.blocks = small.blocks.map (fun B ↦ B.map (up p)) := by
    intro big small p hc
    simp only [blocks, hc, List.length_map]
    have hraw : ((List.range small.childPositions.length).flatMap fun i ↦
          (List.range (small.childPositions.length - i)).map fun len ↦
            ((small.childPositions.map (up p)).drop i).take (len + 1)) =
        ((List.range small.childPositions.length).flatMap fun i ↦
          (List.range (small.childPositions.length - i)).map fun len ↦
            (small.childPositions.drop i).take (len + 1)).map (fun B ↦ B.map (up p)) := by
      rw [List.map_flatMap]
      apply List.flatMap_congr
      intro i hi
      rw [List.map_map]
      apply List.map_congr_left
      intro len hlen
      simp [List.map_take, List.map_drop]
    rw [hraw, List.filter_map]
    congr 1
    apply List.filter_congr
    intro B hB
    simp
  have hRuns : ∀ (big small : Context) p level s,
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      (p = 0 ∨ p = small.word.length) → big.numRuns = small.numRuns := by
    intro big small p level s hlen hp hbp hletter hedge
    unfold numRuns
    rw [hlen]
    have hfilter := hFilter small.word.length p
      (fun i ↦ decide (big.letterAt i = Letter.child ∧
        (i = 0 ∨ big.letterAt (i - 1) ≠ Letter.child)))
      (fun i ↦ decide (small.letterAt i = Letter.child ∧
        (i = 0 ∨ small.letterAt (i - 1) ≠ Letter.child))) hp (by simp [hbp])
    have hmap : ∀ i, i < small.word.length →
        decide (big.letterAt (up p i) = Letter.child ∧
          (up p i = 0 ∨ big.letterAt (up p i - 1) ≠ Letter.child)) =
        decide (small.letterAt i = Letter.child ∧
          (i = 0 ∨ small.letterAt (i - 1) ≠ Letter.child)) := by
      intro i hi
      rw [hletter i hi]
      rcases hedge with rfl | rfl
      · have hu : up 0 i = i + 1 := by simp [up]
        rw [hu]
        by_cases hi0 : i = 0
        · subst i
          simp [hbp]
        · have hip : i - 1 < small.word.length := by omega
          have huprev : up 0 (i - 1) = i := by simp [up]; omega
          rw [show i + 1 - 1 = up 0 (i - 1) by omega, hletter _ hip]
          simp [hi0]
      · have hu : up small.word.length i = i := by simp [up, hi]
        rw [hu]
        by_cases hi0 : i = 0
        · simp [hi0]
        · have hip : i - 1 < small.word.length := by omega
          have huprev : up small.word.length (i - 1) = i - 1 := by simp [up, hip]
          conv_lhs => rw [← huprev, hletter _ hip]
    rw [hfilter hmap, List.length_map]
  have hFuel : ∀ fuel (big small : Context) p level s,
      big.a = small.a → big.u = small.u → big.k = small.k → big.maxima = small.maxima →
      small.maxima.length < level →
      big.word.length = small.word.length + 1 → p ≤ small.word.length →
      big.letterAt p = Letter.ext level s →
      (∀ i, i < small.word.length → big.letterAt (up p i) = small.letterAt i) →
      (p = 0 ∨ p = small.word.length) →
      boundFuel fuel big = boundFuel fuel small := by
    intro fuel
    induction fuel with
    | zero => intros; rfl
    | succ fuel ih =>
      intro big small p level s ha hu hk hm hlevel hlen hp hbp hletter hedge
      obtain ⟨hc, hext, hsides⟩ :=
        hGeometry big small p level s hm hlevel hlen hp hbp hletter
      have hparts : ∀ (B : List ℕ) (t : Side) m,
          boundFuel fuel (big.part (B.map (up p)) t m) =
            boundFuel fuel (small.part B t m) := by
        intro B t m
        have hpbig : p < big.word.length := by omega
        apply ih (big.part (B.map (up p)) t m) (small.part B t m) p (level + 1) s
        · exact ha
        · exact hu
        · exact hk
        · simp only [part_maxima, hm]
        · simp only [part_maxima, List.length_cons]
          omega
        · simpa only [part_word_length] using hlen
        · simpa only [part_word_length] using hp
        · exact part_letterAt_of_ext big (B.map (up p)) t m hpbig hbp
        · intro i hi
          have his : i < small.word.length := by simpa only [part_word_length] using hi
          have hib : up p i < big.word.length := by
            rw [hlen]
            dsimp [up]
            split_ifs <;> omega
          cases hs : small.letterAt i with
          | child =>
            rw [part_letterAt_of_child big (B.map (up p)) t m hib
              ((hletter i his).trans hs), part_letterAt_of_child small B t m his hs]
            simp only [hMapMem]
          | ext N t' =>
            rw [part_letterAt_of_ext big (B.map (up p)) t m hib
              ((hletter i his).trans hs), part_letterAt_of_ext small B t m his hs]
        · simpa only [part_word_length] using hedge
      have hruns := hRuns big small p level s hlen hp hbp hletter hedge
      simp only [boundFuel, hruns]
      split_ifs with hr
      · exact hBase big small p level s ha hu hk hm hlevel hlen hp hbp hletter
      · rw [hc, hBlocks big small p hc, hk, List.flatMap_map]
        apply congrArg (fun xs : List ℕ ↦ (xs.max?).getD 0)
        apply List.flatMap_congr
        intro B hB
        rw [hRest]
        apply List.flatMap_congr
        intro d hd
        simp only [hparts]
  intro big small p level s ha hu hk hm hlevel hlen hp hbp hletter hedge
  have hf := fun fuel ↦ hFuel fuel big small p level s ha hu hk hm hlevel hlen hp hbp
    hletter hedge
  refine ⟨hf, ?_⟩
  unfold bound
  rw [(hGeometry big small p level s hm hlevel hlen hp hbp hletter).1, List.length_map]
  exact hf _

end ErdosSzekeres
