"""Small R14 mathematical candidates; no execution, guards or result storage.

Proper blocks are exact nonempty child-order intervals other than the full
child set, as in Context.blocks. Zero-valued parts are retained.
"""
from harness.research.primitives import part


def children(row):
    return tuple(i for i, token in enumerate(row["word"]) if token == "S")


def proper_blocks(positions):
    for start in range(len(positions)):
        for stop in range(start + 1, len(positions) + 1):
            if start != 0 or stop != len(positions):
                yield positions[start:stop]


def cut_values(evaluate, row):
    positions = children(row)
    for block in proper_blocks(positions):
        rest = tuple(p for p in positions if p not in block)
        for side, opposite in (("lower", "upper"), ("upper", "lower")):
            for maximum in range(1, row["k"] - 1):
                left = part(row, block, side, maximum)
                right = part(row, rest, opposite, row["k"] - 1 - maximum)
                lv = evaluate(left["word"], left["maxima"])
                rv = evaluate(right["word"], right["maxima"])
                yield {"block": block, "rest": rest, "side": side,
                       "maximum": maximum, "left": left, "right": right,
                       "left_value": lv, "right_value": rv, "value": lv + rv}


def internal_shrink_records(evaluate, row):
    """Try all smaller blocks inside every attaining nontrivial outer block.

    This is a proposed sufficient lifting invariant, stronger than N_root.
    All root orientations/couplings and all internal positions are free.
    No selected leaf is fixed. Both outer parts must have >=2 children.
    """
    bound = evaluate(row["word"], row["maxima"])
    choices = tuple(cut_values(evaluate, row))
    for outer in choices:
        if outer["value"] != bound or min(len(outer["block"]), len(outer["rest"])) < 2:
            continue
        eligible = [cut for cut in choices if
            set(cut["block"]) < set(outer["block"])]
        best = max(eligible, key=lambda cut: cut["value"])
        yield {"outer": outer, "bound": bound, "best_internal": best,
               "passed": bound <= best["value"]}


def inner_split_record(evaluate, row):
    """Compare one part's actual bound with all its further proper cut sums."""
    bound = evaluate(row["word"], row["maxima"])
    choices = tuple(cut_values(evaluate, row))
    best = max(choices, key=lambda cut: cut["value"])
    return {"row": row, "bound": bound, "best_inner": best,
            "passed": bound <= best["value"]}


def three_piece_rotation_records(evaluate, row):
    """Existential rotation over ALL attaining inner cuts of a multi-run B.

    Isolate any one of the three whole pieces A, B-minus-A, R that is an
    original proper child-order interval. Reoptimize root side and coupling.
    This tests a sufficient local exchange, not the full singleton claim.
    Both unrestricted-size and strictly-smaller-than-B versions are reported.
    """
    bound = evaluate(row["word"], row["maxima"])
    choices = tuple(cut_values(evaluate, row))
    by_block = {}
    for cut in choices:
        key = tuple(cut["block"])
        if key not in by_block or by_block[key]["value"] < cut["value"]:
            by_block[key] = cut
    for outer in choices:
        block, rest = outer["block"], outer["rest"]
        if outer["value"] != bound or min(len(block), len(rest)) < 2:
            continue
        # Physical runs: retained positions are consecutive in the original word.
        if all(q == p + 1 for p, q in zip(block, block[1:])):
            continue
        inner = tuple(cut_values(evaluate, outer["left"]))
        attaining = [cut for cut in inner if cut["value"] == outer["left_value"]]
        if not attaining:
            raise ValueError("multi-run component had no attaining recurrence cut")
        pieces = {tuple(rest)}
        for cut in attaining:
            pieces.add(tuple(cut["block"]))
            pieces.add(tuple(cut["rest"]))
        rotated = [by_block[piece] for piece in pieces if piece in by_block]
        smaller = [cut for cut in rotated if len(cut["block"]) < len(block)]
        best = max(rotated, key=lambda cut: cut["value"], default=None)
        best_smaller = max(smaller, key=lambda cut: cut["value"], default=None)
        yield {"outer": outer, "bound": bound, "attaining_inner_cuts": attaining,
               "best_rotation": best, "best_smaller": best_smaller,
               "passed": best is not None and bound <= best["value"],
               "smaller_passed": best_smaller is not None and bound <= best_smaller["value"]}
