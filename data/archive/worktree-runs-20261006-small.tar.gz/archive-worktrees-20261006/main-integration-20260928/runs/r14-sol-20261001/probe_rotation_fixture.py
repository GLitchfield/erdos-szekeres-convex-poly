"""R14 finite fixture runner. Resource policy is owned by es job run."""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from harness.research.context_bound import compiled_evaluator
from harness.research.primitives import part
from harness.research.singleton_cuts import singleton_cut_values
from rotation_candidate import (internal_shrink_records, inner_split_record,
                                three_piece_rotation_records)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--spec", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    spec = json.loads(Path(args.spec).read_text())
    start = time.monotonic()
    records = []
    counts = Counter()
    for index, case in enumerate(spec["cases"]):
        row = case["row"]
        evaluate = compiled_evaluator(row["a"], row["u"], row["k"],
                                      cache_size=2_000_000, persistent=True)
        print(json.dumps({"stage": "start", "index": index, "total": len(spec["cases"]),
                          "name": case["name"], "elapsed": time.monotonic() - start}), flush=True)
        try:
            value = evaluate(row["word"], row["maxima"])
            singletons = singleton_cut_values(evaluate, row)
            internal = (list(internal_shrink_records(evaluate, row))
                        if case.get("internal_shrink", True) else [])
            counts["eligible_outer_cuts"] += len(internal)
            failed = [record for record in internal if not record["passed"]]
            counts["internal_shrink_failures"] += len(failed)
            rotations = (list(three_piece_rotation_records(evaluate, row))
                         if case.get("three_piece_rotations") else [])
            rotation_failed = [r for r in rotations if not r["passed"]]
            smaller_failed = [r for r in rotations if not r["smaller_passed"]]
            counts["eligible_rotation_cuts"] += len(rotations)
            counts["rotation_failures"] += len(rotation_failed)
            counts["smaller_rotation_failures"] += len(smaller_failed)
            components = []
            for component in case.get("components", []):
                child = part(row, component["keep"], component["side"], component["maximum"])
                result = inner_split_record(evaluate, child)
                components.append({"name": component["name"], **result})
                counts["inner_split_failures"] += not result["passed"]
            record = {"name": case["name"], "row": row, "bound": value,
                "best_singleton": max(singletons), "singleton_values": singletons,
                "eligible_outer_cuts": len(internal), "internal_failures": failed,
                "eligible_rotation_cuts": len(rotations),
                "rotation_failures": rotation_failed,
                "smaller_rotation_failures": smaller_failed,
                "component_splits": components}
            if (not spec.get("failures_only") or failed or rotation_failed or smaller_failed
                    or any(not result["passed"] for result in components)):
                if len(records) < spec.get("record_limit", len(spec["cases"])):
                    records.append(record)
        finally:
            evaluate.close()
        counts["rows"] += 1
        elapsed = time.monotonic() - start
        print(json.dumps({"done": index + 1, "total": len(spec["cases"]),
            "elapsed": elapsed, "rate": (index + 1) / elapsed, "counts": dict(counts)}), flush=True)
    Path(args.out).write_text(json.dumps({"semantics": "context-bound-zero-children-c-v1",
        "spec": spec, "complete": True, "counts": dict(counts), "records": records,
        "retained_records": len(records),
        "seconds": time.monotonic() - start}, indent=2) + "\n")
    # Candidate failures are mathematical diagnostics in the result, not runner failures.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
