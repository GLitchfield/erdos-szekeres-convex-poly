"""Replay already-found R14 witnesses with the shared Python recurrence.

No new candidate/family is searched. Guards and deadlines belong to es.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from harness.research.recursive import evaluator
from harness.research.singleton_cuts import singleton_cut_values
from rotation_candidate import cut_values, inner_split_record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=("first", "internal", "rotation"), required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent
    if args.source in ("first", "internal"):
        stored = json.loads((directory / "rotation-fixtures.result.json").read_text())
        record = stored["records"][0 if args.source == "first" else 1]
        row = record["row"]
    else:
        stored = json.loads((directory / "FAILED-ROTATION-WITNESS.json").read_text())
        record = stored
        row = stored["root"]
    start = time.monotonic()
    reference = evaluator(row["a"], row["u"], row["k"],
                          semantics="context-bound-zero-children-v1", cache_size=16000)
    def evaluate(word, maxima):
        word = tuple(token if token == "S" else tuple(token) for token in word)
        return reference(word, tuple(maxima))
    checks = []
    def check(name, actual, expected):
        checks.append({"name": name, "actual": actual, "expected": expected,
                       "passed": actual == expected})
        print(json.dumps({"done": len(checks), "name": name,
                          "elapsed": time.monotonic() - start,
                          "passed": actual == expected}), flush=True)
    check("root", evaluate(row["word"], row["maxima"]), record["bound"])
    actual_singletons = singleton_cut_values(evaluate, row)
    check("all_singleton_cut_values", sorted(actual_singletons),
          sorted(tuple(choice) for choice in record["singleton_values"]))
    if args.source == "first":
        component = record["component_splits"][0]
        replay = inner_split_record(evaluate, component["row"])
        check("single_run_component", replay["bound"], component["bound"])
        check("best_proper_component_cut", replay["best_inner"]["value"],
              component["best_inner"]["value"])
    elif args.source == "internal":
        failed = record["internal_failures"][0]
        outer = failed["outer"]
        for name in ("left", "right"):
            child = outer[name]
            check("outer_" + name, evaluate(child["word"], child["maxima"]),
                  outer[name + "_value"])
        choices = [cut for cut in cut_values(evaluate, row)
                   if set(cut["block"]) < set(outer["block"])]
        check("best_internal_rotation", max(cut["value"] for cut in choices),
              failed["best_internal"]["value"])
    else:
        failed = record["failed_rotation"]
        outer = failed["outer"]
        for name in ("left", "right"):
            child = outer[name]
            check("outer_" + name, evaluate(child["word"], child["maxima"]),
                  outer[name + "_value"])
        actual_inner = tuple(cut_values(evaluate, outer["left"]))
        attaining = [cut for cut in actual_inner if cut["value"] == outer["left_value"]]
        check("attaining_inner_count", len(attaining), len(failed["attaining_inner_cuts"]))
        summary = lambda cut: (tuple(cut["block"]), tuple(cut["rest"]),
                              cut["side"], cut["maximum"], cut["left_value"],
                              cut["right_value"], cut["value"])
        check("all_attaining_inner_cuts", sorted(map(summary, attaining)),
              sorted(map(summary, failed["attaining_inner_cuts"])))
        pieces = {tuple(outer["rest"])}
        for cut in attaining:
            pieces.update((tuple(cut["block"]), tuple(cut["rest"])))
        choices = [cut for cut in cut_values(evaluate, row)
                   if tuple(cut["block"]) in pieces]
        check("best_whole_piece_rotation", max(cut["value"] for cut in choices),
              failed["best_rotation"]["value"])
    failures = [check for check in checks if not check["passed"]]
    result = {"semantics": "context-bound-zero-children-v1", "source": args.source,
              "complete": True, "checks": checks, "failures": failures,
              "seconds": time.monotonic() - start, "lean_certified": False}
    Path(args.out).write_text(json.dumps(result, indent=2) + "\n")
    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
