import ESBlueprint.B.CtxBoundPartRunContractionOfOneLevelRoot
import ESBlueprint.B.CtxBoundChildRunContractionOneLevelRoot
import Mathlib.Data.List.GetD

namespace ErdosSzekeres

open Ctx Ctx.Context

set_option maxHeartbeats 8000000
set_option maxRecDepth 10000

example (σ : Ctx.Context) (hwf : σ.WellFormed)
  (left right : List Ctx.Letter) (r m t : ℕ) (side : Ctx.Side)
  (hr : 0 < r) (hm : 0 < m) (ht : 0 < t)
  (houter : ∀ x ∈ left ++ right, ∃ l s, 2 ≤ l ∧ x = Ctx.Letter.ext l s)
  (hword : σ.word = left ++ List.replicate r Ctx.Letter.child ++
    List.replicate m (Ctx.Letter.ext 1 side) ++ List.replicate t Ctx.Letter.child ++ right) :
  True := by
  classical
  have hExtMem : ∀ (τ : Context) (N : ℕ) (s : Side),
      Letter.ext N s ∈ τ.word ↔ ∃ p, τ.letterAt p = Letter.ext N s := by
    intro τ N s
    constructor
    · intro h
      obtain ⟨p, hp⟩ := List.mem_iff_getElem?.mp h
      exact ⟨p, by simp [Context.letterAt, hp]⟩
    · rintro ⟨p, hp⟩
      unfold Context.letterAt at hp
      cases he : τ.word[p]? with
      | none => simp [he] at hp
      | some x =>
        simp only [he, Option.getD_some] at hp
        exact List.mem_iff_getElem?.mpr ⟨p, hp ▸ he⟩
  let down : Letter → Letter
    | .child => .child
    | .ext N s => .ext (N - 1) s
  have hOldMem : ∀ x ∈ left ++ right, x ∈ σ.word := by
    intro x hx
    simp only [List.mem_append] at hx
    simp only [hword, List.mem_append]
    tauto
  have hLowerMem : ∀ x ∈ left.map down ++ right.map down,
      ∃ N s, 1 ≤ N ∧ x = Letter.ext N s ∧ Letter.ext (N + 1) s ∈ σ.word := by
    intro x hx
    rw [← List.map_append] at hx
    obtain ⟨y, hy, hxy⟩ := List.mem_map.mp hx
    obtain ⟨N, s, hN, rfl⟩ := houter y hy
    refine ⟨N - 1, s, by omega, ?_, ?_⟩
    · simpa [down] using hxy.symm
    · have hpred : N - 1 + 1 = N := by omega
      rw [hpred]
      exact hOldMem _ hy
  let hat (n : ℕ) : Context :=
    { σ with
      word := left.map down ++ List.replicate n Letter.child ++ right.map down
      maxima := σ.maxima.tail }
  have hOuterMem : ∀ n N s, Letter.ext N s ∈ (hat n).word →
      Letter.ext N s ∈ left.map down ++ right.map down := by
    intro n N s hx
    simpa [hat, List.mem_append] using hx
  have hLabels : ∀ n N s, Letter.ext N s ∈ (hat n).word →
      1 ≤ N ∧ N ≤ (hat n).maxima.length ∧ s = σ.sideAt (N + 1) := by
    intro n N s hx
    obtain ⟨N', s', hN, he, hold⟩ := hLowerMem _ (hOuterMem n N s hx)
    obtain ⟨rfl, rfl⟩ := Letter.ext.inj he
    obtain ⟨q, hq⟩ := (hExtMem σ (N + 1) s).mp hold
    obtain ⟨_, hlen, hs⟩ := hwf.2.2.2.2.2 q (N + 1) s hq
    refine ⟨hN, ?_, hs⟩
    simp only [hat, List.length_tail]
    omega
  have hWF : ∀ n, (hat n).WellFormed := by
    intro n
    obtain ⟨ha, hu, hak, huk, hmax, hlet⟩ := hwf
    refine ⟨ha, hu, hak, huk, ?_, ?_⟩
    · intro M hM
      exact hmax M (List.mem_of_mem_tail hM)
    · intro p N s hp
      have hmem := (hExtMem (hat n) N s).mpr ⟨p, hp⟩
      obtain ⟨hN, hlen, hs⟩ := hLabels n N s hmem
      refine ⟨hN, hlen, ?_⟩
      have hplen : p < (hat n).word.length := by
        by_contra h
        have he := letterAt_of_length_le (hat n) (Nat.le_of_not_gt h)
        rw [he] at hp
        cases hp
      have hpN : p ∈ (hat n).extPositions N := by
        simp [Context.extPositions, hplen, hp]
      cases hh : ((hat n).extPositions N).head? with
      | none =>
        have hnil := List.head?_eq_none_iff.mp hh
        rw [hnil] at hpN
        simp at hpN
      | some q =>
        have hqmem := List.mem_of_mem_head? (Option.mem_def.mpr hh)
        have hqext := (List.mem_filter.mp hqmem).2
        cases he : (hat n).letterAt q with
        | child => simp [he] at hqext
        | ext N' s' =>
          have heq : N' = N := by simpa [he] using hqext
          subst N'
          have hs' := (hLabels n N s'
            ((hExtMem (hat n) N s').mpr ⟨q, he⟩)).2.2
          change s = (hat n).sideAt N
          unfold Context.sideAt
          simp only [hh, he]
          exact hs.trans hs'.symm
  trivial

end ErdosSzekeres
