import Mathlib.Data.List.GetD
import Mathlib.Tactic

set_option maxHeartbeats 400000

example : True := by
  let alt (n : ℕ) (b : Bool) : List Bool :=
    (List.range n).map (fun i ↦ if i % 2 = 0 then b else !b)
  have hAltGet : ∀ n b i (hi : i < (alt n b).length),
      (alt n b)[i] = if i % 2 = 0 then b else !b := by
    intro n b i hi
    simp [alt]
  have hAltStep : ∀ n b, alt (n + 2) b = b :: (!b) :: alt n b := by
    intro n b
    apply List.ext_getElem (by simp [alt])
    intro i hi hj
    cases i with
    | zero => simp [alt]
    | succ i =>
      cases i with
      | zero => simp [alt]
      | succ i =>
        have hmod : (i + 1 + 1) % 2 = i % 2 := by omega
        simp [alt, hmod]
  have hAltNot : ∀ n b, (alt n b).map Bool.not = alt n (!b) := by
    intro n b
    apply List.ext_getElem (by simp [alt])
    intro i hi hj
    simp only [List.getElem_map, hAltGet]
    split_ifs <;> simp
  have hAltAdj : ∀ n b i (hi : i + 1 < (alt n b).length),
      (alt n b)[i] = true → (alt n b)[i + 1] = false := by
    intro n b i hi ht
    have hip : i < (alt n b).length := by omega
    rw [hAltGet n b i hip] at ht
    rw [hAltGet n b (i + 1) hi]
    have hmod : i % 2 < 2 := Nat.mod_lt i (by omega)
    have hnext : (i + 1) % 2 < 2 := Nat.mod_lt (i + 1) (by omega)
    cases b <;> simp at ht ⊢ <;> omega
  trivial

#eval IO.println "R9 parity helper checkpoint"
