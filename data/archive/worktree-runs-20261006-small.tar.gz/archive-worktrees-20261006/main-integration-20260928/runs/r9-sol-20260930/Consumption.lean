import ESBlueprint.B.CtxBoundAdditiveSingleRunAlternatingOfRunContractionAndDeletion
import ESBlueprint.B.CtxBoundAdditiveSingleRunOfRunContractionAndAlternating

namespace ErdosSzekeres

example
    (hcontract : ∀ (τ : Ctx.Context), τ.WellFormed →
      ∀ (side : Ctx.Side) (left right : List Ctx.Letter),
      τ.word = left ++ [Ctx.Letter.child, Ctx.Letter.child] ++ right →
      (∀ i ∈ τ.childPositions, ∀ j ∈ τ.childPositions, ∀ l : ℕ, i < l → l < j →
        τ.letterAt l = Ctx.Letter.child ∨ τ.letterAt l = Ctx.Letter.ext 1 side) →
      τ.bound = ({ τ with word := left ++ [Ctx.Letter.child] ++ right } : Ctx.Context).bound)
    (hdel : ∀ (τ : Ctx.Context), τ.WellFormed →
      (∀ p ∈ τ.childPositions, p + 1 ∉ τ.childPositions) →
      ∀ (left right : List Ctx.Letter) (lev : ℕ) (side : Ctx.Side),
      τ.word = left ++ [Ctx.Letter.ext lev side] ++ right →
      Ctx.Letter.ext lev side ∈ left ++ right →
      τ.bound ≤ ({ τ with word := left ++ right } : Ctx.Context).bound)
    (σ : Ctx.Context) (hwf : σ.WellFormed) (hruns : σ.numRuns ≤ 1)
    (keep : List ℕ) (hkeep : ∀ p ∈ keep, p ∈ σ.childPositions) (hne : keep ≠ [])
    (hall : keep.length < σ.childPositions.length) (d : ℕ) (hd : 1 ≤ d)
    (hdk : d ≤ σ.k - 2) :
    (σ.part keep Ctx.Side.lower d).bound +
        (σ.part (σ.childPositions.filter (fun p ↦ p ∉ keep)) Ctx.Side.upper
          (σ.k - 1 - d)).bound ≤ σ.bound ∧
      (σ.part keep Ctx.Side.upper (σ.k - 1 - d)).bound +
        (σ.part (σ.childPositions.filter (fun p ↦ p ∉ keep)) Ctx.Side.lower d).bound
          ≤ σ.bound := by
  exact ctx_bound_additive_single_run_of_run_contraction_and_alternating hcontract
    (ctx_bound_additive_single_run_alternating_of_run_contraction_and_deletion hcontract hdel)
    σ hwf hruns keep hkeep hne hall d hd hdk

#print axioms ctx_bound_additive_single_run_alternating_of_run_contraction_and_deletion
#print axioms ctx_bound_additive_single_run_of_run_contraction_and_alternating
end ErdosSzekeres
