"""Bounded exhaustive Python/C differential for the R5 compiled evaluator.

This enumerates every word in the stated small domain, including unused declared
levels and zero sibling maxima.  It is finite diagnostic evidence, not Lean proof
credit and not a general equivalence certificate.
"""
from __future__ import annotations

from itertools import combinations, product
import json
import time

from harness.research.recursive import evaluator


CASES = ((3, 4, 5), (4, 4, 5), (4, 5, 6), (5, 5, 6))


def external_sequences(depth: int, count: int):
    if depth == 0:
        if count == 0:
            yield ()
        return
    alphabet = tuple((level, side)
                     for level in range(1, depth + 1)
                     for side in ("lower", "upper"))
    for sequence in product(alphabet, repeat=count):
        sides = {}
        valid = True
        for level, side in sequence:
            if level in sides and sides[level] != side:
                valid = False
                break
            sides[level] = side
        if valid:
            yield sequence


def words(s_count: int, external):
    size = s_count + len(external)
    for s_positions in combinations(range(size), s_count):
        marked = set(s_positions)
        rest = iter(external)
        yield tuple("S" if position in marked else next(rest)
                    for position in range(size))


def main():
    started = time.monotonic()
    total = 0
    per_case = []
    for a, u, k in CASES:
        python_bound = evaluator(a, u, k, semantics="context-bound-zero-children-v1",
                                 cache_size=500000)
        compiled_bound = evaluator(a, u, k, semantics="context-bound-zero-children-c-v1",
                                   cache_size=16000)
        compared = 0
        for depth in range(4):
            external_max = 3 if depth <= 2 else 2
            for external_count in range(external_max + 1):
                for external in external_sequences(depth, external_count):
                    for s_count in range(1, 4):
                        for word in words(s_count, external):
                            for maxima in product(range(k - 1), repeat=depth):
                                expected = int(python_bound(word, maxima))
                                observed = compiled_bound(word, maxima)
                                if observed != expected:
                                    raise AssertionError(
                                        (a, u, k, word, maxima, expected, observed))
                                compared += 1
        total += compared
        per_case.append({"case": [a, u, k], "comparisons": compared})
        print(json.dumps(per_case[-1], sort_keys=True), flush=True)
    print(json.dumps({"comparisons": total, "elapsed_seconds": time.monotonic() - started,
                      "domain": {"depth_max": 3, "s_count": [1, 3],
                                 "external_max_by_depth": {"0-2": 3, "3": 2},
                                 "maxima": "0..k-2", "consistent_level_sides": True},
                      "per_case": per_case}, sort_keys=True))


if __name__ == "__main__":
    main()
