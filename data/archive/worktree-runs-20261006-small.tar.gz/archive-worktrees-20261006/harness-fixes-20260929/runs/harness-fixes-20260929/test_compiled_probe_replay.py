"""Registered witness-replay check for the R5 compiled semantics."""
from __future__ import annotations

import json
from pathlib import Path
import shutil

import pytest

from harness.research.recursive_cut import evaluate, replay


ROOT = Path(__file__).resolve().parents[2]


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_compiled_recursive_cut_witness_replays():
    spec = json.loads((ROOT / "harness/research/examples/recursive-cut-small.json").read_text())
    spec["semantics"] = "context-bound-zero-children-c-v1"
    spec["candidate"]["target"]["budget"] = 0
    result = evaluate(spec)
    assert result["outcome"] == "witness_found"
    checked = replay(result["witness"])
    assert checked["replayed"] is True
    assert checked["computed"]["target"]["sum"] == 7
    assert checked["computed"]["control"]["sum"] == 7
    assert checked["lean_refutation"] is False
