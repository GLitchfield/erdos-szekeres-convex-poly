"""Finite exact/overflow sweep for the compiled evaluator's S-only threshold."""
from __future__ import annotations

import math
import shutil

import pytest

from harness.research.context_bound import compiled_evaluator


INT64_MAX = (1 << 63) - 1


def threshold(a: int, u: int, k: int) -> int:
    if a <= 1 or u <= 1:
        return 0
    if a + u <= k + 3:
        return math.comb(a + u - 4, a - 2)
    return sum(math.comb(k - 2, j) for j in range(k - a, u - 1) if 0 <= j <= k - 2)


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_compiled_threshold_exactness_and_overflow():
    exact = overflow = 0
    for k in range(3, 21):
        for a in range(2, 21):
            for u in range(2, 21):
                expected = threshold(a, u, k)
                assert expected <= INT64_MAX
                assert compiled_evaluator(a, u, k)(("S",), ()) == expected
                exact += 1
    for a in range(2, 46):
        for u in range(2, 46):
            k = max(3, a + u - 3)
            expected = threshold(a, u, k)
            bound = compiled_evaluator(a, u, k)
            if expected <= INT64_MAX:
                assert bound(("S",), ()) == expected
                exact += 1
            else:
                with pytest.raises(OverflowError, match="signed 64-bit"):
                    bound(("S",), ())
                overflow += 1
    assert exact + overflow == 8434
    assert exact > 0 and overflow > 0
