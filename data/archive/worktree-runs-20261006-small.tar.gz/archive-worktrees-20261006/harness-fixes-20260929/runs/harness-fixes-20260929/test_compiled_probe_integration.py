"""End-to-end registered-probe check for the R5 compiled semantics."""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import shutil

import pytest

from harness.research.recursive_cut import evaluate


ROOT = Path(__file__).resolve().parents[2]


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_recursive_cut_probe_accepts_compiled_semantics():
    spec = json.loads((ROOT / "harness/research/examples/recursive-cut-small.json").read_text())
    python_result = evaluate(spec)
    compiled_spec = deepcopy(spec)
    compiled_spec["semantics"] = "context-bound-zero-children-c-v1"
    compiled_result = evaluate(compiled_spec)

    assert compiled_result["outcome"] == python_result["outcome"]
    assert compiled_result["stop_reason"] == python_result["stop_reason"]
    assert compiled_result["coverage"] == python_result["coverage"]
    assert compiled_result["sample_rows"] == python_result["sample_rows"]
    assert compiled_result["lean_equivalence"] is False
    assert compiled_result["finite_negative_has_proof_credit"] is False
