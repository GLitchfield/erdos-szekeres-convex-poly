#include <stdint.h>
#include <stdio.h>

int es_context_bound(int a, int u, int k, const int *word, size_t word_len,
                     const int *maxima, size_t depth, size_t cache_size,
                     int64_t *out);

static uint32_t state = 20260929U;

static uint32_t next_random(void) {
    state = state * 1664525U + 1013904223U;
    return state;
}

static int fail(const char *message, int rc, int64_t value) {
    fprintf(stderr, "%s: rc=%d value=%lld\n", message, rc, (long long)value);
    return 1;
}

int main(void) {
    int64_t value = -1;
    int end_cut[] = {1, 0, 0, -2, 0, 0};
    int end_maxima[] = {3, 1};
    int rc = es_context_bound(3, 4, 5, end_cut, 6, end_maxima, 2, 128, &value);
    if (rc != 0 || value != 1) return fail("end-cut regression", rc, value);

    int no_child[] = {1, -2};
    rc = es_context_bound(3, 4, 5, no_child, 2, end_maxima, 2, 128, &value);
    if (rc != 3) return fail("malformed context", rc, value);

    int one_child[] = {0};
    rc = es_context_bound(50, 50, 100, one_child, 1, NULL, 0, 128, &value);
    if (rc != 4) return fail("overflow path", rc, value);

    const int cases[][3] = {{4, 4, 5}, {4, 5, 6}, {5, 5, 6}};
    for (int sample = 0; sample < 10000; ++sample) {
        int s_count = 1 + (int)(next_random() % 4U);
        int ext_count = (int)(next_random() % 3U);
        int depth = ext_count ? 1 + (int)(next_random() % 3U) : (int)(next_random() % 4U);
        int sides[3] = {1, 1, 1};
        int word[6] = {0, 0, 0, 0, 0, 0};
        int maxima[3] = {0, 0, 0};
        for (int level = 0; level < depth; ++level)
            sides[level] = next_random() & 1U ? 1 : -1;
        for (int index = 0; index < ext_count; ++index) {
            int level = 1 + (int)(next_random() % (uint32_t)depth);
            word[s_count + index] = sides[level - 1] * level;
        }
        int length = s_count + ext_count;
        for (int index = length - 1; index > 0; --index) {
            int other = (int)(next_random() % (uint32_t)(index + 1));
            int temporary = word[index]; word[index] = word[other]; word[other] = temporary;
        }
        for (int case_index = 0; case_index < 3; ++case_index) {
            int k = cases[case_index][2];
            for (int level = 0; level < depth; ++level)
                maxima[level] = 1 + (int)(next_random() % (uint32_t)(k - 2));
            rc = es_context_bound(cases[case_index][0], cases[case_index][1], k,
                                  word, (size_t)length, maxima, (size_t)depth, 128, &value);
            if (rc != 0) return fail("generated context", rc, value);
        }
    }
    return 0;
}
