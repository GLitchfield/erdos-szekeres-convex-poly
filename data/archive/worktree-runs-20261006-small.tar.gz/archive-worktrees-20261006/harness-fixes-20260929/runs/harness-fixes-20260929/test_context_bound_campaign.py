"""Extended finite differential campaign for the R5 compiled evaluator.

Diagnostic evidence only: agreement here is not a Lean equivalence proof.
"""
from __future__ import annotations

import random
import shutil

import pytest

from harness.research.recursive import evaluator


CASES = ((4, 4, 5), (4, 5, 6), (5, 5, 6))


def context(rng: random.Random, *, s_count: int, external_max: int):
    external_count = rng.randint(0, external_max)
    depth = rng.randint(1 if external_count else 0, 3)
    sides = {level: rng.choice(("lower", "upper")) for level in range(1, depth + 1)}
    word = ["S"] * s_count
    word.extend((level := rng.randint(1, depth), sides[level]) for _ in range(external_count))
    rng.shuffle(word)
    return tuple(word), depth


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_extended_compiled_context_bound_campaign():
    comparisons = 0
    for a, u, k in CASES:
        python_bound = evaluator(a, u, k, semantics="context-bound-zero-children-v1", cache_size=200000)
        compiled_bound = evaluator(a, u, k, semantics="context-bound-zero-children-c-v1", cache_size=16000)
        for seed in range(2026092900, 2026092912):
            rng = random.Random(seed ^ (a << 16) ^ (u << 8) ^ k)
            for _ in range(250):
                word, depth = context(rng, s_count=rng.randint(1, 3), external_max=3)
                maxima = tuple(rng.randint(1, k - 2) for _ in range(depth))
                assert compiled_bound(word, maxima) == int(python_bound(word, maxima)), (
                    a, u, k, seed, word, maxima
                )
                comparisons += 1

        # A bounded stress slice reaches one level beyond the committed random fixture.
        rng = random.Random(2026092999 ^ (a << 16) ^ (u << 8) ^ k)
        for _ in range(50):
            word, depth = context(rng, s_count=4, external_max=2)
            maxima = tuple(rng.randint(1, k - 2) for _ in range(depth))
            assert compiled_bound(word, maxima) == int(python_bound(word, maxima)), (
                a, u, k, "stress", word, maxima
            )
            comparisons += 1
    assert comparisons == 9150
