"""Finite R5 differential campaign admitting zero sibling maxima."""
from __future__ import annotations

import random
import shutil

import pytest

from harness.research.recursive import evaluator
from test_context_bound_campaign import CASES, context


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_compiled_context_bound_with_zero_maxima():
    comparisons = 0
    for a, u, k in CASES:
        rng = random.Random(2026093000 ^ (a << 16) ^ (u << 8) ^ k)
        python_bound = evaluator(a, u, k, semantics="context-bound-zero-children-v1", cache_size=100000)
        compiled_bound = evaluator(a, u, k, semantics="context-bound-zero-children-c-v1", cache_size=16000)
        for _ in range(1000):
            word, depth = context(rng, s_count=rng.randint(1, 3), external_max=2)
            maxima = tuple(rng.randint(0, k - 2) for _ in range(depth))
            assert compiled_bound(word, maxima) == int(python_bound(word, maxima)), (
                a, u, k, word, maxima
            )
            comparisons += 1
    assert comparisons == 3000
