"""Bounded cold-cache concurrency diagnostic for the compiled context evaluator."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[2]


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_concurrent_first_use_publishes_one_loadable_library(tmp_path):
    code = (
        "from harness.research.context_bound import compiled_evaluator; "
        "print(compiled_evaluator(3,4,5)(((1,'lower'),'S','S',(2,'upper'),'S','S'),(3,1)))"
    )
    env = os.environ.copy()
    env["TMPDIR"] = str(tmp_path)
    env["PYTHONPATH"] = str(ROOT)
    processes = [
        subprocess.Popen([sys.executable, "-c", code], cwd=ROOT, env=env,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        for _ in range(8)
    ]
    results = [process.communicate(timeout=120) for process in processes]
    assert [(process.returncode, out.strip(), err) for process, (out, err) in zip(processes, results)] == [
        (0, "1", "") for _ in processes
    ]
    cache = tmp_path / f"es-context-bound-{os.getuid()}"
    assert len(list(cache.glob("context-bound-*.so"))) == 1
    assert not list(cache.glob(".context-bound-*"))
