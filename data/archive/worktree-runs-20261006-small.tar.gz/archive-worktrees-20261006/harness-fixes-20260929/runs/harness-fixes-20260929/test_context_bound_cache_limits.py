"""Finite differential check across tiny compiled memo-table limits."""
from __future__ import annotations

import random
import shutil

import pytest

from harness.research.recursive import evaluator
from test_context_bound_campaign import CASES, context


@pytest.mark.skipif(shutil.which("cc") is None, reason="C compiler unavailable")
def test_tiny_compiled_cache_limits_preserve_results():
    comparisons = 0
    for a, u, k in CASES:
        python_bound = evaluator(a, u, k, semantics="context-bound-zero-children-v1",
                                 cache_size=200000)
        for cache_size in (1, 2, 3, 7):
            compiled_bound = evaluator(a, u, k, semantics="context-bound-zero-children-c-v1",
                                       cache_size=cache_size)
            rng = random.Random(202609290000 ^ (a << 20) ^ (u << 12) ^ (k << 4) ^ cache_size)
            for index in range(500):
                s_count = 4 if index < 10 else rng.randint(1, 3)
                word, depth = context(rng, s_count=s_count, external_max=2)
                maxima = tuple(rng.randint(0, k - 2) for _ in range(depth))
                assert compiled_bound(word, maxima) == int(python_bound(word, maxima)), (
                    a, u, k, cache_size, word, maxima
                )
                comparisons += 1
    assert comparisons == 6000
