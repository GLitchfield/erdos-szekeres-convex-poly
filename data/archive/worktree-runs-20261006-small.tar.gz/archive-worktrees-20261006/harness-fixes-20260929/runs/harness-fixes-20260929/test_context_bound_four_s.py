"""Deterministic four-S Python/C stress slice for the R5 evaluator.

Finite diagnostic evidence only; this is not a Lean proof or equivalence theorem.
"""
from __future__ import annotations

import random

from harness.research.recursive import evaluator
from test_context_bound_campaign import context


CASES = ((3, 4, 5), (4, 4, 5), (4, 5, 6), (5, 5, 6))


def main():
    comparisons = 0
    for a, u, k in CASES:
        rng = random.Random(2026093001 ^ (a << 16) ^ (u << 8) ^ k)
        python_bound = evaluator(a, u, k, semantics="context-bound-zero-children-v1",
                                 cache_size=300000)
        compiled_bound = evaluator(a, u, k, semantics="context-bound-zero-children-c-v1",
                                   cache_size=16000)
        for _ in range(500):
            word, depth = context(rng, s_count=4, external_max=2)
            maxima = tuple(rng.randint(0, k - 2) for _ in range(depth))
            expected = int(python_bound(word, maxima))
            observed = compiled_bound(word, maxima)
            if observed != expected:
                raise AssertionError((a, u, k, word, maxima, expected, observed))
            comparisons += 1
        print(f"{a},{u},{k}: 500 matches", flush=True)
    print(f"comparisons={comparisons}")


if __name__ == "__main__":
    main()
