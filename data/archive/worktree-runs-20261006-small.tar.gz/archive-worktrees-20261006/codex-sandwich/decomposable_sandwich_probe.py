#!/usr/bin/env python3
"""Probe whether a single-run ``A B A`` split is dominated by a boundary split.

For every literal-Lean context recurrence tested here, compare each orientation and
coupling of the sandwich partition with the best prefix/suffix partition at the same
coupling (allowing either orientation).  A failure would rule out reducing the first
interleaved single-run case to ``ctx_bound_additive_prefix_suffix`` by uncrossing.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from decomposable_additivity_test import child, contexts  # noqa: E402
import decomposable_recursive_formula as recursive_formula  # noqa: E402
from decomposable_recursive_formula import make_F2, run_index  # noqa: E402


def split_value(F, word, maxima, keep, d, k, lower_first):
    """Value of one oriented split, using the literal Lean zero-inclusive sum."""
    child_positions = frozenset(i for i, letter in enumerate(word) if letter == "S")
    rest = child_positions - keep
    c = k - 1 - d
    if lower_first:
        left = child(word, maxima, keep, "lower", d)
        right = child(word, maxima, rest, "upper", c)
    else:
        left = child(word, maxima, keep, "upper", c)
        right = child(word, maxima, rest, "lower", d)
    return F(*left) + F(*right)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", required=True)
    parser.add_argument("--s-max", type=int, default=6)
    parser.add_argument("--e-max", type=int, default=2)
    parser.add_argument("--levels", type=int, default=2)
    parser.add_argument("--cache-size", type=int, default=100_000)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    a, u, k = (int(value) for value in args.case.split(","))
    recursive_formula.CACHE_SIZE = args.cache_size
    F = make_F2(a, u, k, include_zero_children=True)
    checked = 0
    violations = []
    for word, maxima in contexts(args.s_max, args.e_max, args.levels, k):
        child_positions = [i for i, letter in enumerate(word) if letter == "S"]
        runs = run_index(word)
        if len({runs[i] for i in child_positions}) != 1:
            continue
        n = len(child_positions)
        if n < 3:
            continue
        for l in range(1, n - 1):
            for middle_length in range(1, n - l):
                outer = frozenset(child_positions[:l] + child_positions[l + middle_length :])
                for d in range(1, k - 1):
                    boundary_values = []
                    for cut in range(1, n):
                        prefix = frozenset(child_positions[:cut])
                        boundary_values.extend(
                            split_value(F, word, maxima, prefix, d, k, orientation)
                            for orientation in (True, False)
                        )
                    best_boundary = max(boundary_values)
                    for orientation in (True, False):
                        checked += 1
                        value = split_value(F, word, maxima, outer, d, k, orientation)
                        if value > best_boundary and len(violations) < 30:
                            violations.append(
                                {
                                    "word": list(word),
                                    "maxima": list(maxima),
                                    "lengths": [l, middle_length, n - l - middle_length],
                                    "d": d,
                                    "orientation": "lower" if orientation else "upper",
                                    "value": value,
                                    "best_boundary": best_boundary,
                                }
                            )
    result = {"case": args.case, "checked": checked, "violations": violations}
    args.output.write_text(json.dumps(result, indent=2, default=list) + "\n")
    print(json.dumps({"case": args.case, "checked": checked, "violations": len(violations)}))
    raise SystemExit(bool(violations))


if __name__ == "__main__":
    main()
